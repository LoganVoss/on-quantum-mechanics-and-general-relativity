# Voss v2.2: foundations, continuum criteria, and an independent Lax selector

Read **paper/foundations.pdf** first (13 pages). This package extends, rather than silently replaces, the supplied v2.0 manuscript and v2.1 audit.

## Main result
For the declared nontrivial scalar-current rational Lax ansatz, a weighted nonlinear two-polarization sigma model is locally compatible exactly when its coupling W is harmonic. If W depends on a harmonic area with non-null gradient, W is affine. For W=c rho^n, **n=0 and n=1** both survive. Vanishing coupling at the shrinking axis removes the constant branch and gives W=c rho, c>0.

This is a selector of the **shape coupling**, not the whole gravitational action. An explicit dilaton-dependent Weyl-frame deformation preserves the Lax system and asymptotic data while changing the 4D metric under the fixed dictionary.

## What is clearly defined
- Four-dimensional spacetime is an input 2+2 interpretation; the information target dimension is separately two.
- Signature (-,+,+,+) follows from a stipulated Lorentzian quotient and a positive orbit covariance block.
- The canonical probe uses a regular irreducible Weyl representation on L2(R). A finite initial-state support does not make the canonical algebra finite dimensional.
- Target-coordinate cutoff removal at fixed radial lattice, the known polarized field continuum, and the interacting radial quantum continuum are separate limits.
- A precise strong-resolvent/observable convergence contract is provided. The exponential Hamiltonian preserves a valid limit but cannot manufacture one.

## Executed checks
The four supplied audit scripts were rerun unmodified. New code verifies the Lax algebra, its Frobenius obstruction, the exact rational single-chart rank, generic noncommuting current jets, a Weyl-frame curvature obstruction, and an explicit polarized continuum cutoff example. The zero-twist-corrected two-polarization PDE is evolved on 128, 256, 512, and 1024 interval grids. Nonlinear backreaction is retained.

The corrected initial twist coefficient is 0.05278195754784881. On the 1024 grid the relative energy drift is 3.91579e-6 and max exp(gamma) is 2.35797141. The finite-difference method has a decreasing but nonzero twist-conservation defect; it is not advertised as exactly charge conserving.

## Run
```bash
python -m venv .venv
. .venv/bin/activate
pip install -r requirements.txt
python scripts/verify_all.py
```
This reruns the uploaded audit scripts, all new calculations, and writes JSON/CSV/NPZ/log outputs to `evidence/`. Synthetic results are deterministic except wall-clock timing.

To build the paper:
```bash
cd paper
pdflatex -interaction=nonstopmode -halt-on-error foundations.tex
pdflatex -interaction=nonstopmode -halt-on-error foundations.tex
```

## Lean status
`lean/Certificates.lean` contains small algebraic certificates for the power-law alternatives and scalar Lax coefficient, not the full PDE or continuum argument. **The Lean compiler was unavailable; these sources have not been compiler-verified.** No `sorry` or postulated theorem is used. Python/SymPy certificates were executed separately.

## Status and scope
This is an unpublished research supplement with AI assistance, not a laboratory experiment or an established new fundamental theory. Classical local Lax compatibility is not quantum integrability. The interacting two-polarization radial quantum continuum is **not established** by this bundle. Existing literature on canonical nonlinear gravitational quantization and integrable deformations is cited without claiming that it is equivalent to this regulator.

No files were published to a remote GitHub repository. The ZIP contains a local Git bundle and a directory ready for user-controlled publication. No new distribution license has been assigned to the user-supplied sources.
