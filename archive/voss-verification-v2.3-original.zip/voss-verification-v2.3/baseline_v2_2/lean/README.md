# Optional Lean certificates

**Not compiled in this authoring environment.** These source-level certificates are intentionally small; none formalizes the full Lax/continuum theorem. No `sorry` or new axiom is used.

```bash
lake update
lake exe cache get
lake build
```

Python/SymPy execution logs in `../evidence/` are independent evidence, not a replacement for Lean kernel checking.
