# Claim ledger

| Statement | Status | Scope / input |
|---|---|---|
| Spacetime dimension 4 | Explicit kinematic premise | 2D quotient + two spacelike orbit directions |
| Lorentzian signature | Premise plus algebraic consequence | Lorentzian quotient; positive covariance block |
| Probe canonical algebra | Explicit premise | Regular irreducible Weyl representation |
| Gaussian fiducial probe from saturation | Analytic result inherited and specified | Finite covariance; ordinary Schrödinger representation |
| Single-chart action selection | Source result; exact finite certificate rerun | Original two-derivative candidate class and literal quotient frame |
| Local rational Lax family iff W is harmonic | Derived here, known-framework antecedents | Nontrivial scalar-current ansatz; generic two-polarization jets |
| W=c rho^n only n=1 | False without extra condition | n=0 also admits a Lax family |
| Integrability plus axis selects W=c rho | Proved within scoped ansatz | Harmonic non-null rho, smooth W, W(0)=0, positivity |
| Integrability selects complete Einstein action | Not established; explicit surviving freedom | U changes under a dilaton-dependent Weyl field redefinition |
| Local Lax pair gives full global integrability | Not claimed | Boundary/monodromy/involution requirements are separate |
| Fixed-lattice target-space Dirichlet exhaustion | Proved in supplement | Positive closable form, nested form core |
| Interacting radial quantum continuum | Defined but not constructed | Renormalization, embeddings, observables, identities need control |
| Exponential Hamiltonian inherits strong-resolvent limit | Proved conditional functional-calculus result | Positive renormalized generators on an identified Hilbert space |
| Bounded Hamiltonian ensures continuum | False | K_j=jI produces a saturated trivial phase limit |
| Polarized Fock cutoff removal | Established theory plus explicit worked proof/check | One polarization; exact nonlinear physical-time Hamiltonian |
| Corrected zero-twist nonlinear pulse | Newly executed numerical benchmark | Finite radial domain and convergent finite differences |
| Lean kernel verification | Not performed | Small source certificates included, compiler unavailable |
| Worldwide priority / new fundamental force | Not claimed | No independent priority or empirical evidence |
