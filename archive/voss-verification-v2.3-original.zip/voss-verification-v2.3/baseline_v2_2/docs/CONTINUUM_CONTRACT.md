# Continuum contract

## Do not identify these limits
1. Removing a finite matrix / target-coordinate approximation at a fixed radial lattice.
2. Taking radial spacing to zero at fixed physical radius, with declared counterterms and vacuum normalization.
3. Handling the regular axis and sending the outer radius to infinity in a fixed asymptotic sector.
4. Taking hbar to zero or kappa to zero. These are not spatial continuum limits.

## Regulator
At finite radial sites, use H_N=L2((H2)^N, product hyperbolic volume) with positive kinetic Dirichlet form and a nonnegative nearest-neighbor squared-geodesic potential. Its Friedrichs operator is an infinite-dimensional quantum operator. A 256-dimensional coordinate-grid matrix is only an approximation to it.

Dirichlet exhaustion in target configuration space converges at fixed N because the restricted form domains increase to a form core. This does not settle N->infinity.

## Generator criterion
Provide common-space embeddings (or an explicit generalized Hilbert-space convergence scheme), renormalized nonnegative self-adjoint K_j and K, and prove

```
(K_j + lambda)^(-1) psi -> (K + lambda)^(-1) psi
```

for all psi and lambda>0. Mosco liminf and recovery conditions for the forms are sufficient. For fixed kappa>0, this implies strong convergence of exp(-kappa K_j), H_j=(I-exp(-kappa K_j))/kappa and their unitary groups uniformly on compact time intervals.

## Observable criterion
Also identify the physical smeared observable algebras, renormalized geometric composites, compatible states, finite ordered correlation functions, and the relevant reduced symmetry/constraint identities. Generator convergence alone is not a gravitational all-operator equivalence. For unbounded operators, domain and moment/tail control must be explicit.

## Saturation test
K_j=jI has a convergent bounded physical Hamiltonian H_j->I/kappa but no finite self-adjoint generator limit. Boundedness is not an ultraviolet proof. If H_j->H strongly, L=I-kappa H has zero kernel, and all operators live on the identified common Hilbert space, K=-log(L)/kappa supplies a possible strong-resolvent limit. That still does not establish the local observable map.

## Precisely established sector
In the known polarized Fock model, K=dGamma(hbar k) and K_Lambda=dGamma(hbar min(k,Lambda)). Monotone form convergence proves the continuum cutoff removal, with the exact nonlinear physical H retained. The interacting two-polarization field is not replaced by that solvable sector.
