# Independent integrability selector

This route does not evaluate a flat reference metric. It assumes a Lorentzian conformal quotient, a torsion-free current equation for M in SL(2,R)/SO(2), and the standard scalar-current rational Lax ansatz. It is a local classical result, not a classification of all possible integrable theories.

Let J_±=M^(-1)∂_±M, with ∂_±=∂_T±∂_R. The equations are

```
∂_+ J_- - ∂_- J_+ + [J_+,J_-] = 0,
∂_+(W J_-) + ∂_-(W J_+) = 0.
```

Set L_+=J_+/(1-s), L_-=J_-/(1+s). Their flatness requires

```
∂_+ s = s(1+s)/(1-s) * ∂_+ log W,
∂_- s = s(1-s)/(1+s) * ∂_- log W.
```

The Frobenius obstruction is exactly

```
∂_-∂_+s - ∂_+∂_-s = 4 s^2/(1-s^2) * W_{+-}/W.
```

A nontrivial spectral family therefore requires W_{+-}=0. Conversely, a harmonic W has local harmonic conjugate Wtilde, and the constant spectral curve

```
w = Wtilde + W/2 (s + 1/s)
```

constructs the family. The trivial s=0 connection is just Maurer-Cartan and is not an integrability test of the equations of motion.

For W=W(rho), harmonic rho with non-null gradient implies W''=0. Thus W=c0+c1 rho. Powers give n(n-1)=0: both n=0 and n=1. Shrinking-axis W(0)=0 and nontrivial positivity select W=c1 rho, c1>0.

Neither U(rho), the literal quotient Weyl frame, nor the entire quantum observable algebra is fixed by this condition. For example

```
F=a0 rho, W=a0 rho, V=0,
U=a0/(2rho) + 2 a0 eta B'(rho)
```

with smooth compactly supported B has the same local shape Lax equations. It is related to the Einstein frame by h_eta=exp(-2 eta B) h_0, which changes the 4D metric when h is the literal base block. The scalar curvature of the cylindrical seed becomes -exp(-gamma) gamma'', gamma=-2 eta B, generically nonzero.

The familiar Lax framework and the restrictions on local sigma-model couplings have prior literature, including Hoare, Levine and Tseytlin, JHEP 11 (2020) 020. The present work is a scoped derivation and verification for the supplied selection question, not a claim of first discovery of that framework.
