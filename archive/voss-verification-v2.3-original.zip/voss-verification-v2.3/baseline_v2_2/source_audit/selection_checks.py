"""Selection-theorem checks (exact rational linear algebra via fractions + numpy rank).
Equations of motion of S=int sqrt(-h)[F R + U (grad rho)^2 - W/4 Tr(J_a J^a) + V + k(rho) eps^{ab} Omega_ij d_a phi^i d_b phi^j]
evaluated on flat reference charts.
Chart M (Milne-polar):  rho=t r, P=log(t/r), Q=0.
Chart C (cylindrical):  rho=r,   P=-log r,   Q=0.
Chart K (constant):     rho=const, M=const.
Metric equations (derived by hand and cross-checked with the paper's Eq. 19):
 M-tt: -F'' t^2 + U s/2 - W s/(4 rho^2) + V/2
 M-rr: -F'' r^2 + U s/2 - W s/(4 rho^2) - V/2   (s=t^2+r^2)
 M-tr: -(rho F''+F') + rho U + W/(2 rho)
 M-shape(P): -W' (r/t+t/r) + W (1/t^2+1/r^2)   [times 1]  ; M-shape(Q) odd term: 4 (t/r) k'
 C-tt: -F'' + U/2 - W/(4 rho^2) + V/2 ; C-rr: U/2 - W/(4 rho^2) - V/2 ; area/shape analogues.
"""
import numpy as np, itertools
from fractions import Fraction as Fr

powers = list(range(-2, 5))          # basis rho^j, j=-2..4 for every function (wider than paper's m=5)
nb = len(powers)

def basis(j, rho, d=0):
    # d-th derivative of rho^j
    c = 1
    for k in range(d): c *= (j - k)
    return c * rho ** (j - d) if (j - d) != 0 or c != 0 else 0.0

def row_blocks(rho, which):
    """return dict of coefficient vectors (for unknowns f_j,u_j,w_j,v_j) giving F,F',F'',U,W,W',V at rho"""
    z = np.zeros(nb)
    F  = np.array([basis(j, rho, 0) for j in powers]); F1 = np.array([basis(j, rho, 1) for j in powers])
    F2 = np.array([basis(j, rho, 2) for j in powers])
    return F, F1, F2

def assemble(rows_spec):
    A = []
    for spec in rows_spec:
        A.append(spec)
    return np.array(A)

def eq_rows_milne(t, r, include_P=True):
    rho = t * r; s = t * t + r * r
    F, F1, F2 = row_blocks(rho, 'f')
    U = F.copy(); W = F.copy(); V = F.copy()
    W1 = F1.copy()
    Z = np.zeros(nb)
    def vec(f=Z, u=Z, w=Z, v=Z): return np.concatenate([f, u, w, v])
    rows = []
    rows.append(vec(f=-F2 * t * t, u=U * s / 2, w=-W * s / (4 * rho ** 2), v=V / 2))
    rows.append(vec(f=-F2 * r * r, u=U * s / 2, w=-W * s / (4 * rho ** 2), v=-V / 2))
    rows.append(vec(f=-(rho * F2 + F1), u=rho * U, w=W / (2 * rho)))
    if include_P:
        rows.append(vec(w=-W1 * (r / t + t / r) + W * (1 / t ** 2 + 1 / r ** 2)))
    return rows

def eq_rows_cyl(r):
    rho = r; F, F1, F2 = row_blocks(rho, 'f'); U = F.copy(); W = F.copy(); V = F.copy(); Z = np.zeros(nb)
    def vec(f=Z, u=Z, w=Z, v=Z): return np.concatenate([f, u, w, v])
    return [vec(f=-F2, u=U / 2, w=-W / (4 * rho ** 2), v=V / 2), vec(u=U / 2, w=-W / (4 * rho ** 2), v=-V / 2)]

def eq_rows_const(rho):
    F, *_ = row_blocks(rho, 'f'); Z = np.zeros(nb)
    return [np.concatenate([Z, Z, Z, F])]

def nullspace_report(A, label):
    u, sv, vt = np.linalg.svd(A)
    tol = 1e-9 * sv[0]
    rank = int((sv > tol).sum())
    null = vt[rank:]
    print(f"  {label}: rows={A.shape[0]}, unknowns={A.shape[1]}, rank={rank}, nullity={A.shape[1]-rank}")
    return null

def describe(null):
    # null space should be spanned by: (F=rho: f_1=1, U=1/(2 rho): u_{-1}=1/2, W=rho: w_1=1) and Euler const f_0=1
    names = [f"f{j}" for j in powers] + [f"u{j}" for j in powers] + [f"w{j}" for j in powers] + [f"v{j}" for j in powers]
    target_a = np.zeros(4 * nb); target_a[powers.index(1)] = 1; target_a[nb + powers.index(-1)] = .5; target_a[2 * nb + powers.index(1)] = 1
    target_b = np.zeros(4 * nb); target_b[powers.index(0)] = 1
    # check span equality: project targets on null space
    ok = []
    for tg, nm in [(target_a, 'Einstein direction (a)'), (target_b, 'Euler constant (b)')]:
        res = tg - null.T @ (null @ tg)
        ok.append((nm, np.linalg.norm(res)))
    dim = null.shape[0]
    print(f"    nullity={dim}; distance of known solutions from null space: " + ", ".join(f"{n}: {v:.1e}" for n, v in ok))
    # are there any extra null directions?
    span = np.stack([target_a, target_b])
    q, _ = np.linalg.qr(span.T)
    extra = null - (null @ q) @ q.T
    print(f"    extra (non-Einstein, non-Euler) null directions: {np.linalg.matrix_rank(extra, tol=1e-8)}")

rng = np.random.default_rng(7)
print(f"basis rho^j, j in {powers}: 4 functions -> {4*nb} unknowns")

# (i) chart K + C only: what the "constant + cylindrical" pair leaves free
rowsKC = []
for rho in [0.7, 1.1, 1.9, 2.6, 3.3, 4.1, 5.2]: rowsKC += eq_rows_const(rho)
for r in [0.6, 0.9, 1.4, 2.2, 3.1, 4.3, 5.5, 6.1]: rowsKC += eq_rows_cyl(r)
nKC = nullspace_report(np.array(rowsKC), "constant + cylindrical charts only"); describe(nKC)

# (ii) Milne chart alone (metric eqs only, then metric + P equation), sampling many (t,r)
pts = [(rng.uniform(0.4, 3), rng.uniform(0.4, 3)) for _ in range(40)]
rowsM = []
for t, r in pts: rowsM += eq_rows_milne(t, r, include_P=False)
nM = nullspace_report(np.array(rowsM), "Milne chart ALONE (metric equations)"); describe(nM)

# (iii) Milne chart alone, sampled only on a SINGLE rho level set, to show the t-r spread (not rho scan) does the work
rowsM1 = []
for t in np.linspace(0.5, 2.5, 25):
    r = 1.7 / t
    rowsM1 += eq_rows_milne(t, r, include_P=False)
nM1 = nullspace_report(np.array(rowsM1), "Milne chart, points on ONE hyperbola rho=1.7 only");
print("    (only local data at a single rho: constrains values F''(1.7),U,W,V,F' at that rho -> pointwise algebra)")

# (iv) Milne metric + P-equation but with F decoupled: W ~ rho from the matter equation alone
rowsP = []
for t, r in pts:
    rr = eq_rows_milne(t, r, include_P=True)[3]; rowsP.append(rr)
A = np.array(rowsP); u_, sv, vt = np.linalg.svd(A)
rank = int((sv > 1e-9 * sv[0]).sum())
null = vt[rank:]
# restrict to W-block
Wblock = A[:, 2 * nb:3 * nb]
uu, ss, vv = np.linalg.svd(Wblock); rk = int((ss > 1e-9 * ss[0]).sum())
wn = vv[rk:]
print(f"  Milne shape (P) equation alone: W-block rank={rk} of {nb}; nullspace dim={wn.shape[0]} "
      f"; W=rho in null space? residual={np.linalg.norm(np.eye(nb)[powers.index(1)] - wn.T @ (wn @ np.eye(nb)[powers.index(1)])):.1e}")

# (v) parity-odd term k(rho): its Q-equation on the Milne chart is 4 e^P k'(rho)=4 (t/r) k'  -> k'=0
print("  parity-odd coupling k(rho): Q-equation on Milne chart = 4*(t/r)*k'(rho); vanishes iff k'=0 (k=const is a total derivative)")

# (vi) quartic counter-term N^2, N = rho^2 tr_h G - (grad rho)^2 : vanishes on K, C, M
for name, (X, Y, rho) in {
    'Milne': (lambda t, r: t * t - r * r, lambda t, r: -1 / t ** 2 + 1 / r ** 2, lambda t, r: t * r)}.items():
    vals = [rho(t, r) ** 2 * Y(t, r) - X(t, r) for t, r in pts]
    print(f"  N=rho^2 Y - X on {name} chart: max|N| = {np.max(np.abs(vals)):.1e}")
rr_ = rng.uniform(0.5, 5, 20)
print(f"  N on cylindrical chart (X=1,Y=1/r^2,rho=r): max|N| = {np.max(np.abs(rr_**2/rr_**2 - 1)):.1e}")
