"""Independent numerical geometry checks (no sympy available).
A) Off-shell identity (25): R[g] = R[h] - 2 box log rho - 3/2 (grad log rho)^2 - 1/4 Tr(J_a J^a)
   on generic non-solution fields.
B) Exact time-dependent vacuum solution (flat Milne chart in areal gauge) and a constant-SL(2,R)
   twisted copy with nonconstant A: test eqs (30)-(33) and all 16 four-d Ricci components.
"""
import numpy as np

H1, H2 = 1e-4, 1e-3

def ricci_from_metric(gfun, x):
    n = len(x)
    def d1(f, i, h=H1):
        e = np.zeros(n); e[i] = h
        return (f(x + e) - f(x - e)) / (2 * h)
    g = gfun(x); gi = np.linalg.inv(g)
    dg = np.array([d1(gfun, k) for k in range(n)])            # dg[k,a,b] = d_k g_ab
    ddg = np.zeros((n, n, n, n))                               # ddg[k,l,a,b]
    for k in range(n):
        for l in range(n):
            ek = np.zeros(n); el = np.zeros(n); ek[k] = H2; el[l] = H2
            ddg[k, l] = (gfun(x + ek + el) - gfun(x + ek - el) - gfun(x - ek + el) + gfun(x - ek - el)) / (4 * H2 ** 2)
    # Christoffel
    low = np.zeros((n, n, n))   # Gamma_{s,mu,nu}
    for s in range(n):
        for m in range(n):
            for v in range(n):
                low[s, m, v] = 0.5 * (dg[m, s, v] + dg[v, s, m] - dg[s, m, v])
    Gam = np.einsum('ls,smv->lmv', gi, low)
    dlow = np.zeros((n, n, n, n))  # d_k Gamma_{s,m,v}
    for k in range(n):
        for s in range(n):
            for m in range(n):
                for v in range(n):
                    dlow[k, s, m, v] = 0.5 * (ddg[k, m, s, v] + ddg[k, v, s, m] - ddg[k, s, m, v])
    dgi = np.array([-gi @ dg[k] @ gi for k in range(n)])
    dGam = np.einsum('kls,smv->klmv', dgi, low) + np.einsum('ls,ksmv->klmv', gi, dlow)  # d_k Gamma^l_mv
    Ric = np.zeros((n, n))
    for m in range(n):
        for v in range(n):
            t1 = sum(dGam[l, l, m, v] for l in range(n))
            t2 = sum(dGam[v, l, m, l] for l in range(n))
            t3 = sum(Gam[l, l, s] * Gam[s, m, v] for l in range(n) for s in range(n))
            t4 = sum(Gam[l, v, s] * Gam[s, m, l] for l in range(n) for s in range(n))
            Ric[m, v] = t1 - t2 + t3 - t4
    return Ric, g, gi

# ---------------- A: off-shell identity with generic fields ----------------
def fields(T, R):
    s = 0.30 * np.sin(T + 0.5 * R) + 0.1 * R
    rho = 2.0 + 0.7 * np.sin(0.8 * T - R) + 0.3 * R
    u = 0.5 * np.cos(T - 0.7 * R) + 0.2 * T
    v = 1.5 + 0.6 * np.sin(0.4 * T + R)
    return s, rho, u, v

def g4_A(X):
    T, R = X[0], X[1]
    s, rho, u, v = fields(T, R)
    M = np.array([[1, u], [u, u * u + v * v]]) / v
    g = np.zeros((4, 4))
    g[0, 0] = -np.exp(2 * s); g[1, 1] = np.exp(2 * s)
    g[2:, 2:] = rho * M
    return g

def fd(f, X, i, h=1e-4):
    e = np.zeros(2); e[i] = h
    return (f(X + e) - f(X - e)) / (2 * h)

def fdd(f, X, i, j, h=1e-3):
    ei = np.zeros(2); ej = np.zeros(2); ei[i] = h; ej[j] = h
    return (f(X + ei + ej) - f(X + ei - ej) - f(X - ei + ej) + f(X - ei - ej)) / (4 * h * h)

def rhs25(X):
    sf = lambda Y: fields(Y[0], Y[1])[0]
    rf = lambda Y: fields(Y[0], Y[1])[1]
    lr = lambda Y: np.log(rf(Y))
    s = sf(X)
    box = lambda f: np.exp(-2 * s) * (-fdd(f, X, 0, 0) + fdd(f, X, 1, 1))      # conformally flat 2d
    Rh = -2 * np.exp(-2 * s) * (-fdd(sf, X, 0, 0) + fdd(sf, X, 1, 1))
    grad2 = np.exp(-2 * s) * (-fd(lr, X, 0) ** 2 + fd(lr, X, 1) ** 2)
    def Mf(Y):
        _, _, u, v = fields(Y[0], Y[1]); return np.array([[1, u], [u, u * u + v * v]]) / v
    M = Mf(X); Mi = np.linalg.inv(M)
    J = [Mi @ fd(Mf, X, a) for a in range(2)]
    trJJ = np.exp(-2 * s) * (-np.trace(J[0] @ J[0]) + np.trace(J[1] @ J[1]))
    return Rh - 2 * box(lr) - 1.5 * grad2 - 0.25 * trJJ

print("== A: off-shell identity (25) on generic fields ==")
for X in [np.array([0.3, 1.1, 0, 0.]), np.array([1.2, 0.7, 0, 0.]), np.array([-0.4, 2.0, 0, 0.])]:
    Ric, g, gi = ricci_from_metric(g4_A, X)
    Rg = np.einsum('ab,ab->', gi, Ric)
    r = rhs25(X[:2])
    print(f"  R[g] numeric={Rg:+.8f}  RHS(25)={r:+.8f}  diff={abs(Rg-r):.2e}")

# ---------------- B: exact Milne solution, twisted copy ----------------
Sm = np.array([[1.3, 0.4], [0.9, 0.0]])   # build SL2 matrix
a_, b_, c_, d_ = 1.2, 0.5, 0.7, 0.0
d_ = (1 + b_ * c_) / a_                      # ad - bc = 1
S = np.array([[a_, b_], [c_, d_]]); assert abs(np.linalg.det(S) - 1) < 1e-12

def milne_fields(T, R, twist=True):
    q = np.sqrt(T * T - R * R)
    t2, r2 = T + q, T - q
    e2s = 1.0 / (2 * q)
    if twist:
        gzz = a_ ** 2 * t2 + c_ ** 2 * r2
        gzp = a_ * b_ * t2 + c_ * d_ * r2
    else:
        gzz, gzp = t2, 0.0
    psi = np.log(gzz); A = gzp / gzz
    gam = np.log(e2s) + psi            # e^{gamma-psi} = e^{2s}
    return psi, A, gam

def g4_B(X, twist=True):
    T, R = X[0], X[1]
    psi, A, gam = milne_fields(T, R, twist)
    g = np.zeros((4, 4))
    g[0, 0] = -np.exp(gam - psi); g[1, 1] = np.exp(gam - psi)
    # coordinates (T,R,phi,z)
    g[2, 2] = R * R * np.exp(-psi) + np.exp(psi) * A * A
    g[2, 3] = g[3, 2] = np.exp(psi) * A
    g[3, 3] = np.exp(psi)
    return g

print("== B: exact vacuum (Milne, SL(2,R)-twisted) ==")
for X in [np.array([2.0, 1.0, 0, 0.]), np.array([3.1, 2.2, 0, 0.])]:
    for tw in (False, True):
        Ric, g, gi = ricci_from_metric(lambda Y: g4_B(Y, tw), X)
        print(f"  twist={tw}  X={X[:2]}  max|Ric_mu nu| (16 comps) = {np.max(np.abs(Ric)):.2e}")
    # perturbed gamma (sanity: test must fail if equations are wrong)
    def g4_bad(Y):
        g = g4_B(Y, True); g[0,0] *= 1.02; g[1,1] *= 1.02; return g
    Ric, *_ = ricci_from_metric(g4_bad, X)
    print(f"  constant gamma shift (still a solution; the real discrimination test is in extra_checks.py): max|Ric| = {np.max(np.abs(Ric)):.2e}")

# residuals of reduced equations (30)-(33) on the twisted exact solution
def fld(Y): return milne_fields(Y[0], Y[1], True)
def comp(k): return lambda Y: fld(Y)[k]
for X in [np.array([2.0, 1.0]), np.array([3.1, 2.2])]:
    T, R = X
    psi, A, gam = fld(X)
    pT, pR = fd(comp(0), X, 0), fd(comp(0), X, 1)
    AT, AR = fd(comp(1), X, 0), fd(comp(1), X, 1)
    gT, gR = fd(comp(2), X, 0), fd(comp(2), X, 1)
    pTT, pRR = fdd(comp(0), X, 0, 0), fdd(comp(0), X, 1, 1)
    ATT, ARR = fdd(comp(1), X, 0, 0), fdd(comp(1), X, 1, 1)
    e30 = gR - (R / 2 * (pT ** 2 + pR ** 2) + np.exp(2 * psi) / (2 * R) * (AT ** 2 + AR ** 2))
    e31 = gT - (R * pT * pR + np.exp(2 * psi) / R * AT * AR)
    e32 = pTT - pRR - pR / R - np.exp(2 * psi) / R ** 2 * (AT ** 2 - AR ** 2)
    e33 = ATT - ARR + AR / R + 2 * (pT * AT - pR * AR)
    print(f"  X={X}: residuals (30)={e30:+.1e} (31)={e31:+.1e} (32)={e32:+.1e} (33)={e33:+.1e}   |A_R|={abs(AR):.3f}")
