import numpy as np, sys
sys.argv = ['x']
exec(open('geom_checks.py').read().split('# ---------------- A:')[0])  # reuse ricci_from_metric

# ---------- 1. proper discrimination test for the Ricci check ----------
exec(open('geom_checks.py').read().split('# ---------------- B: exact Milne solution, twisted copy ----------------')[1].split('print("== B')[0])
print("== 1. discrimination of the 4D Ricci test (twisted Milne solution) ==")
X = np.array([2.0, 1.0, 0, 0.])
def with_gamma_shift(f):
    def g(Y):
        gg = g4_B(Y, True); fac = np.exp(f(Y)); gg[0, 0] *= fac; gg[1, 1] *= fac; return gg
    return g
for name, f in [("gamma += const 0.02 (still a solution)", lambda Y: 0.02),
                ("gamma += 0.02*R (NOT a solution)", lambda Y: 0.02 * Y[1]),
                ("gamma += 0.02*T (NOT a solution)", lambda Y: 0.02 * Y[0])]:
    Ric, *_ = ricci_from_metric(with_gamma_shift(f), X)
    print(f"  {name:42s}: max|Ric| = {np.max(np.abs(Ric)):.2e}")
# drop the twist-dependent coefficient in the metric: use twisted orbit block but untwisted base conformal factor from psi_untwisted
def g_wrong(Y):
    g = g4_B(Y, True); psi0, _, gam0 = milne_fields(Y[0], Y[1], False)
    psi1, _, _ = milne_fields(Y[0], Y[1], True)
    fac = np.exp((gam0 - psi0) - (np.log(1.0/(2*np.sqrt(Y[0]**2-Y[1]**2)))))  # = 1, keeps base; instead perturb base using psi mismatch
    g[0,0] = -np.exp(gam0 - psi1); g[1,1] = np.exp(gam0 - psi1); return g
Ric, *_ = ricci_from_metric(g_wrong, X)
print(f"  base factor built from wrong psi (twist ignored in gamma): max|Ric| = {np.max(np.abs(Ric)):.2e}")

# ---------- 2. machine check of the variation formula (19) ----------
print("== 2. functional derivative check of E_ab (Eq. 19) with generic F,U,W,V and generic non-solution fields ==")
N = 241
x = np.linspace(-1.2, 1.2, N); dx = x[1] - x[0]
T, Rr = np.meshgrid(x, x, indexing='ij')
def grad(f): return np.gradient(f, dx, axis=0, edge_order=2), np.gradient(f, dx, axis=1, edge_order=2)
rho = 2.0 + 0.4 * np.sin(1.3 * T + 0.6 * Rr) + 0.2 * T * Rr
Pf = 0.3 * np.cos(T - 0.8 * Rr) + 0.1 * Rr
Qf = 0.5 * np.sin(0.7 * T + Rr)
Ff = lambda r: r ** 2 + 0.3 * r; F1 = lambda r: 2 * r + 0.3; F2 = lambda r: 2 + 0 * r
Uf = lambda r: 0.5 + 0.2 * r
Wf = lambda r: 1.0 + 0.3 * r ** 2
Vf = lambda r: 0.4 + 0.1 * r
# base inverse metric h^{ab} = h0 + eps*delta
def hinv0():
    a = 0.15 * np.sin(T + 0.3 * Rr); b = 0.1 * np.cos(0.5 * T - Rr); c = 0.08 * np.sin(Rr + 0.4 * T)
    hu = np.zeros((2, 2) + T.shape)
    hu[0, 0] = -np.exp(-2 * a) * (1 + 0.1 * b); hu[1, 1] = np.exp(-2 * a) * (1 - 0.05 * c); hu[0, 1] = hu[1, 0] = 0.12 * c
    return hu
bump = np.exp(-((T / 0.55) ** 2 + (Rr / 0.5) ** 2) ** 2)        # compact-ish support, vanishing at edges
def metric_stuff(hu):
    det_u = hu[0, 0] * hu[1, 1] - hu[0, 1] ** 2
    hl = np.zeros_like(hu); hl[0, 0] = hu[1, 1] / det_u; hl[1, 1] = hu[0, 0] / det_u; hl[0, 1] = hl[1, 0] = -hu[0, 1] / det_u
    sq = 1 / np.sqrt(np.abs(det_u))
    return hl, sq
def christoffel(hl, hu):
    d = np.zeros((2, 2, 2) + T.shape)    # d[k,a,b]=d_k h_ab
    for a in range(2):
        for b in range(2):
            gt, gr = grad(hl[a, b]); d[0, a, b] = gt; d[1, a, b] = gr
    Gam = np.zeros((2, 2, 2) + T.shape)
    for l in range(2):
        for m in range(2):
            for n in range(2):
                Gam[l, m, n] = sum(0.5 * hu[l, s] * (d[m, s, n] + d[n, s, m] - d[s, m, n]) for s in range(2))
    return Gam
def action(eps, dh):
    hu = hinv0() + eps * dh
    hl, sq = metric_stuff(hu)
    Gam = christoffel(hl, hu)
    # Ricci scalar in 2D: R = h^{ab}(d_l Gam^l_ab - d_b Gam^l_al + Gam Gam - Gam Gam)
    dG = np.zeros((2, 2, 2, 2) + T.shape)
    for l in range(2):
        for m in range(2):
            for n in range(2):
                gt, gr = grad(Gam[l, m, n]); dG[0, l, m, n] = gt; dG[1, l, m, n] = gr
    Rs = 0
    for a in range(2):
        for b in range(2):
            ric = sum(dG[l, l, a, b] for l in range(2)) - sum(dG[b, l, a, l] for l in range(2)) \
                + sum(Gam[l, l, s] * Gam[s, a, b] for l in range(2) for s in range(2)) \
                - sum(Gam[l, b, s] * Gam[s, a, l] for l in range(2) for s in range(2))
            Rs = Rs + hu[a, b] * ric
    rt, rr = grad(rho); pt, pr = grad(Pf); qt, qr = grad(Qf)
    rg = [rt, rr]; pg = [pt, pr]; qg = [qt, qr]
    X = sum(hu[a, b] * rg[a] * rg[b] for a in range(2) for b in range(2))
    G = sum(hu[a, b] * (pg[a] * pg[b] + np.exp(2 * Pf) * qg[a] * qg[b]) for a in range(2) for b in range(2))
    L = Ff(rho) * Rs + Uf(rho) * X - 0.5 * Wf(rho) * G + Vf(rho)
    return np.sum(sq * L) * dx * dx
def Eab_pred():
    hu = hinv0(); hl, sq = metric_stuff(hu); Gam = christoffel(hl, hu)
    rt, rr = grad(rho); pt, pr = grad(Pf); qt, qr = grad(Qf)
    rg = [rt, rr]; pg = [pt, pr]; qg = [qt, qr]
    Fv = Ff(rho); Ft, Fr = grad(Fv); Fg = [Ft, Fr]
    # second covariant derivative of F
    ddF = np.zeros((2, 2) + T.shape)
    for a in range(2):
        for b in range(2):
            fa = Fg[a]; ga = grad(fa)
            ddF[a, b] = ga[b] - sum(Gam[l, a, b] * Fg[l] for l in range(2))
    box = sum(hu[a, b] * ddF[a, b] for a in range(2) for b in range(2))
    X = sum(hu[a, b] * rg[a] * rg[b] for a in range(2) for b in range(2))
    Gab = np.zeros((2, 2) + T.shape)
    for a in range(2):
        for b in range(2):
            Gab[a, b] = pg[a] * pg[b] + np.exp(2 * Pf) * qg[a] * qg[b]
    Gtr = sum(hu[a, b] * Gab[a, b] for a in range(2) for b in range(2))
    E = np.zeros((2, 2) + T.shape)
    for a in range(2):
        for b in range(2):
            E[a, b] = hl[a, b] * box - ddF[a, b] + Uf(rho) * (rg[a] * rg[b] - 0.5 * hl[a, b] * X) \
                - 0.5 * Wf(rho) * (Gab[a, b] - 0.5 * hl[a, b] * Gtr) - 0.5 * hl[a, b] * Vf(rho)
    return E, sq
E, sq = Eab_pred()
eps = 2e-3
for (a, b) in [(0, 0), (1, 1), (0, 1)]:
    dh = np.zeros((2, 2) + T.shape); dh[a, b] = bump
    if a != b: dh[b, a] = bump
    num = (action(eps, dh) - action(-eps, dh)) / (2 * eps)
    fac = 2 if a != b else 1
    pred = np.sum(sq * E[a, b] * bump) * dx * dx * fac
    print(f"  delta h^{a}{b}: numerical dS/deps = {num:+.6f}   int sqrt(-h) E_ab dh^ab = {pred:+.6f}   rel.err = {abs(num-pred)/abs(pred):.1e}")
