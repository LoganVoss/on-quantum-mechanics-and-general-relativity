#!/usr/bin/env python3
"""Exact Weyl-frame counterexample and generic nonabelian Lax-jet checks."""
from pathlib import Path
import json
import sympy as s
import numpy as np
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'evidence'
t,r,phi,z=s.symbols('t r phi z', real=True);g=s.Function('g')(r)
coords=[t,r,phi,z]
metric=s.diag(-s.exp(g),s.exp(g),r*r,1); inv=metric.inv();N=4
Gam=[[[s.simplify(sum(inv[i,l]*(s.diff(metric[l,k],coords[j])+s.diff(metric[l,j],coords[k])-s.diff(metric[j,k],coords[l]))/2 for l in range(N))) for k in range(N)] for j in range(N)] for i in range(N)]
Ric=s.zeros(4)
for i in range(N):
 for j in range(N):
  Ric[i,j]=s.simplify(sum(s.diff(Gam[k][i][j],coords[k])-s.diff(Gam[k][i][k],coords[j])+sum(Gam[k][k][l]*Gam[l][i][j]-Gam[k][j][l]*Gam[l][i][k] for l in range(N)) for k in range(N)))
assert s.simplify(Ric[0,0]+Ric[1,1]-s.diff(g,r)/r)==0
scalar=s.simplify(sum(inv[i,j]*Ric[i,j] for i in range(N) for j in range(N)))
assert s.simplify(scalar+s.exp(-g)*s.diff(g,r,2))==0
# Generic noncommuting tangent currents at M=I, not an abelian seed.
rng=np.random.default_rng(20261111); residual=0.;minimum_comm=np.inf
for _ in range(256):
 p,q,rr,ss=rng.normal(size=4)
 Jp=np.array([[p,q],[q,-p]]);Jm=np.array([[rr,ss],[ss,-rr]])
 C=Jp@Jm-Jm@Jp
 minimum_comm=min(minimum_comm,np.linalg.norm(C))
 up,um=rng.normal(size=2);spc=rng.uniform(.05,.65)
 a=1/(1-spc);b=1/(1+spc)
 sp=spc*(1+spc)/(1-spc)*up
 sm=spc*(1-spc)/(1+spc)*um
 X=-(up*Jm+um*Jp+C)/2
 Y=-(up*Jm+um*Jp-C)/2
 curvature=-sp/(1+spc)**2*Jm+b*X-sm/(1-spc)**2*Jp-a*Y+a*b*C
 residual=max(residual,float(np.max(np.abs(curvature))))
assert residual<1e-11
out={'ricci_for_gamma_deformation':[[str(Ric[i,j]) for j in range(4)] for i in range(4)],'ricci_trace':str(scalar),'identity_Rtt_plus_Rrr':'gamma_prime/R','compact_frame_change':'U_eta=a/(2rho)+2 a eta B_prime; h_eta=exp(-2 eta B) h_0','same_shape_Lax_and_boundary_data':True,'generic_nonabelian_Lax_jet_tests':256,'max_Lax_curvature_entry':residual,'minimum_commutator_norm':float(minimum_comm),'scope':'Conformal frames related by a 2D field redefinition; they give different 4D metrics under the fixed literal-block dictionary.'}
(OUT/'frame_freedom_summary.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
