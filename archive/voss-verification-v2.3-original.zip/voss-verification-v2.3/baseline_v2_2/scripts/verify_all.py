#!/usr/bin/env python3
"""Rerun supplied audits and this supplement's executable certificates."""
from pathlib import Path
import hashlib, json, subprocess, sys, time
ROOT=Path(__file__).resolve().parents[1]; OUT=ROOT/'evidence';OUT.mkdir(exist_ok=True)
commands=[('source_audit',s) for s in ('geom_checks.py','selection_checks.py','extra_checks.py','pde_repro.py')]+[('scripts',s) for s in ('verify_integrability.py','verify_foundations.py','verify_frame_freedom.py','verify_corrected_boundary.py')]
records=[]
for directory,script in commands:
    start=time.perf_counter()
    run=subprocess.run([sys.executable,script],cwd=ROOT/directory,text=True,capture_output=True,timeout=180)
    label=('audit_' if directory=='source_audit' else '')+Path(script).stem
    (OUT/(label+'.log')).write_text(run.stdout+run.stderr)
    record={'script':directory+'/'+script,'returncode':run.returncode,'seconds':time.perf_counter()-start,'source_sha256':hashlib.sha256((ROOT/directory/script).read_bytes()).hexdigest()}
    records.append(record)
    print(f"{record['script']}: exit {run.returncode}",flush=True)
    if run.returncode:
        print(run.stdout+run.stderr);(OUT/'run_manifest.json').write_text(json.dumps(records,indent=2));sys.exit(run.returncode)
(OUT/'run_manifest.json').write_text(json.dumps(records,indent=2))
print('All executable scripts completed. Analytical scope and uncompiled Lean status remain in CLAIM_LEDGER.md.')
