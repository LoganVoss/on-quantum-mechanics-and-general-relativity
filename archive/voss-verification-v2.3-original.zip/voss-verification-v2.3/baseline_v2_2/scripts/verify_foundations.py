#!/usr/bin/env python3
"""Exact finite certificates and a continuum-cutoff benchmark in polarized Fock space."""
from pathlib import Path
import sympy as s
import numpy as np
import json,csv
from scipy.integrate import quad
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'evidence';OUT.mkdir(exist_ok=True)
# Exact single-chart coefficient certificate, independent of floating point SVD.
powers=list(range(-2,5)); m=len(powers)
r=s.symbols('r',positive=True)
def row(t,x):
    rho=t*x; sig=t*t+x*x
    vv=s.Matrix([[rho**j for j in powers]])
    v1=s.Matrix([[s.diff(r**j,r).subs(r,rho) for j in powers]])
    v2=s.Matrix([[s.diff(r**j,r,2).subs(r,rho) for j in powers]])
    return s.Matrix.vstack(s.Matrix.hstack(-t*t*v2,sig*vv/2,-sig*vv/(4*rho*rho),vv/2),s.Matrix.hstack(-x*x*v2,sig*vv/2,-sig*vv/(4*rho*rho),-vv/2),s.Matrix.hstack(-(rho*v2+v1),rho*vv,vv/(2*rho),s.zeros(1,m)))
A=s.Matrix.vstack(*[row(s.Rational(t),s.Rational(x)) for t in [1,2,3,4] for x in [1,2,3]])
rank=A.rank(); null=A.nullspace();assert rank==26 and len(null)==2
vE=s.zeros(4*m,1);vB=s.zeros(4*m,1)
vE[powers.index(1)]=1;vE[m+powers.index(-1)]=s.Rational(1,2);vE[2*m+powers.index(1)]=1
vB[powers.index(0)]=1
assert A*vE==s.zeros(A.rows,1) and A*vB==s.zeros(A.rows,1)
# Parity-odd local term. Sign changes with orientation, zero condition does not.
t,x=s.symbols('t x',positive=True); k=s.Function('k');rho=t*x;P=s.log(t/x)
odd=s.simplify(2*s.exp(P)*s.diff(k(rho),rho) if False else 2*s.exp(P)*s.Subs(s.Derivative(k(r),r),r,rho)*(s.diff(rho,t)*s.diff(P,x)-s.diff(rho,x)*s.diff(P,t)))
# Frame conversion and signature: block determinant exact.
u,v,area=s.symbols('u v area', positive=True)
M=s.Matrix([[1,u],[u,u*u+v*v]])/v
assert s.simplify(M.det()-1)==0
# finite oscillator truncation is not an exact canonical representation.
N=5
ann=s.zeros(N)
for j in range(1,N): ann[j-1,j]=s.sqrt(j)
Q=(ann+ann.T)/s.sqrt(2);PP=(ann-ann.T)/(s.I*s.sqrt(2))
expected=s.eye(N);expected[N-1,N-1]-=N
assert s.simplify(Q*PP-PP*Q-s.I*expected)==s.zeros(N)
# Polarized continuum benchmark on one-particle L2(R+,dk).
# A common-Fock frequency cutoff is omega_L(k)=min(k,L), not a finite-matrix surrogate.
beta=0.7;kappa=0.3;hbar=1.;T=1.1
q_exact=beta/(beta+kappa*hbar)
rows=[]
for cutoff in [0.5,1.,2.,4.,8.,16.]:
    q_formula=q_exact+kappa*hbar/(beta+kappa*hbar)*np.exp(-(beta+kappa*hbar)*cutoff)
    q_quad=quad(lambda k: beta*np.exp(-beta*k-kappa*hbar*min(k,cutoff)),0,cutoff,epsabs=1e-13)[0]+np.exp(-(beta+kappa*hbar)*cutoff)
    H=lambda k:-np.expm1(-kappa*hbar*k)/kappa
    # Difference is identically zero below cutoff. Integrate the probability-weighted tail.
    err2=quad(lambda k: beta*np.exp(-beta*k)*abs(np.exp(-1j*T*H(cutoff)/hbar)-np.exp(-1j*T*H(k)/hbar))**2,cutoff,np.inf,epsabs=1e-14,limit=200)[0]
    bound=T/(hbar*kappa)*np.exp(-(beta/2+kappa*hbar)*cutoff)
    assert abs(q_formula-q_quad)<1e-11
    assert np.sqrt(err2)<=bound+1e-12
    rows.append({'cutoff':cutoff,'opening_expectation':q_formula,'opening_error':q_formula-q_exact,'unitary_state_error':float(np.sqrt(err2)),'rigorous_tail_bound':bound})
with (OUT/'polarized_continuum_cutoff.csv').open('w',newline='') as f:
    wr=csv.DictWriter(f,fieldnames=rows[0].keys());wr.writeheader();wr.writerows(rows)
result={'single_chart_exact_matrix_shape':list(A.shape),'single_chart_exact_rank':rank,'single_chart_exact_nullity':len(null),'nullspace_is_exact_Einstein_plus_Euler':True,'parity_odd_Q_variation':str(odd),'finite_CCR_defect':'[Q_N,P_N]=i(I-N |N-1><N-1|)','covariance_unit_determinant':True,'polarized_continuum_cutoff':rows,'scope':'Polarized field cutoff removal and exact finite algebra. No interacting quantum continuum is claimed.'}
(OUT/'foundations_summary.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
