#!/usr/bin/env python3
"""Exact, scoped Lax-selection certificates and independent path-order tests.
No claim is made that every possible Lax representation has this ansatz.
"""
from pathlib import Path
import csv, json
import numpy as np
import sympy as sp
from scipy.integrate import solve_ivp

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'evidence'; OUT.mkdir(exist_ok=True)
s, u, v, g, E = sp.symbols('s u v g E')
A = s*(1+s)/(1-s)
B = s*(1-s)/(1+s)
a, b = 1/(1-s), 1/(1+s)
checks = {}
def zero(name, expr):
    expr=sp.factor(sp.cancel(expr)); checks[name]={'residual':str(expr), 'passed':expr==0}
    if expr != 0: raise AssertionError((name,expr))
zero('commutator_coefficient', 2*a*b-a-b)
zero('J_plus_coefficient', -sp.diff(a,s)*B*v+(a-b)*v/2)
zero('J_minus_coefficient', sp.diff(b,s)*A*u+(a-b)*u/2)
# g = (log W)_{+-}, u=(log W)_+, v=(log W)_-.
frob = sp.factor((sp.diff(A,s)*B-sp.diff(B,s)*A)*u*v+(A-B)*g)
zero('Frobenius_factor', frob-4*s**2/(1-s**2)*(g+u*v))
# If g = W_{+-}/W - uv, the obstruction is proportional to W_{+-}/W.
wp, wm, wpm, W = sp.symbols('wp wm wpm W', nonzero=True)
zero('Frobenius_weight_form', frob.subs({u:wp/W,v:wm/W,g:wpm/W-wp*wm/W**2})-4*s**2/(1-s**2)*wpm/W)
# Explicit implicit spectral curve: w = Wdual + W*(s+1/s)/2.
zero('spectral_curve_plus', wp+wp*(s+1/s)/2+W*(1-1/s**2)*A*(wp/W)/2)
zero('spectral_curve_minus', -wm+wm*(s+1/s)/2+W*(1-1/s**2)*B*(wm/W)/2)
# Chain-rule obstruction when rho is harmonic.
rho,n,c,rp,rm=sp.symbols('rho n c rp rm', positive=True)
power_weight=c*rho**n
power_d2=sp.diff(power_weight,rho,2)
zero('power_second_derivative', power_d2-c*n*(n-1)*rho**(n-2))
# Trace equation: F' box rho + F'' X - V = 0.
Fp,Fpp,Wp,Wpp,X,V=sp.symbols('Fp Fpp Wp Wpp X V', nonzero=True)
boxW=Wp*(V-Fpp*X)/Fp+Wpp*X
zero('coupled_trace_obstruction', boxW-(Wp/Fp*V+(Wpp-Wp*Fpp/Fp)*X))
# Single-chart result at fixed rho: two distinct d=t^2-r^2 values.
f2,pot,d1,d2=sp.symbols('f2 pot d1 d2')
zero('single_chart_difference', (pot-f2*d1)-(pot-f2*d2)-f2*(d2-d1))
a0,rr=sp.symbols('a0 rr',positive=True)
UU,WW=sp.symbols('UU WW')
sol=sp.solve([UU-WW/(2*rr**2),-a0+rr*UU+WW/(2*rr)], [UU,WW])
zero('selected_U',sol[UU]-a0/(2*rr));zero('selected_W',sol[WW]-a0*rr)
# Counterexample to uniqueness of full dynamics: U drops from the trace.
t00,t11,rr0,rr1,gg00,gg11=sp.symbols('t00 t11 rr0 rr1 gg00 gg11')
XX=-rr0**2+rr1**2
Utrace=-(rr0**2+XX/2)+(rr1**2-XX/2)
zero('U_kinetic_trace_zero',Utrace)

# Numeric checks of Frobenius obstruction at regular values.
power_rows=[]
for exponent in [-2,-1,0,0.5,1,1.5,2,3]:
    R=1.3; ss=0.23
    val=-4*ss**2/(1-ss**2)*exponent*(exponent-1)/R**2
    power_rows.append({'n':exponent,'R':R,'spectral_s':ss,'frobenius_defect':float(val)})
with (OUT/'lax_power_scan.csv').open('w',newline='') as f:
    wr=csv.DictWriter(f,fieldnames=power_rows[0].keys());wr.writeheader();wr.writerows(power_rows)

# Integrate the scalar spectral-parameter system along two rectangular paths.
# W=R^n, ∂±=∂T±∂R. A path-independent spectral parameter requires Frobenius closure.
def path_value(exponent, order, dt=.12,dr=.09):
    T,R,ss=.2,1.3,.23
    for axis in order:
        if axis=='T':
            fun=lambda x,y: [2*exponent*y[0]**2/(R*(1-y[0]**2))]
            res=solve_ivp(fun,[T,T+dt],[ss],rtol=2e-12,atol=1e-14)
            T+=dt
        else:
            fun=lambda x,y: [exponent*y[0]*(1+y[0]**2)/(x*(1-y[0]**2))]
            res=solve_ivp(fun,[R,R+dr],[ss],rtol=2e-12,atol=1e-14)
            R+=dr
        if not res.success: raise RuntimeError(res.message)
        ss=float(res.y[0,-1])
    return ss
path_rows=[]
for exponent in [0,.5,1,1.5,2]:
    tr=path_value(exponent,'TR'); rt=path_value(exponent,'RT')
    path_rows.append({'n':exponent,'s_TR':tr,'s_RT':rt,'absolute_path_difference':abs(tr-rt)})
with (OUT/'spectral_path_tests.csv').open('w',newline='') as f:
    wr=csv.DictWriter(f,fieldnames=path_rows[0].keys());wr.writeheader();wr.writerows(path_rows)
assert path_rows[0]['absolute_path_difference']<1e-10
assert path_rows[2]['absolute_path_difference']<1e-10
assert all(row['absolute_path_difference']>1e-7 for row in path_rows if row['n'] not in [0,1])

summary={'scope':'classical local scalar-current rational Lax ansatz; not all integrability mechanisms',
'exact_checks':checks,'exact_checks_passed':sum(x['passed'] for x in checks.values()),
'frobenius_identity':str(frob),'power_law_candidates':[0,1],
'axis_vanishing_selects':1,'path_order_tests':path_rows}
(OUT/'integrability_summary.json').write_text(json.dumps(summary,indent=2))
print(json.dumps(summary,indent=2))
