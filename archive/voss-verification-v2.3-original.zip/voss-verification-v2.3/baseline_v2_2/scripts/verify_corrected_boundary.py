#!/usr/bin/env python3
"""Re-evolve the audit's benchmark after imposing zero asymptotic twist.
Uses the supplied independent finite-difference implementation unchanged except
for the explicitly reported initial-velocity counterterm. One continuum coefficient
is used on every grid; it is not retuned per grid.
"""
from pathlib import Path
import json,csv
import numpy as np
from scipy.integrate import quad, trapezoid
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'evidence'
ns={}
source=(ROOT/'source_audit'/'pde_repro.py').read_text()
exec(compile(source.split('res = {}')[0],'supplied_pde_functions','exec'),ns)
original=ns['data']
def scalar_parts(r):
    psi,chi,pt,ct=original(np.array(r))
    w=r*np.exp(-2*psi)
    return float(w*ct),float(w*np.exp(-(r/1.2)**2))
num,nerr=quad(lambda r: scalar_parts(r)[0],0,np.inf,epsabs=1e-13,epsrel=1e-12)
den,derr=quad(lambda r: scalar_parts(r)[1],0,np.inf,epsabs=1e-13,epsrel=1e-12)
cstar=-num/den
corrected_twist,qerr=quad(lambda r: scalar_parts(r)[0]+cstar*scalar_parts(r)[1],0,np.inf,epsabs=1e-13,epsrel=1e-12)
def corrected(R):
    psi,chi,pt,ct=original(R)
    return psi,chi,pt,ct+cstar*np.exp(-(R/1.2)**2)
ns['data']=corrected
rows=[];states={}
for N in [128,256,512,1024]:
    R,y,g0,g1,dR=ns['run'](N)
    initial=np.asarray(corrected(R))
    twist0=trapezoid(R*np.exp(-2*initial[0])*initial[3],R)
    twist1=trapezoid(R*np.exp(-2*y[0])*y[3],R)
    row={'intervals':N,'gamma_initial':float(g0[-1]),'gamma_final':float(g1[-1]),'relative_energy_drift':float(abs(g1[-1]-g0[-1])/g0[-1]),'max_exp_gamma':float(np.exp(g1.max())),'initial_discrete_twist':float(twist0),'final_discrete_twist':float(twist1),'twist_drift':float(twist1-twist0)}
    rows.append(row);states[N]=(R,y)
    np.savez_compressed(OUT/f'corrected_evolution_{N}.npz',R=R,psi=y[0],chi=y[1],psi_T=y[2],chi_T=y[3],gamma=g1)
orders=[]
for N in [128,256]:
    a=states[N][1][0];b=states[2*N][1][0][::2];c=states[4*N][1][0][::4]
    orders.append({'coarse_grid':N,'observed_order':float(np.log2(np.linalg.norm(a-b)/np.linalg.norm(b-c)))})
with (OUT/'corrected_boundary_convergence.csv').open('w',newline='') as f:
    wr=csv.DictWriter(f,fieldnames=rows[0].keys());wr.writeheader();wr.writerows(rows)
report={'correction_formula':'chi_T -> chi_T + c_star exp[-(R/1.2)^2]','c_star':cstar,'original_continuum_twist':num,'corrected_continuum_twist':corrected_twist,'quadrature_error_estimate':qerr,'same_coefficient_on_all_grids':True,'rows':rows,'orders':orders,'scope':'Finite-domain classical nonlinear convergence. A(infinity)=0 is a chosen global boundary sector, not inferred from local equations.'}
(OUT/'corrected_boundary_summary.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
