# Formal verification status

**Lean compilation was requested and attempted, but NOT completed in this session.**

The current build receipt is evidence/lean/build_receipt.json. Its status is `blocked`, not `passed`. The compiler driver exited 78 because neither `lean` nor `lake` exists. Network downloads failed DNS resolution and direct connection attempts. The GitHub plugin was confirmed installed after the user connected it, but the available tool discovery exposed no repository or Actions operations, and no authenticated GitHub CLI was present. No remote repository was read, created, or changed; no Actions run was submitted. Connection is not being disputed.

## Defects corrected in the package

* The v2.2 workflow ran Python only. It did not invoke any Lean compiler.
* Optional Mathlib proofs from the earlier nonlinear package were outside its Std-only default build.
* Proof coverage and compilation receipts were not machine-readable across the bundle sequence.
* Several independent Python audit scripts printed residuals but did not themselves fail when tolerances were violated.

The new workflow has separate required Python and Lean jobs and a final gate that rejects either job's failure. All six proof modules are imported and built. The toolchain is Lean 4.19.0; Mathlib is pinned to commit c44e0c8ee63ca166450922a373c7409c5d26b00b, the official v4.19.0 release commit. Dependency revisions and source hashes are archived in a successful receipt.

## What the formal source represents

38 named theorem declarations are inventoried in machine/theorems.json. The original five proof files are preserved byte-for-byte in archive_sources/ and copied into the new project. Eight new algebraic lemmas isolate the single-chart argument, the regular Lax obstruction, the probe-frame inference, and related identities. They are SOURCE, not currently kernel-verified results.

The source does not formalize the full variational calculus, all Ricci components, the interacting continuum, global causality, or a full nonperturbative gravitational equivalence. Some statements assume exactly the algebraic variation identities that the analytical paper derives. A Lean success for those statements would check the consequences of the hypotheses, not automatically check their physical origin.

## Reproduce on a capable machine

Install the official Lean toolchain manager, then from this repository root run:

    python scripts/compile_lean.py --fetch-deps

The driver will check versions, fetch the pinned Mathlib dependency, delete this project's stale build outputs, build every proof module, query the axioms of every inventoried theorem, and require rejection of an intentionally false control. It writes `passed` only after all those checks succeed. Missing tools, missing theorem reports, unexpected axioms, or incomplete objects cause nonzero exits.

The only permitted standard logical axioms are propext, Quot.sound, and Classical.choice. Each theorem's actual dependencies are recorded. No `sorry`, `admit`, custom axiom declaration, unsafe declaration, or native_decide occurs in the project's proof source. A static scan is NOT a substitute for elaboration and kernel checking.

Optional replay of compiled declarations through an installed matching lean4checker is available using:

    python scripts/compile_lean.py --replay /absolute/path/to/lean4checker

The replay is reported separately. The normal build receipt does not claim an independent prover or a second kernel when it has only run Lean's compiler.

## Cross-computer communication

Exchange the source, pinned toolchain, dependency lock, theorem inventory, build receipt, source hashes, and logs. Re-run the compiler on the receiving computer. Do not treat a green Python job, a PDF sentence, a .olean filename, or an unsigned JSON claim as a substitute for that verification. Hashes detect changed bytes; they do not by themselves prove the producer was honest.
