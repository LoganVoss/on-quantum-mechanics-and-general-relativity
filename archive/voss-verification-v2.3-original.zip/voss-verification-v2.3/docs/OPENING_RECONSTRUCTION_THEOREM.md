# Opening-first reconstruction of a continuum generator

## Scope
This is an operator-theoretic equivalence on one specified Hilbert space. It does not construct the interacting gravitational field, its local observable algebra, or its constraint representation. A sequence on changing lattice Hilbert spaces must first be transported to a common space by specified compatible identifications. It preserves, rather than linearizes, the nonlinear physical energy map.

## Theorem 1: reconstruction from one bounded opening
Let kappa > 0. Nonnegative densely defined self-adjoint operators K correspond bijectively to bounded positive contractions L with ker(L) = {0}, through

    L = exp(-kappa K),       K = -log(L)/kappa.

The logarithm uses Borel spectral calculus and can be unbounded. Zero may be in the continuous spectrum; absence of a zero eigenvector, not a positive spectral gap, is required. The domain is dense precisely because the zero spectral projection vanishes.

For a sequence K_n >= 0 define L_n = exp(-kappa K_n). Suppose L_n converges strongly to L. Then K_n has a nonnegative self-adjoint strong-resolvent limit if and only if ker(L) = {0}; the limit is K = -log(L)/kappa.

Proof. For lambda > 0 define

    f_lambda(x) = 1 / (lambda - log(x)/kappa),  x > 0;
    f_lambda(0) = 0.

This is continuous on [0,1]. Strong convergence of uniformly bounded self-adjoint contractions implies strong convergence of their continuous functional calculus. Hence

    (K_n+lambda)^(-1) = f_lambda(L_n) -> f_lambda(L) = (K+lambda)^(-1).

Conversely, strong-resolvent convergence K_n -> K implies strong convergence exp(-kappa K_n) -> exp(-kappa K). The latter has trivial kernel, so the given limit L is injective. QED.

## Theorem 2: informational sufficient conditions
Suppose all matrix elements of L_n on a dense linear set converge to the matrix elements of a positive contraction L. Suppose also, on a total set of test vectors psi,

    <psi, L_n^2 psi> -> <psi, L^2 psi>.

The uniform norm bound and density extend the first condition to weak-operator convergence. Then

    ||(L_n-L)psi||^2
      = <psi,L_n^2 psi> - 2 Re <L_n psi,L psi> + ||L psi||^2 -> 0.

Uniform boundedness extends strong convergence to all vectors. The square in the measured condition is the operator square, NOT the square of an expectation value. Off-diagonal matrix elements can be encoded by expectation values on superpositions through polarization. A finite list of tests does not establish these universal hypotheses.

## No-loss condition
A practical sufficient condition excluding a kernel in L is a dense set D with uniformly bounded auxiliary mean energies:

    sup_n <psi,K_n psi> <= C_psi < infinity,  psi in D.

Then for 0 < delta < 1,

    <psi, 1_[0,delta](L_n) psi>
       <= kappa C_psi / |log(delta)|.

This is spectral Markov inequality. Uniform suppression of small-opening spectral weight, followed by the strong limit and density, excludes a nonzero kernel. It is a condition to prove or test with controlled bounds, not a consequence of positivity alone.

## Nonlinear physical evolution
With H_n=(I-L_n)/kappa and H=(I-L)/kappa, strong convergence gives H_n -> H. Since all are bounded by 1/kappa, the power-series expansion gives strong convergence of exp(-it H_n/hbar), uniformly for t in compact intervals. No coupling expansion is used in the definitions.

## Saturation controls
If K_n=nI, then L_n -> 0 and H_n -> I/kappa. There is no densely defined finite-energy self-adjoint K corresponding to L=0. This is loss of the entire finite-energy Hilbert space, not a successful interacting continuum.

If K_n=diag(0,1,n), the two low levels look perfectly stable but the third is lost. A check confined to the first two levels misses the failure.

In contrast, K_n=n|n><n| on l2 has K_n -> 0 in strong resolvent and L_n -> I strongly even though ||K_n|| diverges. Uniform operator-norm energy bounds are unnecessarily strong; vector-wise spectral control is the relevant requirement.

## Conditioning
On a common spectral window L_n,L >= delta I > 0, the resolvent integral for log gives

    ||K_n-K|| <= ||L_n-L|| / (kappa delta).

Small opening values amplify reconstruction errors. The theorem is exact but does not supply cost-free access to high auxiliary energies.

## Status
The proofs above are analytical. Finite noncommuting numerical examples, exact polarization algebra, saturation controls, and 256 spectral-tail checks were executed in verify_new_routes.py. The operator theorem is not formalized in Lean here. No novelty priority is claimed.
