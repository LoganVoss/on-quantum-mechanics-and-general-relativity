# Research sweep: established structure, surviving ambiguities, and concrete routes

Scope: the supplied gravitational research chain from finite anchor tomography through nonlinear Einstein-Rosen reconstruction, action selection, and the v2.2 Lax/continuum supplement. This is not an account-wide audit of unrelated SHA or application projects.

| Layer | What survives the sweep | Boundary or defect | Concrete response |
|---|---|---|---|
| Finite quantum anchors | Exact inverse and missing-anchor witness | Support and complete operator map are inputs | Preserve full operator words before compression; use held-out dynamical tests |
| Canonical pair | Weyl/Schrodinger model and covariance reconstruction | Finite matrices cannot realize exact CCR | Distinguish state-support cutoff from operator-algebra cutoff |
| Quantum shape | Positive unimodular covariance gives hyperbolic target | Probe-to-orbit correspondence, dimension and signature are supplied | Treat response/commutator measurements as additional anchors, not deductions from QFI |
| Flat-reference action | Single-chart selection in the declared local class | Physical frame, locality and derivative class remain premises | Stronger local algebra certificates; preserve the full premise list |
| Nonlinear geometry | Two-polarization field equations and gamma backreaction pass checks | Symmetry-restricted; not generic angular gravity | Keep independent profiles and zero-twist boundary conditions |
| Lax selector | Harmonic W, then affine W(rho) on generic non-null area | Constant branch, null-area exception and conformal frame remain | Axis condition for W; orbit-momentum probe for physical frame |
| Curvature-squared extensions | Vacuum references cannot distinguish them | 'No ghosts' alone is insufficient | Apply calibrated sourced response, not only vacuum backgrounds |
| Quantum regulator | Positive generators and nonlinear bounded physical evolution | Finite dimensions and unitarity do not imply continuum | Opening-first strong-limit theorem plus no-loss spectral tightness |
| Quantum renormalization | Reduced-gravity beta-function literature is directly relevant | Fixed classical functions need not be closed under quantum RG | Promote coupling functions to scale-dependent functions and test constraint/anomaly identities |
| Causality | Regular classical time function; regulated unitarity | Naive tensor-factor locality fails for nonlinear global energy | Use dressed relational observables and explicit detector/control operations |
| Thermal interpretation | Stationary states commuting with K can be defined | Bounded H on infinite H-space has divergent normal Gibbs trace | Specify finite-energy conditioning or an appropriate algebraic equilibrium problem; auxiliary Gibbs is not physical-H thermal |
| Formal verification | 38 declarations inventoried; fail-closed build configured | Compiler not available; GitHub actions not exposed this session | Do not upgrade status until a real build receipt exists |

## A sourced test for the derivative-order ambiguity
For the candidate action R + alpha R^2 with minimally coupled matter, its exact trace equation is

    -R + 6 alpha Box R = 8 pi G T  (c=1).

Thus Ricci-flat vacuum backgrounds solve both the alpha=0 and alpha!=0 theories. A calibrated traceful source distinguishes them. With alpha>0 the extra scalar mass is m_s^2=1/(6alpha). Ghost freedom does not remove this healthy extra scalar. This is an illustrative discriminator of supplied matter-coupling theories, not a proof that every higher-derivative completion is excluded.

## Causality negative control
Take two unconstrained tensor-factor qubits with K_A=epsilon|1><1| and K_B=epsilon|1><1|, and H=F(K_A+K_B), F(E)=(1-exp(-kappa E))/kappa. Prepare A in |+> and B in |b>. Then

    <X_A(t)>_b = cos[t F(epsilon) exp(-b kappa epsilon)/hbar].

For generic t the result depends immediately on b. This does not prove superluminal signalling in the actual constrained gravitational theory: the factorized preparations, clocks, and local operator assignments have not been justified there. It DOES disprove the shortcut 'bounded + unitary implies causal' for the naive tensor-factor interpretation.

## New routes versus promises

Proved conditional reductions in this supplement:
1. An injective strong limit of bounded openings reconstructs the nonnegative strong-resolvent generator; tomography of first and operator-square moments provides a sufficient convergence criterion.
2. A massless probe with calibrated nonzero orbit momentum identifies the previously invisible physical conformal multiplier under minimal coupling.
3. Source response distinguishes a representative curvature-squared extension; an exact two-qubit calculation supplies a causality negative control.

Not completed:
* Constructing the interacting radial quantum continuum and its anomaly-free physical constraints.
* Deriving spacetime dimension or Lorentzian signature from static probe states.
* Proving full AdS/CFT or every-state quantum-spacetime duality.
* Compiler verification of the Lean source in this session.

A particularly relevant prior route is Niedermaier's all-loop reduced-gravity renormalization program (hep-th/0304117). It enlarges essential couplings into functions and studies beta functionals. That is a concrete direction for matching the selected classical action to quantum scaling; it is not an external proof that the present lattice converges nonperturbatively.
