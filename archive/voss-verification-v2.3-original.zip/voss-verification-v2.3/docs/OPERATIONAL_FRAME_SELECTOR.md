# A probe that distinguishes Lax-equivalent conformal frames

Let

    g_sigma = e^(2 sigma(x)) h_ab(x) dx^a dx^b
              + rho(x) M_IJ(x) dy^I dy^J,
    rho > 0,  M > 0, det M = 1.

The base is two dimensional, the orbit frame is calibrated, and h, rho, M are held fixed while sigma changes. The previous Lax selector is insensitive to this freedom. Introduce a minimally coupled scalar test field of calibrated mass m and orbit momentum k:

    Phi(x,y) = phi(x) exp(i k_I y^I).

The exact homogeneous Klein-Gordon equation reduces to

    D0 phi - exp(2 sigma) V_k phi = 0,

where

    D0 = [rho sqrt(-h)]^(-1) partial_a[rho sqrt(-h) h^ab partial_b],
    V_k = m^2 + rho^(-1) M^IJ k_I k_J.

Derivation: sqrt(-g_sigma)=exp(2 sigma) rho sqrt(-h). In the base kinetic density, the exponential cancels against g_sigma^ab. It does not cancel from the mass and orbit-momentum terms. This computation does not linearize the gravitational background.

## Conditional uniqueness
If two candidate frames give the same reduced differential operator for a calibrated probe with V_k>0, then their conformal multipliers are equal. Wherever a measured homogeneous solution has phi != 0,

    exp(2 sigma) = D0 phi / (V_k phi).

Cover nodes with additional probe solutions. Noise, finite resolution, source normalization, and differentiation error must be modeled before using this formula experimentally.

For m=0 and k=0 the entire conformal ambiguity survives. For m=0 but k!=0, positive M implies V_k>0, so an otherwise massless four-dimensional probe becomes a massive probe on the two-dimensional quotient. The probe can carry angular momentum even while the gravitational background remains axisymmetric.

This is an operational selector of a supplied metric interpretation. It adds known minimal probe coupling and calibration. It does not derive matter or the equivalence principle from covariance alone. The probe is in the vanishing-amplitude test-field limit; the background retains full nonlinear backreaction. Full finite-amplitude matter backreaction is not proved here.

An independent ODE integration and five-point finite-difference reconstruction test is supplied. The operator identities were checked symbolically. This is a conditional construction, not an observed signal or a priority claim.
