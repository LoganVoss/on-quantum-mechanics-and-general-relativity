# License and provenance notice

The supplied manuscripts and four audit scripts are retained for research provenance. No new license or public redistribution permission is assigned to the user's material by this package. The new supplement and verification tooling were prepared for the Voss research program with AI assistance. Third-party scientific works are referenced, not bundled. Publication and licensing remain the research owner's decision.
