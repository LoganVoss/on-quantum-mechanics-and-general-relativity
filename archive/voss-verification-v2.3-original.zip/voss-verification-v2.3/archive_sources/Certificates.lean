import Mathlib

/- Small algebraic certificates only. Compiler unavailable in the authoring run.
   These do not formalize the Lax PDE, continuum limits, or Einstein equations. -/
namespace VossFoundations

theorem power_branches (n : ℝ) (h : n * (n - 1) = 0) :
    n = 0 ∨ n = 1 := by
  rcases mul_eq_zero.mp h with hn | hn
  · exact Or.inl hn
  · exact Or.inr (sub_eq_zero.mp hn)

theorem positive_power_branch (n : ℝ) (h : n * (n - 1) = 0)
    (hn : n ≠ 0) : n = 1 := by
  rcases power_branches n h with hz | ho
  · exact False.elim (hn hz)
  · exact ho

theorem lax_commutator_coefficient (s : ℝ)
    (hm : 1 - s ≠ 0) (hp : 1 + s ≠ 0) :
    2 * (1 / (1 - s)) * (1 / (1 + s)) -
      (1 / (1 - s) + 1 / (1 + s)) = 0 := by
  field_simp [hm, hp] <;> ring

theorem fixed_level_difference (f2 pot d1 d2 : ℝ)
    (h1 : pot = f2 * d1) (h2 : pot = f2 * d2) :
    f2 * (d1 - d2) = 0 := by
  nlinarith

end VossFoundations
