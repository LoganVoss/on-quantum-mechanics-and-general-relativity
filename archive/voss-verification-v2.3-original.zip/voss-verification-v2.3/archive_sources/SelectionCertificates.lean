/-
Finite certificates for conditional informational selection.
Lean 4.19.0, Std only. No added axioms or sorry declarations.
AUTHORING STATUS: source supplied; not compiler-verified in this environment.
The analytic logarithm/continuity theorem and the Einstein equations are in
paper/selection_note.tex and independently executed SymPy checks, not claimed
formalized by these finite certificates.
-/
import Std
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace VossSelection

/-- A formal contract: each physical predicate needs its own interpretation.
This record does not prove that quantum data supply a spacetime or gauge group. -/
structure FiveConditions (S : Type) where
  positiveBounded : S → Prop
  unitary : S → Prop
  classicalLorentzian : S → Prop
  freeLimit : S → Prop
  gaugeInvariant : S → Prop

def Admissible {S : Type} (c : FiveConditions S) (s : S) : Prop :=
  c.positiveBounded s ∧ c.unitary s ∧ c.classicalLorentzian s ∧
  c.freeLimit s ∧ c.gaugeInvariant s

/-- Two accepted structures cannot both be the unique accepted structure. -/
theorem nonunique_of_two {S : Type} (c : FiveConditions S) (a b : S)
    (ha : Admissible c a) (hb : Admissible c b) (hne : a ≠ b) :
    ¬ (∀ x y : S, Admissible c x → Admissible c y → x = y) := by
  intro h
  exact hne (h a b ha hb)

/-- Geometric sequence written with an arbitrary binary operation. -/
def iterProduct {A : Type} (mul : A → A → A) (one q : A) : Nat → A
  | 0 => one
  | n + 1 => mul (iterProduct mul one q n) q

/-- One calibration plus every adjacent composition step gives a unique sequence. -/
theorem unique_of_adjacent_composition {A : Type}
    (mul : A → A → A) (one q : A) (L : Nat → A)
    (h0 : L 0 = one) (hs : ∀ n, L (n + 1) = mul (L n) q) :
    ∀ n, L n = iterProduct mul one q n := by
  intro n
  induction n with
  | zero => exact h0
  | succ n ih =>
    calc
      L (n + 1) = mul (L n) q := hs n
      _ = mul (iterProduct mul one q n) q := congrArg (fun a => mul a q) ih
      _ = iterProduct mul one q (n + 1) := rfl

/-- The full composition law supplies the adjacent composition hypothesis. -/
theorem unique_of_full_composition {A : Type}
    (mul : A → A → A) (one q : A) (L : Nat → A)
    (h0 : L 0 = one) (h1 : L 1 = q)
    (hc : ∀ n m, L (n + m) = mul (L n) (L m)) :
    ∀ n, L n = iterProduct mul one q n := by
  apply unique_of_adjacent_composition mul one q L h0
  intro n
  calc
    L (n + 1) = mul (L n) (L 1) := hc n 1
    _ = mul (L n) q := congrArg (fun a => mul (L n) a) h1

/-- The cleared-denominator opening witness fixes L2 only after L1 is known.
This is integer algebra; its real-valued version is proved in the manuscript. -/
theorem witness_is_a_single_constraint (q p : Int) :
    (1 + p - 2*q = 1 + q*q - 2*q) ↔ p = q*q := by
  omega

/-- Polarizing two diagonal identities and their equally weighted mixture
recovers the cross term. The displayed square is explicitly expanded. -/
theorem polarization_step (a b c d e : Int)
    (hc : c = a*a) (he : e = b*b)
    (hm : c + 2*d + e = a*a + 2*(a*b) + b*b) : d = a*b := by
  omega

def openingA (n : Fin 3) : Int :=
  match n.val with | 0 => 36 | 1 => 18 | _ => 9

def openingB (n : Fin 3) : Int :=
  match n.val with | 0 => 36 | 1 => 9 | _ => 4

/-- Scaled finite values: both candidates satisfy the same interval bounds. -/
theorem finite_positive_bounded_A :
    ∀ n : Fin 3, 0 < openingA n ∧ openingA n ≤ 36 := by decide

theorem finite_positive_bounded_B :
    ∀ n : Fin 3, 0 < openingB n ∧ openingB n ≤ 36 := by decide

theorem finite_candidates_distinct : openingA 1 ≠ openingB 1 := by decide

theorem finite_A_composes : 36 * openingA 2 = openingA 1 * openingA 1 := by decide

theorem finite_B_does_not_compose :
    36 * openingB 2 ≠ openingB 1 * openingB 1 := by decide

#print axioms unique_of_adjacent_composition
#print axioms unique_of_full_composition
#print axioms witness_is_a_single_constraint
#print axioms polarization_step
#print axioms finite_positive_bounded_A
#print axioms finite_B_does_not_compose
end VossSelection
