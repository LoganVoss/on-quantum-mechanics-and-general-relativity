import Mathlib

/-!
Limited algebraic certificates for the ab-initio action-selection manuscript.
NOT compiler-verified in the authoring environment.
These statements do not formalize the variational derivation, Gaussian integrals,
functional classification, general relativity, or the quantum continuum.
-/
namespace VossAbInitio

/-- Denominator-cleared cylinder and Milne-polar calibration equations
    select the local kinetic coefficients at each strictly positive area. -/
theorem flatReferenceCoefficients
    (a u w r : ℝ) (hr : 0 < r)
    (hc : 2 * u * r ^ 2 - w = 0)
    (hm : -2 * a * r + 2 * u * r ^ 2 + w = 0) :
    w = a * r ∧ u = a / (2 * r) := by
  have hw : w = a * r := by nlinarith [hc, hm]
  have hz : (2 * u * r - a) * r = 0 := by nlinarith [hc, hw]
  have hlin : 2 * u * r - a = 0 :=
    (mul_eq_zero.mp hz).resolve_right (ne_of_gt hr)
  constructor
  · exact hw
  · apply (eq_div_iff (by positivity : (2 : ℝ) * r ≠ 0)).2
    nlinarith [hlin]

/-- The normalized minimum-uncertainty covariance has determinant one. -/
theorem covarianceDeterminant (u v : ℝ) (hv : v ≠ 0) :
    (1 / v) * ((u * u + v * v) / v) - (u / v) * (u / v) = 1 := by
  field_simp [hv] <;> ring

/-- Conditional discrete composition, not a continuum functional theorem. -/
theorem compositionSequence (L : ℕ → ℝ) (q : ℝ)
    (h0 : L 0 = 1) (hs : ∀ n, L (n + 1) = L n * q) :
    ∀ n, L n = q ^ n := by
  intro n
  induction n with
  | zero => simpa using h0
  | succ n ih => rw [hs, ih, pow_succ]

/-- One-dimensional algebra behind the preconditioned Lyapunov calculation. -/
theorem lyapunovDerivative (e v : ℝ) :
    v * (-2 * v - e) + e * v = -2 * v ^ 2 := by
  ring

/-- The selected normalized coefficients satisfy both cleared constraints. -/
example (r : ℝ) (hr : r ≠ 0) :
    2 * (1 / (2 * r)) * r ^ 2 - r = 0 := by
  field_simp [hr] <;> ring

end VossAbInitio
