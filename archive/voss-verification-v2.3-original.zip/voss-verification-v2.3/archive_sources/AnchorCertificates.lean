/-
Voss nonlinear geometry: finite exact certificates.
Lean 4.19.0, Std only. No sorry, added axioms, or native_decide.
Authoring status: source supplied; Lean compiler NOT available in this runtime.
This verifies finite integer algebra, not the Einstein equations or field quantization.
-/
import Std
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Voss
abbrev Index := Fin 9
abbrev Matrix9 := Index → Index → Int
abbrev Vector9 := Index → Int

def sum9 (f : Index → Int) : Int :=
  f 0 + f 1 + f 2 + f 3 + f 4 + f 5 + f 6 + f 7 + f 8

def mul (a b : Matrix9) (i j : Index) : Int :=
  sum9 (fun k => a i k * b k j)

def matVec (a : Matrix9) (v : Vector9) (i : Index) : Int :=
  sum9 (fun k => a i k * v k)

def A (i j : Index) : Int :=
  match i.val, j.val with
  | 0, 0 => 1
  | 0, 1 => 1
  | 0, 2 => 1
  | 1, 3 => 2
  | 1, 5 => 2
  | 2, 4 => 2
  | 2, 6 => 2
  | 3, 0 => 1
  | 3, 1 => 3
  | 3, 2 => 5
  | 3, 7 => 2
  | 4, 0 => 1
  | 4, 1 => 3
  | 4, 2 => 5
  | 4, 8 => 2
  | 5, 0 => 1
  | 5, 1 => 3
  | 5, 2 => 5
  | 5, 7 => -2
  | 6, 3 => 6
  | 6, 5 => 12
  | 7, 4 => 6
  | 7, 6 => 12
  | 8, 0 => 3
  | 8, 1 => 15
  | 8, 2 => 39
  | 8, 7 => 12
  | _, _ => 0

def B (i j : Index) : Int :=
  match i.val, j.val with
  | 0, 0 => 21
  | 0, 3 => -9
  | 0, 5 => -3
  | 0, 8 => 1
  | 1, 0 => -12
  | 1, 3 => 15
  | 1, 5 => 3
  | 1, 8 => -2
  | 2, 0 => 3
  | 2, 3 => -6
  | 2, 8 => 1
  | 3, 1 => 12
  | 3, 6 => -2
  | 4, 2 => 12
  | 4, 7 => -2
  | 5, 1 => -6
  | 5, 6 => 2
  | 6, 2 => -6
  | 6, 7 => 2
  | 7, 3 => 3
  | 7, 5 => -3
  | 8, 3 => -3
  | 8, 4 => 6
  | 8, 5 => -3
  | _, _ => 0

theorem left_inverse_certificate :
    ∀ i j : Index, mul B A i j = (if i = j then 12 else 0) := by
  decide

theorem right_inverse_certificate :
    ∀ i j : Index, mul A B i j = (if i = j then 12 else 0) := by
  decide

def hidden (j : Index) : Int :=
  match j.val with
  | 0 => 1
  | 1 => -2
  | 2 => 1
  | _ => 0

theorem missing_anchor_certificate :
    ∀ i : Index, matVec A hidden i = (if i.val = 8 then 12 else 0) := by
  decide

theorem derived_witness_certificate :
    ∀ j : Index,
      2 * A 8 j - 15 * A 3 j - 3 * A 5 j + 16 * A 0 j = 4 * hidden j := by
  decide

def stateA (j : Index) : Int := if j.val = 1 then 1 else 0
def twiceStateB (j : Index) : Int := if j.val = 0 ∨ j.val = 2 then 1 else 0

theorem lower_anchor_agreement :
    ∀ i : Fin 8, 2 * matVec A stateA ⟨i.val, Nat.lt_trans i.isLt (by decide)⟩ =
      matVec A twiceStateB ⟨i.val, Nat.lt_trans i.isLt (by decide)⟩ := by
  decide

theorem quartic_separation :
    matVec A twiceStateB 8 - 2 * matVec A stateA 8 = 12 := by
  decide

/-- Coefficients of (a+b*q)^2 in ascending powers of q. -/
def squareAffine (a b : Int) : List Int := [a*a, a*b+b*a, b*b]

/-- Cleared-denominator nonlinear witness: 1 - 2q + q^2 = (1-q)^2. -/
theorem nonlinear_witness_polynomial_certificate :
    squareAffine 1 (-1) = [1, -2, 1] := by
  decide

/-- Abstract reconstruction principle, independent of matrix representation. -/
theorem injective_of_exact_reconstruction {S D : Type}
    (encode : S → D) (decode : D → S)
    (h : ∀ s, decode (encode s) = s) :
    ∀ s t, encode s = encode t → s = t := by
  intro s t hst
  calc
    s = decode (encode s) := (h s).symm
    _ = decode (encode t) := congrArg decode hst
    _ = t := h t

/-- Once a state is reconstructed, any supplied prediction is preserved. -/
theorem prediction_preservation {S D V : Type}
    (encode : S → D) (decode : D → S) (predict : S → V)
    (h : ∀ s, decode (encode s) = s) (s : S) :
    predict (decode (encode s)) = predict s := by
  rw [h s]

#print axioms left_inverse_certificate
#print axioms right_inverse_certificate
#print axioms missing_anchor_certificate
#print axioms derived_witness_certificate
#print axioms nonlinear_witness_polynomial_certificate
#print axioms injective_of_exact_reconstruction
end Voss
