/- Optional mathlib supplement. Not part of the Std-only default build.
Run in a compatible mathlib project. Not executed in the authoring environment. -/
import Mathlib
namespace VossNonlinear

theorem opening_separation (q : ℝ) :
    (1 + q^2) / 2 - q = (1-q)^2 / 2 := by ring

theorem opening_separation_positive (q : ℝ) (hq : q < 1) :
    0 < (1+q^2)/2-q := by
  rw [opening_separation]
  have h : 0 < 1-q := sub_pos.mpr hq
  positivity

theorem gamma_integrability (r u v tt rr : ℝ)
    (wave : r*(tt-rr)=v) : r*u*(tt-rr)-u*v=0 := by
  calc
    r*u*(tt-rr)-u*v = u*(r*(tt-rr)-v) := by ring
    _ = 0 := by rw [wave]; ring

end VossNonlinear
