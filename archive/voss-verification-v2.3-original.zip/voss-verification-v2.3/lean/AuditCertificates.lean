import Mathlib

/-!
New algebraic certificates. Status is determined by the machine build receipt,
not by this header. These are NOT formalizations of operator convergence,
nonlinear PDE existence, or a quantum gravitational continuum.
-/
namespace VossAudit

/-- Two distinct values on one fixed-area hyperbola force F'' and V to vanish.
The premise that the geometric variations yield these equations is external. -/
theorem single_chart_zero
    (f2 pot d1 d2 : ℝ) (hd : d1 ≠ d2)
    (h1 : pot = f2 * d1) (h2 : pot = f2 * d2) :
    f2 = 0 ∧ pot = 0 := by
  have hprod : f2 * (d1 - d2) = 0 := by nlinarith
  have hdiff : d1 - d2 ≠ 0 := sub_ne_zero.mpr hd
  have hf : f2 = 0 := (mul_eq_zero.mp hprod).resolve_right hdiff
  constructor
  · exact hf
  · simpa [hf] using h1

/-- The remaining denominator-cleared single-chart equations select U and W. -/
theorem single_chart_kinetic
    (r fp f2 u w : ℝ) (hr : r ≠ 0) (hf : f2 = 0)
    (hs : 2 * u * r ^ 2 - w = 0)
    (hm : -2 * r * (r * f2 + fp) + 2 * u * r ^ 2 + w = 0) :
    w = r * fp ∧ u = fp / (2 * r) := by
  have hw : w = r * fp := by nlinarith [hs, hm, hf]
  have hz : (2 * u * r - fp) * r = 0 := by nlinarith [hs, hw]
  have hl : 2 * u * r - fp = 0 := (mul_eq_zero.mp hz).resolve_right hr
  constructor
  · exact hw
  · apply (eq_div_iff (mul_ne_zero (by norm_num) hr)).2
    nlinarith [hl]

/-- Algebraic part only: a nonzero regular Lax prefactor forces W_{+-}=0. -/
theorem lax_obstruction_zero
    (s w z : ℝ) (hs : s ≠ 0) (hw : w ≠ 0)
    (hden : 1 - s ^ 2 ≠ 0)
    (h : (4 * s ^ 2 / (1 - s ^ 2)) * (z / w) = 0) : z = 0 := by
  have hp : 4 * s ^ 2 / (1 - s ^ 2) ≠ 0 :=
    div_ne_zero (mul_ne_zero (by norm_num) (pow_ne_zero 2 hs)) hden
  have hz : z / w = 0 := (mul_eq_zero.mp h).resolve_left hp
  exact (div_eq_zero_iff.mp hz).resolve_right hw

/-- Non-null area is essential in the chain-rule inference. -/
theorem nonnull_area_selects_affine
    (wpp rp rm : ℝ) (hp : rp ≠ 0) (hm : rm ≠ 0)
    (h : wpp * (rp * rm) = 0) : wpp = 0 := by
  exact (mul_eq_zero.mp h).resolve_right (mul_ne_zero hp hm)

/-- Equal minimally coupled probe response fixes a conformal multiplier
where the calibrated effective mass squared is nonzero. -/
theorem probe_fixes_frame
    (multiplier effectiveMass : ℝ) (hm : effectiveMass ≠ 0)
    (h : multiplier * effectiveMass = effectiveMass) : multiplier = 1 := by
  have hz : (multiplier - 1) * effectiveMass = 0 := by nlinarith
  exact sub_eq_zero.mp ((mul_eq_zero.mp hz).resolve_right hm)

/-- Weak first moments plus second moments control the squared norm defect.
This is the real scalar polarization identity used by the analytic theorem. -/
theorem norm_defect_algebra (second cross target : ℝ) :
    second - 2 * cross + target =
      (second - target) - 2 * (cross - target) := by ring

/-- Trace equation of the specified R + alpha R^2 candidate, before linearization. -/
theorem quadratic_gravity_trace (r alpha boxR : ℝ) :
    (1 + 2 * alpha * r) * r - 2 * (r + alpha * r ^ 2)
       + 6 * alpha * boxR = -r + 6 * alpha * boxR := by ring

/-- Pole-free two-factor energy composition contains a genuine cross term. -/
theorem nonlinear_energy_cross (q k : ℝ) (hk : k ≠ 0) :
    (1 - q ^ 2) / k - 2 * ((1 - q) / k) = -(1 - q) ^ 2 / k := by
  field_simp [hk] <;> ring

end VossAudit
