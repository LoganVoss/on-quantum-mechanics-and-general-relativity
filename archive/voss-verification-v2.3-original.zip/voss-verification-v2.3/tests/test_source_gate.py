"""Tests the static guard only. These tests do not run a Lean compiler."""
import importlib.util
from pathlib import Path
import re,unittest
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('guard',ROOT/'scripts/source_gate.py');g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
class GuardTest(unittest.TestCase):
 def test_nested_comments(self):
  self.assertNotIn('sorry',g.strip_comments_and_strings('/- sorry /- admit -/ native_decide -/ theorem x : True := by trivial'))
 def test_actual_sorry_remains(self):
  self.assertRegex(g.strip_comments_and_strings('theorem x : False := by sorry'),r'\bsorry\b')
 def test_string_literal_ignored(self):
  self.assertNotIn('axiom',g.strip_comments_and_strings('def x := "axiom"'))
 def test_unterminated_comment_rejected(self):
  self.assertRaises(ValueError,g.strip_comments_and_strings,'/- no close')
if __name__=='__main__':unittest.main()
