from pathlib import Path
import json
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parents[1]; E=ROOT/'evidence';O=ROOT/'paper'/'selection_figures';O.mkdir(exist_ok=True)
d=pd.read_csv(E/'scalar_competitors.csv')
fig,ax=plt.subplots(figsize=(6.8,4))
for col,label in [('L_exponential','Exponential'),('L_rational','Rational'),('L_perturbed','Perturbed exponential')]:
    ax.plot(d.x,d[col],label=label)
ax.set(xlim=(0,6),xlabel='Dimensionless energy x',ylabel='Principal response L(x)',title='Consistency bounds do not select a unique map')
ax.legend();fig.tight_layout();fig.savefig(O/'selection_competitors.pdf');plt.close(fig)
d=pd.read_csv(E/'composition_attractor.csv')
fig,ax=plt.subplots(figsize=(6.8,4));ax.semilogy(d.tau,d.max_target_error)
ax.set(xlabel='Selection time',ylabel='Largest coefficient error',title='Composition selects a unique grid attractor')
fig.tight_layout();fig.savefig(O/'composition_basin.pdf');plt.close(fig)
d=pd.read_csv(E/'two_polarization_pulses.csv')
q=d[(d.amplitude==1)&(d.scale==.7)&(d.T==.4)]
fig,ax=plt.subplots(figsize=(6.8,4))
for b in sorted(q.twist_parameter.unique()):
    z=q[q.twist_parameter==b].sort_values('R');ax.plot(z.R,z.chi,marker='o',label=f'b = {b:g}')
ax.set(xlabel='Areal radius',ylabel='Twist potential chi',title='Polarization changes while opening stays fixed');ax.legend()
fig.tight_layout();fig.savefig(O/'polarization_deformation.pdf');plt.close(fig)
