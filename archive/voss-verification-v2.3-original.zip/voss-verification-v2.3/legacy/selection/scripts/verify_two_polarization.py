#!/usr/bin/env python3
"""Exact nonlinear two-polarization vacuum check plus a controlled finite pulse.
The metric dictionary and local information-action principle are explicit assumptions.
No coupling expansion is used. This is a classical field verification, not a new
nonperturbative continuum quantization of the unpolarized field.
"""
from __future__ import annotations
import csv,json,sys
from pathlib import Path
import sympy as s
import numpy as np
from scipy.integrate import quad
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from nonlinear_er import pulse_jet,gamma_infinity,gamma_pulse
OUT=ROOT/'evidence';OUT.mkdir(exist_ok=True)

def writecsv(name,rows):
    with (OUT/name).open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def exact_ricci():
    T,R,ang,z=s.symbols('T R angle z',real=True)
    p=s.Function('psi')(T,R);g=s.Function('gamma')(T,R)
    a=s.Function('A')(T,R);c=s.Function('chi')(T,R)
    coords=[T,R,ang,z]
    ep=s.exp(p);em=s.exp(-p);eb=s.exp(g-p)
    metric=s.Matrix([[-eb,0,0,0],[0,eb,0,0],[0,0,R**2*em+ep*a*a,ep*a],[0,0,ep*a,ep]])
    inv=s.Matrix([[-1/eb,0,0,0],[0,1/eb,0,0],[0,0,ep/R**2,-ep*a/R**2],[0,0,-ep*a/R**2,em+ep*a*a/R**2]])
    assert s.simplify(metric*inv-s.eye(4))==s.zeros(4)
    conn={}
    for i in range(4):
      for j in range(4):
       for k in range(4):
        conn[i,j,k]=s.simplify(sum(inv[i,d]*(s.diff(metric[d,k],coords[j])+s.diff(metric[d,j],coords[k])-s.diff(metric[j,k],coords[d]))/2 for d in range(4)))
    pT,pR=s.diff(p,T),s.diff(p,R);cT,cR=s.diff(c,T),s.diff(c,R)
    gT=R*(pT*pR+s.exp(-2*p)*cT*cR)
    gR=R*(pT*pT+pR*pR+s.exp(-2*p)*(cT*cT+cR*cR))/2
    aT=R*s.exp(-2*p)*cR;aR=R*s.exp(-2*p)*cT
    waves={s.diff(p,T,2):s.diff(p,R,2)+pR/R-s.exp(-2*p)*(cT*cT-cR*cR),
           s.diff(c,T,2):s.diff(c,R,2)+cR/R+2*(pT*cT-pR*cR)}
    rules={s.diff(g,T,2):s.diff(gT,T),s.diff(g,R,2):s.diff(gR,R),s.diff(g,T,R):s.diff(gT,R),
           s.diff(g,T):gT,s.diff(g,R):gR,
           s.diff(a,T,2):s.diff(aT,T),s.diff(a,R,2):s.diff(aR,R),s.diff(a,T,R):s.diff(aT,R),
           s.diff(a,T):aT,s.diff(a,R):aR}
    assert s.simplify((s.diff(gR,T)-s.diff(gT,R)).subs(waves,simultaneous=True))==0
    assert s.simplify((s.diff(aT,R)-s.diff(aR,T)).subs(waves,simultaneous=True))==0
    res={};raws={}
    for i in range(4):
      for j in range(i,4):
        raw=sum(s.diff(conn[k,i,j],coords[k])-s.diff(conn[k,i,k],coords[j])+sum(conn[k,i,j]*conn[l,k,l]-conn[l,i,k]*conn[k,j,l] for l in range(4)) for k in range(4))
        raw=s.simplify(raw)
        val=s.simplify(s.expand(raw.subs(rules,simultaneous=True).subs(waves,simultaneous=True)))
        print('Ricci',i,j,':',val,flush=True)
        assert val==0,(i,j,val)
        res[f'{i}{j}']=str(val);res[f'{j}{i}']=str(val);raws[f'{i}{j}']=str(raw)
    return {'components_zero':len(res),'residuals':res,'raw_independent_Ricci_components':raws,
       'twist_integrability':'0','gamma_integrability':'0','nonlinear_exponentials_expanded_in_amplitude':False}

def run():
    cert=exact_ricci()
    # Exact information target and Ehlers/Mobius orbit.
    u,b=s.symbols('u b',real=True)
    # cos^2+sin^2=1 implemented with b=tan(angle).
    den=1+b*b*s.exp(2*u)
    P=u+s.log(1+b*b)-s.log(den)
    C=b*(1-s.exp(2*u))/den
    P1,P2=s.diff(P,u),s.diff(P,u,2)
    C1,C2=s.diff(C,u),s.diff(C,u,2)
    iso=s.simplify(P1**2+s.exp(-2*P)*C1**2-1)
    geod1=s.simplify(P2+s.exp(-2*P)*C1*C1)
    geod2=s.simplify(C2-2*P1*C1)
    assert iso==geod1==geod2==0
    fun=s.lambdify((u,b),(P,C,P1,C1,P2,C2),'numpy')
    rows=[]
    for amp in [.2,1.,2.]:
     for scale in [.7,1.3]:
      for twist in [0.,.1,.4,.8]:
       for T in [0.,.4,1.1]:
        for R in [.25,.8,2.]:
            z=pulse_jet(T,R,amp,scale);p,c,dp,dc,d2p,d2c=map(float,fun(z['psi'],twist))
            pt,pr=dp*z['psi_T'],dp*z['psi_R'];ct,cr=dc*z['psi_T'],dc*z['psi_R']
            ptt=d2p*z['psi_T']**2+dp*z['psi_TT']
            prr=d2p*z['psi_R']**2+dp*z['psi_RR']
            ctt=d2c*z['psi_T']**2+dc*z['psi_TT']
            crr=d2c*z['psi_R']**2+dc*z['psi_RR']
            wp=ptt-prr-pr/R+np.exp(-2*p)*(ct**2-cr**2)
            wc=ctt-crr-cr/R-2*(pt*ct-pr*cr)
            invariant=dp**2+np.exp(-2*p)*dc**2
            gam=gamma_pulse(T,R,amp,scale)
            E=gamma_infinity(amp,scale)
            rows.append(dict(amplitude=amp,scale=scale,twist_parameter=twist,T=T,R=R,
                 psi=p,chi=c,gamma=gam,gamma_infinity=E,opening=float(np.exp(-E/2)),
                 psi_wave_residual=float(wp),chi_wave_residual=float(wc),
                 target_isometry_residual=float(abs(invariant-1)),
                 backreaction_factor=float(np.exp(gam)),
                 twist_A_T=float(R*np.exp(-2*p)*cr),twist_A_R=float(R*np.exp(-2*p)*ct)))
    writecsv('two_polarization_pulses.csv',rows)
    cert['target_isometry_identity']='0';cert['target_geodesic_residuals']=['0','0']
    (OUT/'two_polarization_exact.json').write_text(json.dumps(cert,indent=2)+'\n')
    summary={'status':'PASS','synthetic_only':True,'exact_vacuum_Ricci_zero_components':16,
          'twist_integrability_exact':True,'gamma_integrability_exact':True,
          'pulse_points':len(rows),'max_psi_wave_residual':max(abs(r['psi_wave_residual']) for r in rows),
          'max_chi_wave_residual':max(abs(r['chi_wave_residual']) for r in rows),
          'max_target_isometry_residual':max(r['target_isometry_residual'] for r in rows),
          'max_backreaction_factor':max(r['backreaction_factor'] for r in rows),
          'polarization_orbit_keeps_asymptotic_opening':True,
          'generic_two_field_quantum_continuum_proved':False,
          'metric_dictionary_and_local_action_are_additional_assumptions':True}
    assert summary['max_psi_wave_residual']<1e-10 and summary['max_chi_wave_residual']<1e-10
    (OUT/'two_polarization_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps(summary,indent=2))
if __name__=='__main__':run()
