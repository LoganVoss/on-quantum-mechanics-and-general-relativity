#!/usr/bin/env python3
"""Run all NEW evidence. Archived baseline evidence is separately attributed."""
import json,os,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
for name in ['verify_selection.py','verify_information_metric.py','verify_two_polarization.py','verify_tensor_exact.py']:
    p=subprocess.run([sys.executable,str(ROOT/'scripts'/name)],cwd=ROOT,env=env,text=True,capture_output=True)
    (ROOT/'evidence'/f'{name[:-3]}_fresh.log').write_text(p.stdout+p.stderr)
    print(name, 'PASS' if p.returncode==0 else 'FAIL',flush=True)
    if p.returncode:
        print(p.stdout+p.stderr);sys.exit(p.returncode)
p=ROOT/'evidence'
files={'selection':'selection_summary.json','information_metric':'information_metric_exact.json',
       'two_polarization':'two_polarization_summary.json','exact_tensor':'tensor_exact_certificate.json'}
(p/'verification_summary.json').write_text(json.dumps({k:json.loads((p/f).read_text()) for k,f in files.items()},indent=2)+'\n')
print('ALL NEW PYTHON/SYMPY CHECKS PASSED. Lean was not run by this command.')
