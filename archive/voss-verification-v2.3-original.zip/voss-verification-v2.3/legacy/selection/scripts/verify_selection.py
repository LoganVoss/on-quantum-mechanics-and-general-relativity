#!/usr/bin/env python3
"""Synthetic checks for selection, nonuniqueness, and a two-channel extension.
No experimental data and no claim to a quantized nonlinear two-polarization field.
"""
from __future__ import annotations
import csv,json,sys,platform
from pathlib import Path
import numpy as np
import sympy as sp
from scipy.linalg import expm
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from anchor_tomography import anchor_operators, hermitian_basis, design_matrix
OUT=ROOT/'evidence'; OUT.mkdir(exist_ok=True)

def writecsv(name,rows):
    with (OUT/name).open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def run():
    rng=np.random.default_rng(20261111)
    x=sp.symbols('x',real=True);eps=sp.symbols('eps',real=True)
    f=1-sp.exp(-x)*(1+eps*x**3)
    ell=sp.diff(f,x)
    assert sp.simplify(ell-sp.exp(-x)*(1+eps*x*x*(x-3)))==0
    assert sp.simplify(sp.diff(f,x,2).subs(x,0)+1)==0
    p=x**3*(x-1)**2*(x-2)**2
    fm=1-sp.exp(-x)*(1+eps*p);lm=sp.diff(fm,x)
    for j in (0,1,2):
        assert sp.simplify((fm-(1-sp.exp(-x))).subs(x,j))==0
        assert sp.simplify((lm-sp.exp(-x)).subs(x,j))==0
    # Exact finite positivity and unitarity's spectral prerequisites.
    rational_F=[sp.Rational(0),sp.Rational(1,2),sp.Rational(2,3)]
    rational_L=[sp.Rational(1),sp.Rational(1,4),sp.Rational(1,9)]
    assert all(0<=v<=1 for v in rational_F+rational_L)
    assert (rational_L[0]+rational_L[2])/2-rational_L[1]==sp.Rational(11,36)
    X=np.linspace(0,12,481)
    scalar=[]
    for e in X:
        F0=-np.expm1(-e); L0=np.exp(-e)
        er=1/64
        F1=1-np.exp(-e)*(1+er*e**3)
        L1=np.exp(-e)*(1+er*e*e*(e-3))
        scalar.append(dict(x=e,F_exponential=F0,L_exponential=L0,
              F_rational=e/(1+e),L_rational=1/(1+e)**2,F_perturbed=F1,L_perturbed=L1))
    assert min(z['F_perturbed'] for z in scalar)>=0
    assert min(z['L_perturbed'] for z in scalar)>0
    assert max(z['L_perturbed'] for z in scalar)<=1
    writecsv('scalar_competitors.csv',scalar)
    # Many-packet factorization: independent energy pairs, not a single witness.
    rows=[]
    for _ in range(128):
        en=rng.uniform(.02,4,5);w=rng.dirichlet(np.ones(5));kap=float(rng.uniform(.05,1.2))
        q=float(w@np.exp(-kap*en))
        pair=float(np.sum(w[:,None]*w[None,:]*np.exp(-kap*(en[:,None]+en[None,:]))))
        lr=(1+kap*en)**-2
        qrat=float(w@lr)
        pairrat=float(np.sum(w[:,None]*w[None,:]*(1+kap*(en[:,None]+en[None,:]))**-2))
        rows.append(dict(kappa=kap,q=q,pair=pair,composition_residual=pair-q*q,
               rational_composition_residual=pairrat-qrat*qrat,
               witness_direct=(1+pair)/2-q,witness_formula=(1-q)**2/2))
    writecsv('packet_composition.csv',rows)
    # Complete tensor-product anchor basis. Calculate expectations and reconstruct.
    ops=np.array([np.kron(a,b) for a in anchor_operators() for b in anchor_operators()])
    basis=np.array([np.kron(a,b) for a in hermitian_basis() for b in hermitian_basis()])
    A=np.einsum('aij,bji->ab',ops,basis).real
    sv=np.linalg.svd(A,compute_uv=False);assert np.linalg.matrix_rank(A)==81
    Ainv=np.linalg.inv(A)
    ea=np.repeat(np.arange(3,dtype=float),3)
    eb=np.tile(np.arange(3,dtype=float),3)
    trials=[]; states=[]; ys=[]
    for trial in range(256):
        rank=1+(trial%9)
        z=rng.normal(size=(9,rank))+1j*rng.normal(size=(9,rank))
        rho=z@z.conj().T;rho/=np.trace(rho).real
        y=np.einsum('ij,aji->a',rho,ops).real
        restored=np.einsum('a,aij->ij',Ainv@y,basis)
        kap=float(rng.uniform(.02,1));eta=float(rng.uniform(0,2));t=float(rng.uniform(0,5))
        K=ea+eb+eta*kap*ea*eb
        L=np.exp(-kap*K);H=-np.expm1(-kap*K)/kap
        U=np.diag(np.exp(-1j*t*H));rhot=U@rho@U.conj().T
        R=U@restored@U.conj().T
        # A held-out Hermitian readout, including coherences.
        j=rng.normal(size=(9,9))+1j*rng.normal(size=(9,9));O=(j+j.conj().T)/2
        oe=float(abs(np.trace(rhot@O)-np.trace(R@O)))
        ue=float(np.linalg.norm(U.conj().T@U-np.eye(9)))
        le=float(abs(np.trace(rho@np.diag(L))-np.trace(restored@np.diag(L))))
        assert np.min(H)>-1e-14 and np.max(H)<1/kap and ue<2e-14
        trials.append(dict(trial=trial,rank=rank,kappa=kap,eta=eta,time=t,
             reconstruction_error=float(np.max(abs(restored-rho))),
             heldout_error=oe,opening_error=le,unitarity_error=ue))
        states.append(rho);ys.append(y)
    writecsv('two_channel_trials.csv',trials)
    np.savez_compressed(OUT/'two_channel_synthetic_data.npz',states=states,anchors=ys,design=A)
    # Fixed spectator occupation changes the effective exponential scale.
    wit=[]
    for kap in [.05,.3,1.]:
      for eta in [0.,.25,1.]:
       for m in [0,1,2]:
        vals=np.exp(-kap*(np.arange(3)+m+eta*kap*np.arange(3)*m))
        direct=(vals[0]+vals[2])/2-vals[1]
        formula=np.exp(-kap*m)*(1-np.exp(-kap*(1+eta*kap*m)))**2/2
        wit.append(dict(kappa=kap,eta=eta,spectator=m,witness_direct=float(direct),
           witness_formula=float(formula),residual=float(abs(direct-formula))))
    writecsv('two_channel_witness.csv',wit)
    # Conditional attractor: linearized logarithmic composition equations on a grid.
    n=24;h=.1;kap=.3;eq=[];b=[]
    for i in range(1,n+1):
      for j in range(i,n+1-i):
        a=np.zeros(n);a[i+j-1]+=1;a[i-1]-=1;a[j-1]-=1
        eq.append(a);b.append(0.)
    a=np.zeros(n);a[0]=1;eq.append(a);b.append(kap*h)
    C=np.array(eq);d=np.array(b);K=C.T@C
    target=kap*h*np.arange(1,n+1);pre=np.linalg.solve(K,C.T)
    U0=rng.uniform(.01,4,(64,n));U=U0.copy();V=np.zeros_like(U)
    dt=.025;end=32.;hist=[]
    def acc(u,v): return -2*v-((u@C.T-d)@pre.T)
    for step in range(round(end/dt)+1):
        tau=step*dt
        if step%40==0:
            analytical=target+(1+tau)*np.exp(-tau)*(U0-target)
            err=U-target
            energy=.5*np.einsum('bi,ij,bj->b',V,K,V)+.5*np.einsum('bi,ij,bj->b',err,K,err)
            hist.append(dict(tau=tau,max_target_error=float(abs(err).max()),
                  max_analytic_error=float(abs(U-analytical).max()),total_Lyapunov=float(energy.sum())))
        if step==round(end/dt):break
        a1=V;b1=acc(U,V)
        a2=V+dt*b1/2;b2=acc(U+dt*a1/2,V+dt*b1/2)
        a3=V+dt*b2/2;b3=acc(U+dt*a2/2,V+dt*b2/2)
        a4=V+dt*b3;b4=acc(U+dt*a3,V+dt*b3)
        U+=dt*(a1+2*a2+2*a3+a4)/6;V+=dt*(b1+2*b2+2*b3+b4)/6
    assert all(hist[j+1]['total_Lyapunov']<=hist[j]['total_Lyapunov']+1e-10 for j in range(len(hist)-1))
    writecsv('composition_attractor.csv',hist)
    # Target information geometry: exact pure-Gaussian QFI.
    psi,chi=sp.symbols('psi chi',real=True)
    G=sp.diag(1,sp.exp(-2*psi));Gi=G.inv();coords=[psi,chi]
    conn={(a,b,c):sp.simplify(sum(Gi[a,d]*(sp.diff(G[d,b],coords[c])+sp.diff(G[d,c],coords[b])-sp.diff(G[b,c],coords[d]))/2 for d in range(2))) for a in range(2) for b in range(2) for c in range(2)}
    ric=sp.Matrix(2,2,lambda a,b:sp.simplify(sum(sp.diff(conn[c,a,b],coords[c])-sp.diff(conn[c,a,c],coords[b])+sum(conn[c,a,b]*conn[d,c,d]-conn[d,a,c]*conn[c,b,d] for d in range(2)) for c in range(2))))
    curvature=sp.simplify(sp.trace(Gi*ric));assert curvature==-2
    cert={'perturbed_clock_derivative':str(ell),'perturbed_second_derivative_at_zero':str(sp.diff(f,x,2).subs(x,0)),
       'finite_support_counterexample_polynomial':str(p),'matches_F_and_L_at':[0,1,2],
       'rational_witness':'11/36','information_target_scalar_curvature':str(curvature),
       'tensor_anchor_rank':81,'tensor_inverse_certificate':'(B tensor B)(A tensor A)=144 I_81 whenever BA=12 I_9',
       'no_symbolic_coupling_truncation':True}
    (OUT/'exact_selection_certificates.json').write_text(json.dumps(cert,indent=2)+'\n')
    summary={'status':'PASS','synthetic_only':True,'python':platform.python_version(),
        'numpy':np.__version__,'sympy':sp.__version__,'seed':20261111,
        'packet_tests':len(rows),'max_exponential_composition_residual':max(abs(r['composition_residual']) for r in rows),
        'min_rational_composition_defect':min(r['rational_composition_residual'] for r in rows),
        'two_channel_rank':81,'two_channel_trials':len(trials),'smallest_design_singular_value':float(sv[-1]),
        'max_two_channel_reconstruction_error':max(r['reconstruction_error'] for r in trials),
        'max_two_channel_heldout_error':max(r['heldout_error'] for r in trials),
        'max_two_channel_unitarity_error':max(r['unitarity_error'] for r in trials),
        'max_two_channel_opening_error':max(r['opening_error'] for r in trials),
        'max_deformed_witness_residual':max(r['residual'] for r in wit),
        'attractor_particles':64,'attractor_grid':24,'composition_equations':len(eq),
        'attractor_min_hessian_eigenvalue':float(np.linalg.eigvalsh(K)[0]),
        'attractor_final_error':hist[-1]['max_target_error'],
        'attractor_RK4_vs_exact_max_error':max(r['max_analytic_error'] for r in hist),
        'Lean_compiled':False,'nonlinear_two_polarization_quantum_continuum_proved':False}
    (OUT/'selection_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps(summary,indent=2))
if __name__=='__main__':run()
