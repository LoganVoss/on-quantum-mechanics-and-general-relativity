#!/usr/bin/env python3
"""Exact integer/rational inverse certificate for the 81-anchor extension."""
from pathlib import Path
import json
import sympy as s
A=s.Matrix([[1,1,1,0,0,0,0,0,0],[0,0,0,2,0,2,0,0,0],[0,0,0,0,2,0,2,0,0],
 [1,3,5,0,0,0,0,2,0],[1,3,5,0,0,0,0,0,2],[1,3,5,0,0,0,0,-2,0],
 [0,0,0,6,0,12,0,0,0],[0,0,0,0,6,0,12,0,0],[3,15,39,0,0,0,0,12,0]])
B=12*A.inv();assert all(x.q==1 for x in B)
AT=s.kronecker_product(A,A);BT=s.kronecker_product(B,B)
assert BT*AT==AT*BT==144*s.eye(81)
out={'status':'PASS','one_mode_determinant':str(A.det()),'single_inverse_scale':12,
     'tensor_dimension':81,'tensor_inverse_scale':144,'exact_left_inverse':True,
     'exact_right_inverse':True,'tensor_determinant_expression':'27648^18',
     'single_A':A.tolist(),'single_B':B.tolist()}
p=Path(__file__).resolve().parents[1]/'evidence';p.mkdir(exist_ok=True)
(p/'tensor_exact_certificate.json').write_text(json.dumps(out,default=str,indent=2)+'\n')
print('PASS: exact 81-dimensional left and right inverse, scale 144')
