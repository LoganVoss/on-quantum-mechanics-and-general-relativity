#!/usr/bin/env python3
"""Derive the real-Gaussian pure-state quantum Fisher metric exactly."""
from pathlib import Path
import json
import sympy as s
OUT=Path(__file__).resolve().parents[1]/'evidence'
x,mu=s.symbols('x mu', real=True);sigma=s.symbols('sigma',positive=True)
p=s.exp(-(x-mu)**2/(2*sigma**2))/(s.sqrt(2*s.pi)*sigma)
scores=[(x-mu)/sigma**2,-1/sigma+(x-mu)**2/sigma**3]
means=[s.simplify(s.integrate(p*v,(x,-s.oo,s.oo))) for v in scores]
I=s.Matrix(2,2,lambda i,j:s.simplify(s.integrate(p*scores[i]*scores[j],(x,-s.oo,s.oo))))
assert means==[0,0]
assert I==s.diag(1/sigma**2,2/sigma**2)
psi,chi=s.symbols('psi chi',real=True)
J=s.Matrix([[0,s.sqrt(2)],[s.exp(psi),0]])
G=s.simplify(J.T*I.subs(sigma,s.exp(psi))*J/2)
assert G==s.diag(1,s.exp(-2*psi))
result={'status':'PASS','real_normalized_pure_state':'sqrt(Normal(mu,sigma^2))',
'zero_mean_scores':list(map(str,means)), 'quantum_Fisher_equals_classical_Fisher_for_this_real_pure_family':True,
'QFI_in_mu_sigma':str(I),'coordinate_map':'mu=sqrt(2)*chi, sigma=exp(psi)',
'half_QFI_in_psi_chi':str(G),'worldsheet_action_or_spacetime_not_derived_by_this_integral':True}
(OUT/'information_metric_exact.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
