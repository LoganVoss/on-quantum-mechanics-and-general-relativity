#!/usr/bin/env python3
"""Reproduce the manuscript's single backreaction figure from stored synthetic data."""
from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt
root=Path(__file__).resolve().parents[1]
folder=root/'paper'/'figures';folder.mkdir(parents=True,exist_ok=True)
data=np.load(root/'evidence'/'nonlinear_evolution_512.npz')
fig,ax=plt.subplots(figsize=(7.2,4.3))
ax.plot(data['r'],np.exp(data['gamma']),label=r'Nonlinear metric factor $e^\gamma$')
ax.axhline(1,linestyle=':',label='No backreaction')
ax.set(xlabel='Calibrated radius R',ylabel='Metric factor',
       title='Finite-amplitude evolution with two independent polarizations')
ax.legend();fig.tight_layout();fig.savefig(folder/'backreaction.pdf');plt.close(fig)
