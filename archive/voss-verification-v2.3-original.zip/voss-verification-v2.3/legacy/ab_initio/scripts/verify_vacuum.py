#!/usr/bin/env python3
"""Independent symbolic Ricci check using equations derived from the selected action."""
from __future__ import annotations
import json
from pathlib import Path
import sympy as s
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'evidence';OUT.mkdir(exist_ok=True)
T,R,z,phi=s.symbols('T R z phi',real=True)
p=s.Function('psi')(T,R);g=s.Function('gamma')(T,R);A=s.Function('A')(T,R)
coords=[T,R,z,phi]
e=s.exp(g-p);ep=s.exp(p)
metric=s.Matrix([[-e,0,0,0],[0,e,0,0],[0,0,ep,ep*A],[0,0,ep*A,R**2/ep+ep*A*A]])
inv=s.Matrix([[-1/e,0,0,0],[0,1/e,0,0],[0,0,1/ep+ep*A*A/R**2,-ep*A/R**2],[0,0,-ep*A/R**2,ep/R**2]])
assert s.simplify(metric*inv-s.eye(4))==s.zeros(4)
C={}
for i in range(4):
 for j in range(4):
  for k in range(4):
   C[i,j,k]=s.simplify(sum(inv[i,d]*(s.diff(metric[d,k],coords[j])+s.diff(metric[d,j],coords[k])-s.diff(metric[j,k],coords[d]))/2 for d in range(4)))
pT,pR=s.diff(p,T),s.diff(p,R);AT,AR=s.diff(A,T),s.diff(A,R)
gr=R*(pT*pT+pR*pR)/2+ep**2*(AT*AT+AR*AR)/(2*R)
gt=R*pT*pR+ep**2*AT*AR/R
wave={s.diff(p,T,2):s.diff(p,R,2)+pR/R+ep**2*(AT*AT-AR*AR)/R**2,
      s.diff(A,T,2):s.diff(A,R,2)-AR/R-2*(pT*AT-pR*AR)}
rules={s.diff(g,R):gr,s.diff(g,T):gt,s.diff(g,R,2):s.diff(gr,R),s.diff(g,T,2):s.diff(gt,T),s.diff(g,T,R):s.diff(gt,R)}
res={};raws={}
for i in range(4):
 for j in range(i,4):
  raw=s.simplify(sum(s.diff(C[k,i,j],coords[k])-s.diff(C[k,i,k],coords[j])+sum(C[k,i,j]*C[l,k,l]-C[l,i,k]*C[k,j,l] for l in range(4)) for k in range(4)))
  val=s.simplify(s.expand(raw.subs(rules,simultaneous=True).subs(wave,simultaneous=True)))
  print(f'Ricci[{i},{j}] = {val}',flush=True)
  assert val==0,(i,j,val)
  res[f'{i}{j}']=str(val);res[f'{j}{i}']=str(val);raws[f'{i}{j}']=str(raw)
out={'status':'PASS','Ricci_components_zero':len(res),'residuals':res,'raw_independent_components':raws,
     'equations_source':'Euler-Lagrange equations of flat-reference-selected action',
     'weak_amplitude_expansion':False,'two_independent_polarizations':True,
     'metric_signature':'(-,+,+,+) on R>0 for real smooth fields',
     'global_time_on_regular_patch':'g^(TT)=-exp(psi-gamma)<0'}
(OUT/'vacuum_exact.json').write_text(json.dumps(out,indent=2)+'\n')
