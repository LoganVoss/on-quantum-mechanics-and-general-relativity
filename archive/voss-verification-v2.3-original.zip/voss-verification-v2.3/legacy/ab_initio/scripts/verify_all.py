#!/usr/bin/env python3
"""Execute all numerical and symbolic evidence without external data downloads."""
from pathlib import Path
import subprocess,sys,json,platform,os
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'evidence';OUT.mkdir(exist_ok=True)
checks=['verify_ab_initio.py','verify_vacuum.py','verify_action_selection_flow.py',
        'verify_dynamics.py','verify_quantum_regulator.py']
results=[]
for script in checks:
    print('Running',script,flush=True)
    completed=subprocess.run([sys.executable,str(ROOT/'scripts'/script)],cwd=ROOT,
        stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,
        env={**os.environ,'OPENBLAS_NUM_THREADS':'1'})
    (OUT/(Path(script).stem+'_run.log')).write_text(completed.stdout)
    results.append({'script':script,'returncode':completed.returncode})
    if completed.returncode:
        print(completed.stdout);raise SystemExit(completed.returncode)
summary={'status':'PASS','python':platform.python_version(),'checks':results,
         'synthetic_evidence_only':True,'Lean_compiled':False,
         'nonperturbative_quantum_continuum_proved':False}
(OUT/'verification_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
