#!/usr/bin/env python3
"""Finite-basis law selection from flat-reference residuals, not Einstein target coefficients.
Only the derivative class, target symmetry, two vacuum references, and one normalization
are supplied. Finite-basis reconstruction does not establish unrestricted functional uniqueness;
that is the separate analytic theorem in the paper.
"""
from __future__ import annotations
import csv,json
from pathlib import Path
import sympy as s
import numpy as np
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'evidence';OUT.mkdir(exist_ok=True)

def main():
    x=s.symbols('rho',positive=True);m=5
    av=s.symbols('a1:6');uv=s.symbols('u0:5');wv=s.symbols('w0:5');vv=s.symbols('v0:5')
    coeff=av+uv+wv+vv
    F=sum(av[j]*x**(j+1) for j in range(m))
    U=sum(uv[j]*x**(j-1) for j in range(m))
    W=sum(wv[j]*x**(j+1) for j in range(m))
    V=sum(vv[j]*x**j for j in range(m))
    residuals=[V,s.diff(F,x,2),U/2-W/(4*x*x),-(x*s.diff(F,x,2)+s.diff(F,x))+x*U+W/(2*x)]
    nodes=[s.Rational(1,2),s.Rational(3,4),s.Integer(1),s.Rational(3,2),s.Integer(2),s.Integer(3)]
    eq=[res.subs(x,n) for n in nodes for res in residuals]+[s.diff(F,x).subs(x,1)-1]
    A,b=s.linear_eq_to_matrix(eq,coeff)
    assert A.rank()==len(coeff)==20
    sol=list(s.linsolve((A,b)))[0]
    reduced={str(z):str(v) for z,v in zip(coeff,sol)}
    sub=dict(zip(coeff,sol))
    selected=[s.simplify(z.subs(sub)) for z in [F,U,W,V]]
    assert selected==[x,1/(2*x),x,0]
    An=np.array(A,float);bn=np.array(b,float).reshape(-1);star=np.array(sol,float)
    # Preconditioned action-space dynamics have e''+2e'+e=0.
    # Numerically integrate it, independently checking the full original residuals.
    rng=np.random.default_rng(3192026);pos=rng.normal(size=(64,len(coeff)));vel=np.zeros_like(pos)
    dt=.02;steps=1500
    def rhs(pos,vel):return vel,-2*vel-(pos-star)
    logs=[]
    for k in range(steps):
        k1,l1=rhs(pos,vel);k2,l2=rhs(pos+dt*k1/2,vel+dt*l1/2)
        k3,l3=rhs(pos+dt*k2/2,vel+dt*l2/2);k4,l4=rhs(pos+dt*k3,vel+dt*l3)
        pos+=dt*(k1+2*k2+2*k3+k4)/6;vel+=dt*(l1+2*l2+2*l3+l4)/6
        if k%50==49:
            logs.append({'selection_time':(k+1)*dt,'max_parameter_error':float(np.max(abs(pos-star))),
                         'max_reference_residual':float(np.max(abs(pos@An.T-bn)))})
    with (OUT/'action_selection_flow.csv').open('w',newline='') as stream:
        w=csv.DictWriter(stream,fieldnames=list(logs[0]));w.writeheader();w.writerows(logs)
    held=[]
    fun=s.lambdify((x,*coeff),residuals,'numpy')
    for q in np.linspace(.3,3.7,41):held.append(float(np.max(abs(np.asarray(fun(q,*pos[0]),float)))))
    result={'status':'PASS','candidate_dimension':20,'constraint_rows':len(eq),'exact_rank':20,
       'nodes':[str(n) for n in nodes],'selected_coefficients':reduced,
       'selected_functions':list(map(str,selected)),'candidate_particles':64,'selection_time':steps*dt,
       'max_final_coefficient_error':float(np.max(abs(pos-star))),
       'max_final_reference_residual':float(np.max(abs(pos@An.T-bn))),
       'max_held_out_reference_residual':max(held),
       'topological_constant_F0':'not selected; omitted from optimization as bulk-null direction',
       'target_Einstein_coefficients_used_as_loss_inputs':False,
       'actual_inputs':['candidate local action class','flat-reference stationarity','Fprime(1)=1 normalization']}
    assert result['max_final_coefficient_error']<1e-9
    (OUT/'action_selection_flow_summary.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
if __name__=='__main__':main()
