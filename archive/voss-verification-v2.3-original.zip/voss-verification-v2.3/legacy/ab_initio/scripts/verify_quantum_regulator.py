#!/usr/bin/env python3
"""Positive two-site hyperbolic-target regulator and exact nonlinear spectral clock.
This tests a finite reflecting configuration-grid regulator, not continuum equivalence.
"""
from __future__ import annotations
import json,csv
from pathlib import Path
import numpy as np
from scipy.linalg import eigh
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'evidence';OUT.mkdir(exist_ok=True)

def main():
    n=4;ps=np.linspace(-.65,.65,n);cs=np.linspace(-.7,.7,n)
    dp=ps[1]-ps[0];dc=cs[1]-cs[0]
    pts=np.array([(p,c) for p in ps for c in cs]);d=len(pts)
    weight=np.exp(-pts[:,0])*dp*dc
    L=np.zeros((d,d))
    def connect(i,j,k):
        L[i,i]+=k;L[j,j]+=k;L[i,j]-=k;L[j,i]-=k
    for i in range(n):
     for j in range(n):
        at=i*n+j
        if i+1<n:connect(at,(i+1)*n+j,np.exp(-(ps[i]+ps[i+1])/2)*dc/dp)
        if j+1<n:connect(at,i*n+j+1,np.exp(ps[i])*dp/dc)
    Kone=L/(2*np.sqrt(weight[:,None]*weight[None,:]))
    p=pts[:,0];x=pts[:,1];y=np.exp(p)
    distance=np.arccosh(np.maximum(1.,1+((x[:,None]-x[None,:])**2+(y[:,None]-y[None,:])**2)/(2*y[:,None]*y[None,:])))
    K=np.kron(Kone,np.eye(d))+np.kron(np.eye(d),Kone)/2+np.diag((.7*distance**2).ravel())
    ev,V=eigh(K);assert ev[0]>-1e-11
    kappa=.23;f=-np.expm1(-kappa*ev)/kappa;opening=np.exp(-kappa*ev)
    H=(V*f)@V.T;O=(V*opening)@V.T
    time=.47;U=(V*np.exp(-1j*time*f))@V.T
    unity=np.max(abs(U.conj().T@U-np.eye(len(ev))))
    assert unity<1e-10
    rng=np.random.default_rng(20261111);rows=[]
    for index in range(128):
        a=rng.normal(size=len(ev))+1j*rng.normal(size=len(ev));a/=np.linalg.norm(a)
        b=U@a
        rows.append({'trial':index,'norm_residual':abs(np.vdot(b,b)-1),
            'energy_conservation_error':abs(np.vdot(b,H@b)-np.vdot(a,H@a)),
            'opening_conservation_error':abs(np.vdot(b,O@b)-np.vdot(a,O@a))})
    with (OUT/'quantum_trials.csv').open('w',newline='') as stream:
        writer=csv.DictWriter(stream,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    result={'status':'PASS','synthetic_only':True,'sites':2,'configuration_nodes_per_site':d,
        'matrix_dimension':len(ev),'configuration_box':{'psi':[-.65,.65],'chi':[-.7,.7]},
        'boundary_condition':'reflecting configuration-grid boundary',
        'minimum_auxiliary_eigenvalue':float(ev[0]),'maximum_auxiliary_eigenvalue':float(ev[-1]),
        'nonlinear_H_min':float(f.min()),'nonlinear_H_max':float(f.max()),'energy_ceiling':1/kappa,
        'unitarity_max_entry_residual':float(unity),
        'trial_count':len(rows),'max_norm_residual':float(max(x['norm_residual'] for x in rows)),
        'max_energy_conservation_error':float(max(x['energy_conservation_error'] for x in rows)),
        'max_opening_conservation_error':float(max(x['opening_conservation_error'] for x in rows)),
        'continuum_limit_proved':False,'causal_no_signalling_proved':False}
    np.savez_compressed(OUT/'quantum_regulator.npz',K=K,eigenvalues=ev,physical_energies=f,opening_eigenvalues=opening,configuration=pts)
    (OUT/'quantum_regulator_summary.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
