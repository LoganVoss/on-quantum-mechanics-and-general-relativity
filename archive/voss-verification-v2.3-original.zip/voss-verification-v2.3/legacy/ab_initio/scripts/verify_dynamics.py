#!/usr/bin/env python3
"""Independent two-profile nonlinear wave-map evolution, not a polarized isometry orbit.
Second-order radial differences and fourth-order RK; finite-amplitude numerical evidence,
not a continuum existence or quantization theorem.
"""
from __future__ import annotations
import csv,json
from pathlib import Path
import numpy as np
from scipy.integrate import cumulative_trapezoid
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'evidence';OUT.mkdir(exist_ok=True)

def simulate(n:int,Tend:float=.8,L:float=8.):
    r=np.linspace(0,L,n+1);dr=L/n
    def grad(f):
        g=np.zeros_like(f);g[1:-1]=(f[2:]-f[:-2])/(2*dr);g[-1]=(3*f[-1]-4*f[-2]+f[-3])/(2*dr)
        return g
    def lap(f):
        v=np.zeros_like(f);v[0]=4*(f[1]-f[0])/dr**2
        v[1:-1]=(f[2:]-2*f[1:-1]+f[:-2])/dr**2+(f[2:]-f[:-2])/(2*dr*r[1:-1])
        return v
    def rhs(y):
        p,c,v,w=y;pr,cr=grad(p),grad(c)
        vt=lap(p)-np.exp(-2*p)*(w*w-cr*cr)
        wt=lap(c)+2*(v*w-pr*cr)
        out=np.array([v,w,vt,wt]);out[:,-1]=0
        return out
    p=1.6*np.exp(-(r/1.1)**2)
    c=.9*(1+.3*r*r)*np.exp(-(r/1.6)**2)
    v=.12*np.exp(-(r/1.3)**2)
    w=-.09*(1-.2*r*r)*np.exp(-(r/1.5)**2)
    y=np.array([p,c,v,w]);y[:,-1]=0
    def energy(y):
        p,c,v,w=y
        den=r*(v*v+grad(p)**2+np.exp(-2*p)*(w*w+grad(c)**2))/2
        return cumulative_trapezoid(den,r,initial=0)
    initial=energy(y)[-1]
    steps=int(np.ceil(Tend/(.16*dr)));dt=Tend/steps
    log=[]
    for k in range(steps):
        a=rhs(y);b=rhs(y+dt*a/2);cc=rhs(y+dt*b/2);d=rhs(y+dt*cc)
        y+=dt*(a+2*b+2*cc+d)/6
        if (k+1)%max(1,steps//10)==0:
            gamma=energy(y)
            log.append({'grid_intervals':n,'time':(k+1)*dt,'gamma_infinity':gamma[-1],
                  'opening':np.exp(-gamma[-1]/2),'max_backreaction_factor':np.exp(np.max(gamma))})
    p,c,v,w=y;pr,cr=grad(p),grad(c);vr,wr=grad(v),grad(w);pacc,cacc=rhs(y)[2:]
    denergy=r*(v*pacc+pr*vr+np.exp(-2*p)*(w*cacc+cr*wr-v*(w*w+cr*cr)))
    gamma_t=cumulative_trapezoid(denergy,r,initial=0)
    expected=r*(v*pr+np.exp(-2*p)*w*cr)
    err=np.max(np.abs(gamma_t-expected))
    gamma=energy(y)
    return r,y,gamma,{'n':n,'steps':steps,'dt':dt,'initial_gamma_infinity':initial,
        'final_gamma_infinity':gamma[-1],'relative_energy_drift':abs(gamma[-1]-initial)/initial,
        'max_flux_constraint_defect':err,'max_backreaction_factor':float(np.exp(np.max(gamma))),
        'minimum_opening':float(np.exp(-gamma[-1]/2))},log

def run():
    results=[];logs=[];ys=[]
    for n in [128,256,512]:
        r,y,g,res,lg=simulate(n);results.append(res);logs+=lg;ys.append(y)
        np.savez_compressed(OUT/f'nonlinear_evolution_{n}.npz',r=r,state=y,gamma=g)
        print(res,flush=True)
    e0=np.max(np.abs(ys[0]-ys[1][:,::2]));e1=np.max(np.abs(ys[1]-ys[2][:,::2]))
    order=float(np.log2(e0/e1))
    for name,data in [('nonlinear_convergence.csv',results),('nonlinear_time_series.csv',logs)]:
        with (OUT/name).open('w',newline='') as f:
            out=csv.DictWriter(f,fieldnames=list(data[0]));out.writeheader();out.writerows(data)
    summary={'status':'PASS','synthetic_only':True,'independent_initial_field_profiles':True,
        'final_time':.8,'radial_domain':[0,8],'grids':[128,256,512],
        'self_convergence_order':order,'coarse_medium_max_difference':float(e0),
        'medium_fine_max_difference':float(e1),'runs':results,
        'field_equation_exactness_proved_by_numerics':False}
    assert order>1.5 and results[-1]['relative_energy_drift']<.005
    (OUT/'nonlinear_dynamics_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps(summary,indent=2))
if __name__=='__main__':run()
