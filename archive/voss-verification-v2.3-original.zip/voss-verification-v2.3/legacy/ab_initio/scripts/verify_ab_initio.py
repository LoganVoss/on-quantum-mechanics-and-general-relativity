#!/usr/bin/env python3
"""Exact local action selection and covariance geometry. Synthetic verification only."""
from __future__ import annotations
import json
from pathlib import Path
import sympy as s

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'evidence';OUT.mkdir(exist_ok=True)

def simp(x): return s.simplify(s.expand(x))

def covariance_geometry():
    u,x=s.symbols('u x', real=True); v,hbar=s.symbols('v hbar',positive=True)
    density=s.sqrt(v/(s.pi*hbar))*s.exp(-v*x*x/hbar)
    du=s.I*x*x/(2*hbar); dv=1/(4*v)-x*x/(2*hbar)
    def mean(z): return s.simplify(s.integrate(density*z,(x,-s.oo,s.oo)))
    scores=[du,dv]
    means=[mean(z) for z in scores]
    Q=s.Matrix(2,2,lambda i,j:s.simplify(4*s.re(mean(s.conjugate(scores[i])*scores[j])-s.conjugate(means[i])*means[j])))
    assert Q==s.eye(2)/(2*v*v)
    M=s.Matrix([[1,u],[u,u*u+v*v]])/v
    assert simp(M.det())==1
    J=[s.simplify(M.inv()*s.diff(M,z)) for z in [u,v]]
    G=s.Matrix(2,2,lambda i,j:s.simplify(s.trace(J[i]*J[j])/2))
    assert G==s.eye(2)/(v*v) and G==2*Q
    # Fixed point of SO(2) congruence: off diagonal 0, equal diagonal.
    aa,bb,cc=s.symbols('aa bb cc',real=True)
    B=s.Matrix([[aa,bb],[bb,cc]]);rot=s.Matrix([[0,-1],[1,0]])
    residual=rot*B*rot.T-B
    assert residual==s.Matrix([[cc-aa,-2*bb],[-2*bb,aa-cc]])
    # The positivity + unit determinant normalization selects I.
    return {'QFI':str(Q),'normalized_covariance_M':str(M),'det_M':'1',
            'target_metric':str(G),'target_Gaussian_curvature':-1,
            'isotropy_residual':str(residual),'target_metric_equals_twice_QFI':True,
            'minimum_uncertainty_local_probe_not_full_gravitational_state':True}

def references():
    t,r=s.symbols('t r',positive=True);rho=s.symbols('rho',positive=True)
    F=s.Function('F');U=s.Function('U');W=s.Function('W');V=s.Function('V')
    eta=s.diag(-1,1);coords=[t,r]
    def calc(area,P):
        derivatives=[s.diff(area,z) for z in coords]
        pd=[s.diff(P,z) for z in coords]
        X=-derivatives[0]**2+derivatives[1]**2
        Y=-pd[0]**2+pd[1]**2
        f=F(area);boxf=-s.diff(f,t,2)+s.diff(f,r,2)
        E=s.Matrix(2,2,lambda i,j:s.simplify(eta[i,j]*boxf-s.diff(f,coords[i],coords[j])
            +U(area)*(derivatives[i]*derivatives[j]-eta[i,j]*X/2)
            -W(area)*(pd[i]*pd[j]-eta[i,j]*Y/2)/2))
        return E
    cyl=calc(r,-s.log(r));milne=calc(t*r,s.log(t/r))
    # Explicit flat chart calibrations; derivatives of F with respect to its argument.
    fpp=F(r).diff(r,2)
    assert simp(cyl[0,0]-cyl[1,1]+fpp)==0
    assert simp(cyl[1,1]-(U(r)/2-W(r)/(4*r*r)))==0
    a,b=s.symbols('a b',real=True)
    selected={F(rho):a*rho+b,U(rho):a/(2*rho),W(rho):a*rho}
    # Recompute with selected functions rather than fragile derivative substitutions.
    def apply_selected(expr):
        return s.simplify(expr.replace(lambda z:z.func==F,lambda z:a*z.args[0]+b)
             .replace(lambda z:z.func==U,lambda z:a/(2*z.args[0]))
             .replace(lambda z:z.func==W,lambda z:a*z.args[0]).doit())
    cyl_s=cyl.applyfunc(apply_selected);mil_s=milne.applyfunc(apply_selected)
    assert cyl_s==s.zeros(2) and mil_s==s.zeros(2)
    # Independent q and rho Euler equations on both flat configurations.
    def full_checks(area,P):
        X=-s.diff(area,t)**2+s.diff(area,r)**2
        Y=-s.diff(P,t)**2+s.diff(P,r)**2
        boxrho=-s.diff(area,t,2)+s.diff(area,r,2)
        rhoeq=-2*(a/(2*area))*boxrho-(-a/(2*area**2))*X-a*Y/2
        qeq=-s.diff(a*area*s.diff(P,t),t)+s.diff(a*area*s.diff(P,r),r)
        return [simp(rhoeq),simp(qeq)]
    assert full_checks(r,-s.log(r))==[0,0]
    assert full_checks(t*r,s.log(t/r))==[0,0]
    # Curvature-zero checks for both explicitly flat 4d charts, independently computed.
    def all_riemann(metric,coords):
        n=len(coords);inv=metric.inv()
        C=[[[s.simplify(sum(inv[i,k]*(s.diff(metric[k,j],coords[l])+s.diff(metric[k,l],coords[j])-s.diff(metric[j,l],coords[k]))/2 for k in range(n))) for l in range(n)] for j in range(n)] for i in range(n)]
        count=0
        for a0 in range(n):
         for b0 in range(n):
          for c0 in range(n):
           for d0 in range(n):
            val=s.diff(C[a0][d0][b0],coords[c0])-s.diff(C[a0][c0][b0],coords[d0])+sum(C[a0][c0][e]*C[e][d0][b0]-C[a0][d0][e]*C[e][c0][b0] for e in range(n))
            assert simp(val)==0,(a0,b0,c0,d0,val)
            count+=1
        return count
    z,phi=s.symbols('z phi',real=True)
    counts=[all_riemann(s.diag(-1,1,1,r*r),[t,r,z,phi]),
            all_riemann(s.diag(-1,1,t*t,r*r),[t,r,z,phi])]
    return {'cylindrical_metric_variation':str(cyl),'milne_polar_metric_variation':str(milne),
        'cylinder_constraints':['F_second(rho)=0','U(rho)=W(rho)/(2*rho**2)'],
        'milne_polar_constraint_after_cylinder':'-a + W(rho)/rho = 0',
        'selected_functions':{'F':'a*rho+b','U':'a/(2*rho)','W':'a*rho','V':'0'},
        'two_flat_reference_Riemann_components_zero':counts,
        'metric_Euler_residuals_zero':8,'shape_and_area_Euler_residuals_zero':4,
        'uniqueness_scope':'parity-even, total derivative order <=2, target SL(2,R) invariant local bulk class; Euler term and boundary terms remain'}

def backreaction():
    T,R=s.symbols('T R',positive=True)
    p=s.Function('psi')(T,R);a=s.Function('A')(T,R);g=s.Function('gamma')(T,R)
    P=p-s.log(R);sig=(g-p)/2
    targetsum=s.diff(P,T)**2+s.diff(P,R)**2+s.exp(2*P)*(s.diff(a,T)**2+s.diff(a,R)**2)
    targetcross=s.diff(P,T)*s.diff(P,R)+s.exp(2*P)*s.diff(a,T)*s.diff(a,R)
    # h Euler tt and tr equations in conformal-areal gauge.
    e_tt=s.diff(sig,R)+1/(4*R)-R*targetsum/4
    e_tr=s.diff(sig,T)-R*targetcross/2
    gr=R*(s.diff(p,T)**2+s.diff(p,R)**2)/2+s.exp(2*p)*(s.diff(a,T)**2+s.diff(a,R)**2)/(2*R)
    gt=R*s.diff(p,T)*s.diff(p,R)+s.exp(2*p)*s.diff(a,T)*s.diff(a,R)/R
    assert simp(e_tt-(s.diff(g,R)-gr)/2)==0
    assert simp(e_tr-(s.diff(g,T)-gt)/2)==0
    # Target Euler equations.
    E_P=s.diff(P,T,2)-s.diff(P,R,2)-s.diff(P,R)/R-s.exp(2*P)*(s.diff(a,T)**2-s.diff(a,R)**2)
    E_Q=s.diff(a,T,2)-s.diff(a,R,2)-s.diff(a,R)/R+2*(s.diff(P,T)*s.diff(a,T)-s.diff(P,R)*s.diff(a,R))
    targetp=s.diff(p,T,2)-s.diff(p,R,2)-s.diff(p,R)/R-s.exp(2*p)*(s.diff(a,T)**2-s.diff(a,R)**2)/R**2
    targetq=s.diff(a,T,2)-s.diff(a,R,2)+s.diff(a,R)/R+2*(s.diff(p,T)*s.diff(a,T)-s.diff(p,R)*s.diff(a,R))
    assert simp(E_P-targetp)==0 and simp(E_Q-targetq)==0
    waves={s.diff(p,T,2):s.diff(p,R,2)+s.diff(p,R)/R+s.exp(2*p)*(s.diff(a,T)**2-s.diff(a,R)**2)/R**2,
       s.diff(a,T,2):s.diff(a,R,2)-s.diff(a,R)/R-2*(s.diff(p,T)*s.diff(a,T)-s.diff(p,R)*s.diff(a,R))}
    assert simp((s.diff(gr,T)-s.diff(gt,R)).subs(waves,simultaneous=True))==0
    return {'gamma_R':str(gr),'gamma_T':str(gt),'psi_equation':str(targetp),'A_equation':str(targetq),
        'metric_variation_gives_backreaction':'PASS','shape_variation_gives_two_polarizations':'PASS',
        'backreaction_integrability':'0','backreaction_inserted_as_independent_constraint':False}

def main():
    result={'status':'PASS','covariance_geometry':covariance_geometry(),'flat_reference_selection':references(),'variational_backreaction':backreaction()}
    (OUT/'ab_initio_exact.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
if __name__=='__main__':main()
