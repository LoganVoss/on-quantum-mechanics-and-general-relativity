#!/usr/bin/env python3
"""Held-out nonlinear continuum predictions from reconstructed initial states."""
from pathlib import Path
import csv,json,sys
import numpy as np
from numpy.polynomial.legendre import leggauss
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from anchor_tomography import random_state,moments,reconstruct_explicit
from nonlinear_er import packet_laplace,energy_map


def radiative_coefficients(order,time,kappa):
    x,w=leggauss(order);k=1+.2*x;w=w/2
    E=energy_map(k,kappa);E2=energy_map(k[:,None]+k[None,:],kappa)
    c01=np.dot(w,np.exp(-1j*time*E))
    c12=np.sqrt(2)*np.sum(w[:,None]*w[None,:]*np.exp(-1j*time*(E2-E[None,:])))
    # An independent sum over normalized unordered two-boson configurations.
    f=np.sqrt(w);direct=0j
    for i in range(order):
        for j in range(i,order):
            coeff=f[i]*f[j]*(1 if i==j else np.sqrt(2))
            if i==j:
                a=np.sqrt(2)*f[i]*f[i]*np.exp(1j*time*E[i])
            else:
                a=f[i]*f[j]*(np.exp(1j*time*E[i])+np.exp(1j*time*E[j]))
            direct+=coeff*np.exp(-1j*time*E2[i,j])*a
    return c01,c12,abs(c12-direct)


def main():
    out=ROOT/'evidence';out.mkdir(exist_ok=True)
    rng=np.random.default_rng(20261112);kap=.3;time=7.
    c01,c12,fock_error=radiative_coefficients(64,time,kap)
    d01,d12,_=radiative_coefficients(96,time,kap)
    aq=np.zeros((3,3),complex);aq[0,1]=c01;aq[1,2]=c12
    Q=aq+aq.conj().T
    q=packet_laplace(kap);q2=packet_laplace(2*kap);g=packet_laplace(-2*kap)
    targets={'opening':np.diag([1,q,q*q]),'opening_squared':np.diag([1,q2,q2*q2]),
             'asymptotic_radial_metric':np.diag([1,g,g*g]),'nonlinear_radiative_mean':Q}
    states=[];anchors=[];rows=[]
    for i in range(256):
        r=random_state(rng,1+i%3);y=moments(r);rec=reconstruct_explicit(y)
        row={'trial':i}
        for label,op in targets.items():
            truth=np.trace(r@op);prediction=np.trace(rec@op)
            row[label+'_error']=float(abs(truth-prediction))
        states.append(r);anchors.append(y);rows.append(row)
    with (out/'nonlinear_prediction_trials.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
    np.savez_compressed(out/'nonlinear_prediction_states.npz',states=states,anchors=anchors,
                        nonlinear_Q=Q,opening=targets['opening'])
    summary={'status':'PASS','trials':len(rows),'kappa':kap,'physical_time':time,
       'full_continuum_compressed_Heisenberg_coefficients':{'a01':[c01.real,c01.imag],'a12':[c12.real,c12.imag]},
       'max_errors':{k:max(r[k] for r in rows) for k in rows[0] if k!='trial'},
       'independent_two_boson_Fock_sum_error':fock_error,
       'quadrature_order_comparison':float(max(abs(c01-d01),abs(c12-d12))),
       'initial_packet_subspace_assumed_invariant':False}
    assert max(summary['max_errors'].values())<1e-10
    assert fock_error<1e-12 and summary['quadrature_order_comparison']<1e-12
    (out/'nonlinear_prediction_verification.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps(summary,indent=2))
if __name__=='__main__':main()
