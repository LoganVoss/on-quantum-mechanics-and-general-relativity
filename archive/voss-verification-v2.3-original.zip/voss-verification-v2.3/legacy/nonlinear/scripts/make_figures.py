#!/usr/bin/env python3
"""Create separate figures using Matplotlib's default colors and style."""
from pathlib import Path
import sys
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from nonlinear_er import energy_map, gamma_pulse, packet_laplace
out=ROOT/'paper'/'figures';out.mkdir(parents=True,exist_ok=True)

E=np.linspace(0,5,400)
fig,ax=plt.subplots(figsize=(6.4,3.5))
ax.plot(E,E,label='Auxiliary free energy')
ax.plot(E,energy_map(E,.3),label='Exact physical energy, kappa = 0.3')
ax.set(xlabel='Auxiliary energy E',ylabel='Energy',title='The nonlinear physical Hamiltonian is retained')
ax.legend();fig.tight_layout();fig.savefig(out/'nonlinear_energy.pdf');plt.close(fig)

kap=np.linspace(.001,2,300)
W=np.array([.5*(1-packet_laplace(k))**2 for k in kap])
fig,ax=plt.subplots(figsize=(6.4,3.5))
ax.plot(kap,W)
ax.set(xlabel='Nonlinear coupling kappa (dimensionless test units)',ylabel='Opening difference: B minus A',title='Identical quadratic data, different nonlinear geometry')
fig.tight_layout();fig.savefig(out/'opening_witness.pdf');plt.close(fig)

r=np.linspace(0,5,130)
fig,ax=plt.subplots(figsize=(6.4,3.5))
for a in [1.,2.,3.]:
    ax.plot(r,[np.exp(gamma_pulse(0,x,a,1)) for x in r],label=f'Amplitude A = {a:g}')
ax.set(xlabel='Areal radius R / pulse scale',ylabel='Backreaction factor exp(gamma)',title='Finite-amplitude vacuum solutions, no weak-field expansion')
ax.legend();fig.tight_layout();fig.savefig(out/'backreaction_profiles.pdf');plt.close(fig)

x=np.genfromtxt(ROOT/'evidence'/'nonlinear_classical_limit.csv',delimiter=',',names=True)
fig,ax=plt.subplots(figsize=(6.4,3.5))
ax.loglog(x['hbar'],x['difference'],marker='o',label='Mean opening error')
ax.loglog(x['hbar'],x['relative_variance'],marker='s',label='Relative opening variance')
ax.set(xlabel='hbar (fixed classical energy and coupling)',ylabel='Dimensionless discrepancy',title='Classical recovery with nonlinear backreaction retained')
ax.legend();fig.tight_layout();fig.savefig(out/'classical_recovery.pdf');plt.close(fig)
print('Wrote four independent PDF figures; no manually selected colors.')
