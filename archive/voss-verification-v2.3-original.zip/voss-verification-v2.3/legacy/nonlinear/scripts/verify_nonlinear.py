#!/usr/bin/env python3
"""Reproduce exact nonlinear reductions and synthetic continuum-packet evidence."""
from __future__ import annotations
import argparse,csv,json,platform,sys
from pathlib import Path
import numpy as np
import scipy
from scipy.integrate import quad
from numpy.polynomial.legendre import leggauss
import sympy as s
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from nonlinear_er import (energy_map,packet_laplace,opening_expectation,
    packet_survival,pulse_jet,gamma_pulse,gamma_infinity,exact_metric)

def csvwrite(path,rows):
    with path.open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def exact_ricci():
    T,R,ang,z=s.symbols('T R phi z', real=True)
    p=s.Function('psi')(T,R);g=s.Function('gamma')(T,R)
    coords=[T,R,ang,z]
    metric=s.diag(-s.exp(g-p),s.exp(g-p),R**2*s.exp(-p),s.exp(p))
    inv=s.diag(-s.exp(p-g),s.exp(p-g),s.exp(p)/R**2,s.exp(-p))
    C={}
    for a in range(4):
        for b in range(4):
            for c in range(4):
                C[a,b,c]=s.simplify(sum(inv[a,d]*(s.diff(metric[d,c],coords[b])+
                   s.diff(metric[d,b],coords[c])-s.diff(metric[b,c],coords[d]))/2 for d in range(4)))
    ric={};reduced={}
    wave={s.diff(p,T,2):s.diff(p,R,2)+s.diff(p,R)/R}
    rules={s.diff(g,T,2):R*(s.diff(p,T,2)*s.diff(p,R)+s.diff(p,T)*s.diff(p,T,R)),
      s.diff(g,R,2):(s.diff(p,T)**2+s.diff(p,R)**2)/2+
         R*(s.diff(p,T)*s.diff(p,T,R)+s.diff(p,R)*s.diff(p,R,2)),
      s.diff(g,T,R):s.diff(p,T)*s.diff(p,R)+R*(s.diff(p,T,R)*s.diff(p,R)+s.diff(p,T)*s.diff(p,R,2)),
      s.diff(g,T):R*s.diff(p,T)*s.diff(p,R),
      s.diff(g,R):R*(s.diff(p,T)**2+s.diff(p,R)**2)/2}
    for a in range(4):
        for b in range(4):
            raw=sum(s.diff(C[c,a,b],coords[c])-s.diff(C[c,a,c],coords[b])+
                sum(C[c,a,b]*C[d,c,d]-C[d,a,c]*C[c,b,d] for d in range(4)) for c in range(4))
            raw=s.simplify(raw)
            val=s.simplify(raw.subs(rules,simultaneous=True).subs(wave))
            assert val==0,(a,b,val)
            ric[f'{a}{b}']=s.sstr(raw);reduced[f'{a}{b}']=str(val)
    return {'metric':'diag(-exp(gamma-psi), exp(gamma-psi), R^2 exp(-psi), exp(psi))',
            'raw_ricci_components':ric,'after_exact_Einstein_Rosen_constraints':reduced,
            'nonlinear_expansion_used':False,'components_zero':16}

def run(out):
    out.mkdir(parents=True,exist_ok=True)
    exact=exact_ricci()
    (out/'einstein_equations_exact.json').write_text(json.dumps(exact,indent=2)+'\n')
    # Independent numerical derivatives and integral reconstruction of a finite-energy pulse.
    pulse=[];fluxerr=0.;waveerr=0.;totalerr=0.
    for A in [.1,1.,3.]:
      for a in [.7,1.3]:
       for T in [0.,.35,1.1]:
        def integrand(r):
            q=pulse_jet(T,r,A,a);return .5*r*(q['psi_T']**2+q['psi_R']**2)
        gi,qe=quad(integrand,0,np.inf,epsabs=3e-11,epsrel=3e-11,limit=250)
        totalerr=max(totalerr,abs(gi-gamma_infinity(A,a)))
        for R in [.2,.8,2.4]:
            q=pulse_jet(T,R,A,a);g=gamma_pulse(T,R,A,a);dt=1e-4
            gT=(-gamma_pulse(T+2*dt,R,A,a)+8*gamma_pulse(T+dt,R,A,a)-
                 8*gamma_pulse(T-dt,R,A,a)+gamma_pulse(T-2*dt,R,A,a))/(12*dt)
            we=abs(q['psi_TT']-q['psi_RR']-q['psi_R']/R)
            fe=abs(gT-R*q['psi_T']*q['psi_R'])
            waveerr=max(waveerr,we);fluxerr=max(fluxerr,fe)
            diag=exact_metric(T,R,A,a,boundary_time=True).diagonal()
            assert diag[0]<0 and np.all(diag[1:]>0)
            pulse.append({'A':A,'scale':a,'T':T,'R':R,'psi':q['psi'],'gamma':g,
               'gamma_infinity':gi,'opening':np.exp(-gi/2),'g_tt':diag[0],
               'g_RR':diag[1],'backreaction_factor':np.exp(g),'wave_residual':we,
               'gamma_time_constraint_error':fe})
    assert waveerr<1e-10 and fluxerr<2e-8 and totalerr<1e-9
    csvwrite(out/'nonlinear_pulse.csv',pulse)
    # Exact continuum-packet nonlinear witness and an independent double quadrature.
    x,w=leggauss(96);k=1+.2*x;w=w/2
    witnesses=[]
    for kap in [.005,.02,.1,.3,1.,2.]:
        q=packet_laplace(kap)
        LA=np.dot(w,np.exp(-kap*k))
        LB=.5*(1+np.sum(w[:,None]*w[None,:]*np.exp(-kap*(k[:,None]+k[None,:]))))
        pred=.5*(1-q)**2
        assert abs(LB-LA-pred)<1e-13
        witnesses.append({'kappa':kap,'packet_k0':1.,'halfwidth':.2,'L_A':LA,'L_B':LB,
            'difference_direct':LB-LA,'difference_formula':pred,'absolute_error':abs(LB-LA-pred),
            'H_A_minus_H_B':(LB-LA)/kap,'semiclassical_opening_both':np.exp(-kap)})
    csvwrite(out/'nonlinear_witness.csv',witnesses)
    # The global unitary is not a unitary evolution within a single initial packet subspace.
    survival=[];quaderr=0.
    for n in [1,2]:
      for t in [0.,1.,5.,10.,20.,30.]:
        v=packet_survival(n,t,.3,order=64);v2=packet_survival(n,t,.3,order=96)
        quaderr=max(quaderr,abs(v-v2));assert abs(v)<=1+1e-12
        survival.append({'n':n,'t':t,'kappa':.3,'survival_probability':abs(v)**2,
             'amplitude_real':v.real,'amplitude_imag':v.imag,'quadrature_comparison':abs(v-v2)})
    csvwrite(out/'packet_subspace_leakage.csv',survival)
    assert min(r['survival_probability'] for r in survival)<.95
    # Finite-energy QFT recovery and exact spectral gap ratio.
    weak=[];Emax=2.4;E=np.linspace(0,Emax,401)
    for kap in [1.,.3,.1,.03,.01,.003,.001]:
      actual=float(np.max(E-energy_map(E,kap)));bound=kap*Emax**2/2
      assert actual<=bound+1e-12
      weak.append({'kappa':kap,'E_max':Emax,'max_H_difference':actual,'rigorous_bound':bound})
    csvwrite(out/'weak_coupling_recovery.csv',weak)
    spectral=[]
    for kap in [.01,.1,.3,1.]:
      eps=.6; en=energy_map(np.arange(5)*eps,kap);gaps=np.diff(en)
      inferred=-np.log(gaps[1]/gaps[0])/eps
      assert abs(inferred-kap)<1e-11
      spectral.append({'kappa_true':kap,'epsilon':eps,'gap_01':gaps[0],
          'gap_12':gaps[1],'ratio':gaps[1]/gaps[0],'inferred_kappa':inferred,
          'absolute_error':abs(inferred-kap)})
    csvwrite(out/'dynamical_law_identification.csv',spectral)
    # Classical coherent-state limit: hbar decreases at fixed classical energy.
    coherent=[];kap=.3;Ecl=2.
    for hb in [.3,.1,.03,.01,.003,.001]:
      N=Ecl/hb;q1=packet_laplace(kap,hbar=hb);q2=packet_laplace(2*kap,hbar=hb)
      logL=N*(q1-1);L=np.exp(logL);classical=np.exp(-kap*Ecl)
      relvar=np.expm1(N*(q2-2*q1+1))
      coherent.append({'hbar':hb,'mean_number':N,'E_classical':Ecl,'opening_quantum':L,
         'opening_classical':classical,'difference':L-classical,'relative_variance':relvar})
    csvwrite(out/'nonlinear_classical_limit.csv',coherent)
    # Exact algebraic backreaction formula (no expansion in G).
    q=s.symbols('q',real=True)
    assert s.expand((1+q*q)/2-q-(1-q)**2/2)==0
    summary={'status':'PASS','data_kind':'Synthetic analytic and numerical checks; not experimental evidence.',
      'model':'Exact polarized Einstein-Rosen reduction; exact continuum physical Hamiltonian; finite-packet initial-state tomography.',
      'python':platform.python_version(),'numpy':np.__version__,'scipy':scipy.__version__,'sympy':s.__version__,
      'nonlinear_Ricci_components_exactly_zero':16,'pulse_points':len(pulse),
      'maximum_pulse_wave_residual':waveerr,'maximum_gamma_flux_residual':fluxerr,
      'maximum_total_gamma_integral_error':totalerr,
      'maximum_nonlinear_witness_error':max(r['absolute_error'] for r in witnesses),
      'maximum_packet_quadrature_disagreement':quaderr,
      'minimum_packet_survival_probability':min(r['survival_probability'] for r in survival),
      'maximum_kappa_inference_error':max(r['absolute_error'] for r in spectral),
      'nonlinear_hamiltonian_truncated_in_G':False,
      'local_unsmeared_quantum_metric_claimed':False,
      'Lean_compiler_executed':False}
    (out/'nonlinear_verification.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps(summary,indent=2))

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=ROOT/'evidence')
    args=ap.parse_args();run(args.output)
