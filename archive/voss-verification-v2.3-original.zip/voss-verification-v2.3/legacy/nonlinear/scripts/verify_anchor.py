#!/usr/bin/env python3
"""Regenerate synthetic evidence and exact algebraic certificates.
Run from any working directory. Nothing is downloaded or uploaded.
"""
from __future__ import annotations
import argparse, csv, hashlib, json, platform, sys
from pathlib import Path
import numpy as np
import scipy
from scipy.linalg import expm
import sympy as sp
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'src'))
from anchor_tomography import (SPECS, quadrature, anchor_operators, hermitian_basis,
    design_matrix, moments, reconstruct_explicit, reconstruct_linear, entropy,
    random_state, characteristic, tomography_preparations,
    identify_sector_hamiltonian, project_density)


def write_csv(path, rows):
    with path.open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)


def exact_algebra():
    a=sp.zeros(9)
    for n in range(1,9): a[n-1,n]=sp.sqrt(n)
    q0=a+a.T; q1=-sp.I*a+sp.I*a.T
    qh=((1-sp.I)*a+(1+sp.I)*a.T)/sp.sqrt(2)
    ops=[sp.eye(3),q0[:3,:3],q1[:3,:3],(q0**2)[:3,:3],
         (qh**2)[:3,:3],(q1**2)[:3,:3],(q0**3)[:3,:3],
         (q1**3)[:3,:3],(q0**4)[:3,:3]]
    p0,p1,p2,u,v,w,x,z,t=sp.symbols('p0 p1 p2 u v w x z t', real=True)
    coord=[p0,p1,p2,u,v,w,x,z,t]
    rho=sp.Matrix([[p0,u-sp.I*v,(z-sp.I*t)/sp.sqrt(2)],
                   [u+sp.I*v,p1,(w-sp.I*x)/sp.sqrt(2)],
                   [(z+sp.I*t)/sp.sqrt(2),(w+sp.I*x)/sp.sqrt(2),p2]])
    ys=[sp.expand(sp.trace(rho*o)) for o in ops]
    A=sp.Matrix([[sp.simplify(sp.diff(y,c)) for c in coord] for y in ys])
    assert all(v.is_Integer for v in A)
    B=12*A.inv()
    assert all(v.is_Integer for v in B)
    assert B*A == 12*sp.eye(9) and A*B == 12*sp.eye(9)
    d=sp.Matrix([1,-2,1,0,0,0,0,0,0])
    assert A*d == sp.Matrix([0]*8+[12])
    witness=sp.simplify(ops[8]/2-sp.Rational(15,4)*ops[3]-sp.Rational(3,4)*ops[5]+4*ops[0])
    assert witness == sp.diag(1,-2,1)
    assert A.rank()==9 and A[:8,:].rank()==8
    ac=a[:3,:3]; comm=ac*ac.T-ac.T*ac
    assert comm==sp.diag(1,1,-2)
    # Gauge variation: commute ordinary derivatives in a symbolic flat-space jet.
    # R_abcd=1/2(h_ad,bc+h_bc,ad-h_ac,bd-h_bd,ac).
    def dd_gauge(i,j,k,l):
        return sp.Symbol('xi'+str(j)+'_'+''.join(map(str,sorted([i,k,l]))))+\
               sp.Symbol('xi'+str(i)+'_'+''.join(map(str,sorted([j,k,l]))))
    for aa in range(4):
        for bb in range(4):
            for cc in range(4):
                for dd in range(4):
                    g=dd_gauge(aa,dd,bb,cc)+dd_gauge(bb,cc,aa,dd)-dd_gauge(aa,cc,bb,dd)-dd_gauge(bb,dd,aa,cc)
                    assert sp.expand(g)==0
    # The chosen free mode solves the linearized wave and tidal equations.
    tt,zz,om=sp.symbols('t z omega', real=True)
    mode=sp.cos(om*zz)*sp.cos(om*tt)
    assert sp.simplify(sp.diff(mode,tt,2)-sp.diff(mode,zz,2))==0
    assert sp.simplify(-sp.diff(mode,tt,2)/2-om**2*mode/2)==0
    return {'coordinate_order':['p0','p1','p2','Re(rho10)','Im(rho10)',
               'sqrt2 Re(rho21)','sqrt2 Im(rho21)','sqrt2 Re(rho20)','sqrt2 Im(rho20)'],
            'A':np.array(A).astype(int).tolist(), 'B':np.array(B).astype(int).tolist(),
            'inverse_denominator':12,'determinant_integer_coordinates':str(A.det()),
            'rank':9,'rank_without_quartic':8,
            'missing_direction':list(map(int,d)),
            'gauge_variation_components_exactly_zero':256,
            'wave_equation_residual':'0','curvature_metric_relation_residual':'0'}


def run(out: Path, nstates: int=1024):
    out.mkdir(parents=True,exist_ok=True)
    rng=np.random.default_rng(20261111)
    exact=exact_algebra()
    (out/'exact_certificates.json').write_text(json.dumps(exact,indent=2)+'\n')
    ops,basis,A=anchor_operators(),hermitian_basis(),design_matrix()
    nmax=16
    held=[np.linalg.matrix_power(quadrature(th,nmax),k)[:3,:3]
          for k,th in [(2,.173),(3,.719),(4,1.117),(5,.391),(6,2.138)]]
    word=np.eye(nmax,dtype=complex)
    for t in [.13,.31,.77,1.03]: word=word@quadrature(t,nmax)
    held.append(word[:3,:3])
    rows=[]; states=[]; ys=[]; reconstructed=[]
    for i in range(nstates):
        r=random_state(rng,rank=1+i%3); y=moments(r)
        r1=reconstruct_explicit(y); r2=reconstruct_linear(y)
        held_error=max(abs(np.trace((r-r1)@o)) for o in held)
        ch_error=max(abs(characteristic(r,t,.37)-characteristic(r1,t,.37)) for t in [.1,.8,2.1])
        time=float(rng.uniform(0,10)); U=np.diag(np.exp(-1j*time*np.arange(3)))
        rt=U@r@U.conj().T; r1t=U@r1@U.conj().T
        rows.append({'state_id':i,'rank':1+i%3,
            'max_entry_error':float(max(np.max(abs(r-r1)),np.max(abs(r-r2)))),
            'heldout_word_error':float(held_error), 'characteristic_error':float(ch_error),
            'entropy_error_nats':abs(entropy(r)-entropy(r1)),
            'evolved_anchor_error':float(np.max(abs(moments(rt)-moments(r1t))))})
        states.append(r); ys.append(y); reconstructed.append(r1)
    write_csv(out/'state_trials.csv',rows)
    np.savez_compressed(out/'synthetic_states.npz',states=states,anchors=ys,reconstructed=reconstructed)
    assert max(r['max_entry_error'] for r in rows)<1e-11
    assert max(r['heldout_word_error'] for r in rows)<1e-9
    # Different full cutoffs must agree on all compressed products tested here.
    cutoff_residual=max(np.max(abs(np.linalg.matrix_power(quadrature(.37,d),6)[:3,:3]-held[4]*0-
                     np.linalg.matrix_power(quadrature(.37,16),6)[:3,:3])) for d in [12,20,24])
    assert cutoff_residual<1e-12
    # Process tomography: reconstruct sector Hamiltonians from independently
    # constructed state derivatives and observed curvature anchors.
    probes=tomography_preparations(); proc_rows=[]; hdata=[]; dydata=[]
    for i in range(128):
        z=rng.normal(size=(3,3))+1j*rng.normal(size=(3,3))
        h=(z+z.conj().T)/2; h-=np.trace(h)*np.eye(3)/3
        derivatives=[-1j*(h@s-s@h) for s in probes]
        dy=np.array([[np.trace(ds@o).real for o in ops] for ds in derivatives])
        hrec=identify_sector_hamiltonian(dy)
        err=float(np.max(abs(h-hrec)))
        proc_rows.append({'trial_id':i,'max_H_entry_error':err,
                          'hermiticity_error':float(np.max(abs(hrec-hrec.conj().T)))})
        hdata.append(h); dydata.append(dy)
    assert max(r['max_H_entry_error'] for r in proc_rows)<1e-10
    write_csv(out/'hamiltonian_trials.csv',proc_rows)
    np.savez_compressed(out/'synthetic_process_data.npz',hamiltonians=hdata,
                        derivative_anchors=dydata,preparations=probes)
    # Finite-difference process data show a separate temporal-resolution cost.
    h=hdata[0]; fd=[]
    for dt in [1e-1,3e-2,1e-2,3e-3,1e-3,3e-4,1e-4]:
        up,um=expm(-1j*h*dt),expm(1j*h*dt)
        dy=np.array([(moments(up@s@up.conj().T)-moments(um@s@um.conj().T))/(2*dt) for s in probes])
        hrec=identify_sector_hamiltonian(dy)
        fd.append({'delta_t':dt,'hamiltonian_error':float(np.max(abs(h-hrec)))})
    write_csv(out/'time_resolution.csv',fd)
    # Nonlinear rule ambiguity: identical equal-time state anchors, different
    # full-space multi-time correlations.
    N=np.arange(nmax,dtype=float); E0=N.copy(); E1=N.copy(); E1[3]+=.7
    q=quadrature(0); time=.8
    def qtime(E):
        U=np.diag(np.exp(-1j*E*time)); return U.conj().T@q@U
    c0=(qtime(E0)@q)[2,2]; c1=(qtime(E1)@q)[2,2]
    assert abs(c0-(3*np.exp(-1j*time)+2*np.exp(1j*time)))<1e-12
    assert abs(c1-(3*np.exp(-1j*1.7*time)+2*np.exp(1j*time)))<1e-12
    # Inference dynamics, not physical spacetime dynamics.
    target=random_state(rng); y=moments(target); ar=A[1:,1:]; K=ar.T@ar
    b=np.array([np.trace(o)/3 for o in ops[1:]]).real
    starts=np.array([[np.trace(s@B).real for B in basis[1:]]
                     for s in [random_state(rng,1+i%3) for i in range(128)]])
    goal=np.array([np.trace(target@B).real for B in basis[1:]])
    x=starts.copy(); v=np.zeros_like(x); dt=.02; paths=[]
    def acc(x,v):
        return -np.linalg.solve(K,((x@ar.T+b-y[1:])@ar).T).T-2*v
    min_ev=0.; previous=float('inf')
    for step in range(1501):
        if step%50==0:
            e=x-goal; energy=.5*np.einsum('bi,ij,bj->b',v,K,v)+.5*np.einsum('bi,ij,bj->b',e,K,e)
            maxe=float(np.max(energy)); assert maxe<=previous+1e-9; previous=maxe
            tau=step*dt; analytic=goal+(1+tau)*np.exp(-tau)*(starts-goal)
            paths.append({'inference_time':tau,'max_coefficient_error':float(np.max(abs(e))),
                          'max_lyapunov_energy':maxe,
                          'max_analytic_trajectory_error':float(np.max(abs(x-analytic)))})
            for coeff in x:
                rr=np.eye(3)/3+sum((c*B for c,B in zip(coeff,basis[1:])),np.zeros((3,3),complex))
                min_ev=min(min_ev,float(np.linalg.eigvalsh(rr)[0]))
        if step==1500: break
        a1=v; b1=acc(x,v)
        a2=v+dt*b1/2; b2=acc(x+dt*a1/2,v+dt*b1/2)
        a3=v+dt*b2/2; b3=acc(x+dt*a2/2,v+dt*b2/2)
        a4=v+dt*b3; b4=acc(x+dt*a3,v+dt*b3)
        x+=dt*(a1+2*a2+2*a3+a4)/6; v+=dt*(b1+2*b2+2*b3+b4)/6
    write_csv(out/'attractor_trajectory.csv',paths)
    assert paths[-1]['max_coefficient_error']<1e-9
    # Noise robustness in dimensionless anchor coordinates, not detector noise.
    sig=float(np.linalg.svd(ar,compute_uv=False)[-1]); noise=[]
    for eps in np.logspace(-8,-2,7):
        errs=[]; bounds=[]; projected=[]
        for j in range(32):
            r=random_state(rng); y=moments(r); perturb=rng.normal(size=8); perturb*=eps/np.linalg.norm(perturb)
            yy=y.copy(); yy[1:]+=perturb; raw=reconstruct_linear(yy)
            er=float(np.sum(np.linalg.svd(raw-r,compute_uv=False)))
            bd=float(np.sqrt(3)*eps/sig)
            assert er<=bd+1e-12
            errs.append(er); bounds.append(bd)
            projected.append(float(np.sum(np.linalg.svd(project_density(raw)-r,compute_uv=False))))
        noise.append({'anchor_error_l2':eps,'max_raw_trace_error':max(errs),
                      'analytic_bound':bounds[0],'max_projected_trace_error':max(projected)})
    write_csv(out/'noise_response.csv',noise)
    # Coherent classical limit is in full Fock space, not the three-level prior.
    classical=[]
    for eps in [1,0.1,0.01,0.001,0.0001]:
        alpha=1/(2*np.sqrt(eps))
        classical.append({'hbar_ratio':eps,'coherent_amplitude':alpha,
                          'occupation':alpha**2,'strain_mean':1.,'strain_variance':eps})
    write_csv(out/'classical_limit.csv',classical)
    pair={'A':moments(np.diag([0.,1.,0.])).tolist(),
          'B':moments(np.diag([.5,0.,.5])).tolist()}
    (out/'pair_anchors.json').write_text(json.dumps(pair,indent=2)+'\n')
    summary={
        'status':'All executed Python algebraic and synthetic tests passed.',
        'data_kind':'Synthetic within the stated model. No laboratory measurements.',
        'seed':20261111,'python':platform.python_version(),
        'numpy':np.__version__,'scipy':scipy.__version__,'sympy':sp.__version__,
        'model':'Canonical packet initial-state tomography. Free-mode checks and closed d=3 process identification are auxiliary benchmarks, not the nonlinear ER evolution.',
        'exact':{k:v for k,v in exact.items() if k not in ['A','B','coordinate_order']},
        'state_reconstruction':{'trials':nstates,**{k:max(r[k] for r in rows) for k in rows[0] if k not in ['state_id','rank']}},
        'sector_hamiltonian_reconstruction':{'trials':128,'max_entry_error':max(r['max_H_entry_error'] for r in proc_rows),
              'scope':'Time-independent closed d=3 unitary generator, trace fixed to zero; exact derivative anchors.'},
        'cutoff_consistency_error':float(cutoff_residual),
        'attractor':{'particles':128,'steps':1500,'step':dt,'minimum_state_eigenvalue':min_ev,**paths[-1]},
        'smallest_normalized_state_design_singular_value':sig,
        'Hamiltonian_counterexample':{'H0_correlator':[c0.real,c0.imag], 'H1_correlator':[c1.real,c1.imag]},
        'formal_verification':{'Lean_executed':False,'reason':'Lean executable unavailable in authoring runtime; network toolchain installation was unavailable.',
                             'certificate_arithmetic':'The same exact integer identities independently checked by SymPy.',
                             'proof_source':'formal/AnchorCertificates.lean','pinned_version':'leanprover/lean4:v4.19.0'}
    }
    (out/'verification.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps(summary,indent=2))

if __name__=='__main__':
    ap=argparse.ArgumentParser(); ap.add_argument('--output',type=Path,default=ROOT/'evidence'/'anchor')
    ap.add_argument('--states',type=int,default=1024); args=ap.parse_args()
    if args.states<1: ap.error('--states must be positive')
    run(args.output,args.states)
