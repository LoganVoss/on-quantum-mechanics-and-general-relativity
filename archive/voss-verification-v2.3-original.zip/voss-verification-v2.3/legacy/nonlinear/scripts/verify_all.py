#!/usr/bin/env python3
"""Run evidence checks; never call unavailable Lean a verification pass."""
from pathlib import Path
import argparse,json,shutil,subprocess,sys
ROOT=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser();p.add_argument('--lean',action='store_true');args=p.parse_args()
for name in ['verify_anchor.py','verify_nonlinear.py','verify_nonlinear_predictions.py']:
    r=subprocess.run([sys.executable,str(ROOT/'scripts'/name)],cwd=ROOT,capture_output=True,text=True)
    (ROOT/'evidence'/f'{name[:-3]}_run.log').write_text(r.stdout+r.stderr)
    if r.returncode:
        print(r.stdout+r.stderr);raise SystemExit(r.returncode)
    print(f'PASS: {name}')
formal={'status':'NOT_EXECUTED','reason':'Separate Lean compiler run required; source and CI supplied.'}
exitcode=0
if args.lean:
    if not shutil.which('lake'):
        formal={'status':'UNAVAILABLE','reason':'lake executable not found'};exitcode=2
    else:
        r=subprocess.run(['lake','build'],cwd=ROOT,capture_output=True,text=True)
        (ROOT/'evidence'/'lean_build.log').write_text(r.stdout+r.stderr)
        formal={'status':'PASS' if r.returncode==0 else 'FAIL','returncode':r.returncode}
        exitcode=r.returncode
summary={'python_checks':'PASS','Lean':formal,'data':'Synthetic; no laboratory data.',
         'nonlinear_backreaction':'Retained exactly in the model; no coupling expansion in its definition.',
         'source_notes':'See docs/CLAIM_LEDGER.md and formal/STATUS.md.'}
(ROOT/'evidence'/'verification_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2));raise SystemExit(exitcode)
