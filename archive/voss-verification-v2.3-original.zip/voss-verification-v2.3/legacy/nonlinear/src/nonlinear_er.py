"""Nonlinear Einstein--Rosen quantities in c=1 units.

The continuum Hamiltonian is F_kappa(H0), not a mode-truncated polynomial.
Packet formulas are exact for the stated initial packet states. A finite
packet subspace is not assumed invariant under physical-time evolution.
"""
from __future__ import annotations
import numpy as np
from scipy.integrate import quad
from numpy.polynomial.legendre import leggauss


def energy_map(e, kappa: float):
    if kappa < 0:
        raise ValueError('kappa must be nonnegative')
    e = np.asarray(e, dtype=float)
    if np.any(e < 0):
        raise ValueError('auxiliary energy must be nonnegative')
    return e if kappa == 0 else -np.expm1(-kappa*e)/kappa


def packet_laplace(s: float, *, k0: float=1., width: float=.2,
                   hbar: float=1.) -> float:
    if not (0 <= width < k0 and hbar > 0):
        raise ValueError('Require 0 <= width < k0 and hbar > 0')
    x=s*hbar*width
    sinhc = 1+x*x/6+x**4/120 if abs(x)<1e-5 else np.sinh(x)/x
    return float(np.exp(-s*hbar*k0)*sinhc)


def opening_expectation(probabilities, kappa: float, **kwargs) -> float:
    p=np.asarray(probabilities, dtype=float)
    if p.ndim!=1 or np.any(p<0) or not np.isclose(p.sum(),1):
        raise ValueError('Use a normalized finite occupation distribution')
    q=packet_laplace(kappa, **kwargs)
    return float(np.dot(p,q**np.arange(len(p))))


def packet_survival(n: int, time: float, kappa: float, *, k0: float=1.,
                    width: float=.2, hbar: float=1., order: int=80) -> complex:
    """Exact spectral integral, evaluated by independent Gauss quadrature.

    It is <n_f|exp[-it F(H0)/hbar]|n_f>, not a unitary 3x3 block.
    """
    if n not in (0,1,2):
        raise ValueError('This implementation supports n=0,1,2')
    if not 0 <= width < k0:
        raise ValueError('Require a positive-frequency packet')
    if n==0:
        return 1.+0j
    x,w=leggauss(order); k=k0+width*x; w=w/2
    if n==1:
        return complex(np.dot(w,np.exp(-1j*time*energy_map(hbar*k,kappa)/hbar)))
    e=hbar*(k[:,None]+k[None,:])
    return complex(np.sum(w[:,None]*w[None,:]*np.exp(-1j*time*energy_map(e,kappa)/hbar)))


def pulse_jet(T: float, R: float, amplitude: float=1., scale: float=1.) -> dict:
    """Finite-energy exact cylindrical pulse; derivatives are analytic."""
    if R < 0 or scale <= 0:
        raise ValueError('Require R >= 0 and scale > 0')
    z=scale+1j*T; D=z*z+R*R; A=amplitude
    return {'psi':float(A*np.real(D**(-.5))),
            'psi_T':float(A*np.real(-1j*z*D**(-1.5))),
            'psi_R':float(A*np.real(-R*D**(-1.5))),
            'psi_TT':float(A*np.real((R*R-2*z*z)*D**(-2.5))),
            'psi_RR':float(A*np.real((2*R*R-z*z)*D**(-2.5))),
            'psi_TR':float(A*np.real(3j*z*R*D**(-2.5)))}


def gamma_pulse(T: float, R: float, amplitude: float=1., scale: float=1.) -> float:
    def integrand(r):
        p=pulse_jet(T,r,amplitude,scale)
        return .5*r*(p['psi_T']**2+p['psi_R']**2)
    return float(quad(integrand,0,R,epsabs=2e-12,epsrel=2e-12,limit=250)[0])


def gamma_infinity(amplitude: float, scale: float) -> float:
    return amplitude**2/(8*scale**2)


def exact_metric(T: float, R: float, amplitude: float=1., scale: float=1.,
                 boundary_time: bool=False) -> np.ndarray:
    """Metric components (time,R,phi,z), not a metric expectation."""
    p=pulse_jet(T,R,amplitude,scale)['psi']
    g=gamma_pulse(T,R,amplitude,scale)
    factor=np.exp(g-p)
    lapse_sq=np.exp(-gamma_infinity(amplitude,scale)) if boundary_time else 1.
    return np.diag([-factor*lapse_sq,factor,R*R*np.exp(-p),np.exp(p)])
