"""Anchor-complete tomography of a canonical radiative packet at a reference time.

The initial state support is n=0,1,2. Products are formed before compression.
The nonlinear gravitational interpretation and physical-time propagation are
specified by nonlinear_er.py and the paper, not by the auxiliary free helpers.
"""
from __future__ import annotations
from math import factorial
from typing import Sequence
import numpy as np
from scipy.special import eval_genlaguerre

SPECS = ((1, 0.0), (1, np.pi/2), (2, 0.0), (2, np.pi/4),
         (2, np.pi/2), (3, 0.0), (3, np.pi/2), (4, 0.0))


def annihilation(cutoff: int = 16) -> np.ndarray:
    if not isinstance(cutoff, int) or cutoff < 9:
        raise ValueError("Use cutoff >= 9 for products of degree <= 6 on n <= 2.")
    return np.diag(np.sqrt(np.arange(1, cutoff)), 1).astype(complex)


def quadrature(theta: float, cutoff: int = 16) -> np.ndarray:
    a = annihilation(cutoff)
    return np.exp(-1j*theta)*a + np.exp(1j*theta)*a.conj().T


def anchor_operators(cutoff: int = 16) -> list[np.ndarray]:
    return [np.eye(3, dtype=complex)] + [
        np.linalg.matrix_power(quadrature(theta, cutoff), k)[:3, :3]
        for k, theta in SPECS]


def hermitian_basis() -> list[np.ndarray]:
    out = [np.eye(3, dtype=complex)/np.sqrt(3)]
    for i in range(3):
        for j in range(i+1, 3):
            x, y = np.zeros((3,3), complex), np.zeros((3,3), complex)
            x[i,j] = x[j,i] = 1/np.sqrt(2)
            y[i,j], y[j,i] = -1j/np.sqrt(2), 1j/np.sqrt(2)
            out.extend([x, y])
    out.extend([np.diag([1,-1,0])/np.sqrt(2),
                np.diag([1,1,-2])/np.sqrt(6)])
    return out


def design_matrix() -> np.ndarray:
    return np.array([[np.trace(o@b).real for b in hermitian_basis()]
                     for o in anchor_operators()])


def validate_state(rho: np.ndarray, tol: float = 1e-10) -> np.ndarray:
    rho = np.asarray(rho, dtype=complex)
    if rho.shape != (3,3) or not np.isfinite(rho).all():
        raise ValueError("State must be a finite 3 by 3 matrix.")
    if not np.allclose(rho, rho.conj().T, atol=tol, rtol=0):
        raise ValueError("State must be Hermitian.")
    if not np.isclose(np.trace(rho), 1, atol=tol, rtol=0):
        raise ValueError("State must have trace one.")
    if np.linalg.eigvalsh(rho)[0] < -tol:
        raise ValueError("State is not positive semidefinite.")
    return rho


def moments(rho: np.ndarray) -> np.ndarray:
    rho = validate_state(rho)
    return np.array([np.trace(rho@o).real for o in anchor_operators()])


def reconstruct_linear(y: Sequence[float]) -> np.ndarray:
    """Linear inverse on all Hermitian operators; does not impose positivity."""
    y = np.asarray(y, dtype=float)
    if y.shape != (9,) or not np.isfinite(y).all():
        raise ValueError("Expected nine finite real values, including trace.")
    coeff = np.linalg.solve(design_matrix(), y)
    return sum((x*b for x,b in zip(coeff, hermitian_basis())),
               np.zeros((3,3), complex))


def reconstruct_explicit(y: Sequence[float]) -> np.ndarray:
    """Independent closed inverse. Valid for arbitrary trace, not only states."""
    y = np.asarray(y, dtype=float)
    if y.shape != (9,) or not np.isfinite(y).all():
        raise ValueError("Expected nine finite real values, including trace.")
    tr, m10, m11, m20, m21, m22, m30, m31, m40 = y
    alpha, beta = (m10+1j*m11)/2, (m30+1j*m31)/6
    r10, r21 = 2*alpha-beta, (beta-alpha)/np.sqrt(2)
    s = (m20+m22)/2
    nbar = (s-tr)/2
    r20 = ((m20-m22)/4+1j*(m21-s)/2)/np.sqrt(2)
    p2 = (m40-12*np.sqrt(2)*r20.real-3*tr-12*nbar)/12
    p1, p0 = nbar-2*p2, tr-nbar+p2
    return np.array([[p0,r10.conjugate(),r20.conjugate()],
                     [r10,p1,r21.conjugate()], [r20,r21,p2]], complex)


def project_density(rho: np.ndarray) -> np.ndarray:
    """Hilbert-Schmidt projection onto positive trace-one matrices.

    This is a valid-state correction, not a claim of maximum-likelihood fitting.
    """
    ev, u = np.linalg.eigh((rho+rho.conj().T)/2)
    v = np.sort(ev)[::-1]
    cssv = np.cumsum(v)-1
    idx = np.nonzero(v-cssv/np.arange(1,len(v)+1)>0)[0][-1]
    threshold = cssv[idx]/(idx+1)
    p = np.maximum(ev-threshold,0)
    return (u*p)@u.conj().T


def entropy(rho: np.ndarray) -> float:
    p = np.linalg.eigvalsh((rho+rho.conj().T)/2)
    p = p[p>1e-14]
    return float(-np.sum(p*np.log(p)))


def random_state(rng: np.random.Generator, rank: int = 3) -> np.ndarray:
    if rank not in (1,2,3):
        raise ValueError("rank must be 1, 2, or 3")
    a = rng.normal(size=(3,rank))+1j*rng.normal(size=(3,rank))
    rho = a@a.conj().T
    return rho/np.trace(rho).real


def displacement_block(t: float, theta: float) -> np.ndarray:
    """Exact full-Fock displacement matrix elements compressed to n<=2.

    No truncated matrix exponential is used.
    """
    alpha = 1j*t*np.exp(1j*theta)
    r = abs(alpha)**2
    out = np.zeros((3,3),complex)
    for m in range(3):
        for n in range(3):
            if m >= n:
                out[m,n] = (np.exp(-r/2)*np.sqrt(factorial(n)/factorial(m))*
                            alpha**(m-n)*eval_genlaguerre(n,m-n,r))
            else:
                out[m,n] = (np.exp(-r/2)*np.sqrt(factorial(m)/factorial(n))*
                            (-alpha.conjugate())**(n-m)*eval_genlaguerre(m,n-m,r))
    return out


def characteristic(rho: np.ndarray, lam: float, theta: float = 0.,
                   *, coupling: float = 1., omega: float = 1., time: float = 0.) -> complex:
    rho = validate_state(rho)
    return complex(np.trace(rho@displacement_block(lam*coupling, theta+omega*time)))


def tomography_preparations(epsilon: float = 1/6) -> list[np.ndarray]:
    if not 0 < epsilon < 1/3:
        raise ValueError("Choose epsilon in (0,1/3) for this positivity guarantee.")
    base = np.eye(3, dtype=complex)/3
    return [base] + [base+epsilon*b for b in hermitian_basis()[1:]]


def identify_sector_hamiltonian(derivative_anchors: np.ndarray,
                                *, hbar: float = 1.) -> np.ndarray:
    """Infer traceless sector H from exact derivatives on nine known preparations.

    Inputs: 9 x 9 array, row j = d/dt of the nine anchors on preparation j.
    Assumes a time-independent closed unitary generator; not a field-law proof.
    """
    dy = np.asarray(derivative_anchors, float)
    if dy.shape != (9,9) or not np.isfinite(dy).all() or hbar <= 0:
        raise ValueError("Expected finite derivative array (9,9) and hbar>0.")
    basis = hermitian_basis()
    probes = tomography_preparations()
    x = np.array([[np.trace(b@s).real for s in probes] for b in basis])
    derivs = [reconstruct_explicit(row) for row in dy]
    d = np.array([[np.trace(b@s).real for s in derivs] for b in basis])
    superop = d@np.linalg.inv(x)
    def apply_l(op: np.ndarray) -> np.ndarray:
        coeff = np.array([np.trace(b@op) for b in basis])
        return sum((v*b for v,b in zip(superop@coeff,basis)),
                   np.zeros((3,3),complex))
    h = np.zeros((3,3),complex)
    for j in range(3):
        for k in range(3):
            e = np.zeros((3,3),complex); e[j,k]=1
            h += apply_l(e)@e.conj().T
    return 1j*hbar*h/3
