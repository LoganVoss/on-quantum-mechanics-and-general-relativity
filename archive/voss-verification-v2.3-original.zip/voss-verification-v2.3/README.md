# Voss verification and research audit, v2.3

## Read this first

**Lean compilation is still BLOCKED, not completed.** No Lean or Lake executable is present in the authoring environment; direct network downloads failed. The GitHub connection was confirmed, but this tool session did not expose repository/Actions operations and did not submit a remote build. See `evidence/lean/build_receipt.json` for the actual attempted command status.

This bundle fixes a real CI defect: the v2.2 workflow ran Python only. The new workflow requires separate Python and Lean jobs. It includes every prior certificate, pins the toolchain and Mathlib commit, inventories all 38 theorem declarations, inspects proof axioms, and requires Lean to reject an intentionally false control. It does not claim that providing this workflow equals executing it.

## Research advances

* Opening-first continuum criterion: an injective strong limit of the bounded opening operator identifies a unique nonnegative strong-resolvent generator. First and operator-square tomography plus spectral no-loss control provide sufficient conditions.
* Operational frame selector: a massless probe carrying calibrated orbit momentum distinguishes physical quotient conformal factors invisible to the shape Lax system.
* Sourced higher-derivative response and an exact two-qubit causality negative control expose two additional overclaims the project must avoid.

These are conditional analytical constructions and synthetic tests, not a new experimentally confirmed gravitational theory or a completed interacting quantum continuum.

## Commands

```sh
python -m pip install -r requirements.txt
python scripts/verify_all.py
# Requires the official Lean 4.19.0 toolchain manager/runtime and network/cache access:
python scripts/compile_lean.py --fetch-deps
```

The scientific command does NOT assert Lean success. The compilation command fails closed: missing executables return code 78; compiler errors or receipt inconsistencies return nonzero. A successful receipt is written only after an actual completed build and theorem audit.

Run the GitHub workflow using `workflow_dispatch` or push this directory to a chosen repository. This package did not create or publish any repository. All workflow permissions are read-only.

## Files

- `paper/audit.pdf`, `paper/audit.tex`: scientific audit and new theorem proofs.
- `docs/FORMAL_VERIFICATION_STATUS.md`: actual compiler status and coverage boundaries.
- `docs/OPENING_RECONSTRUCTION_THEOREM.md`: full analytical theorem.
- `docs/OPERATIONAL_FRAME_SELECTOR.md`: exact probe reduction and its assumptions.
- `docs/RESEARCH_SWEEP.md`: the full supplied gravitational chain and remaining gaps.
- `lean/`: all proof modules, unified root, axiom-report module, pinned toolchain.
- `archive_sources/`: byte-identical originals of the five prior proof files.
- `machine/`: theorem inventory, dependency/claim metadata and execution blocker.
- `evidence/`: fresh synthetic data, exact checks, source scan, and real blocked build receipt.
- `baseline_v2_2/`: preserved prior research package and its rerun evidence.
- `legacy/`: earlier scientific scripts, supporting modules and rerun outputs.

## Trust boundary

A proof checks its statement and hypotheses. Small algebraic certificates do not formalize the full Einstein tensor, variational classification, ultraviolet limit, or operational causality. A printed `PASS`, a small residual, a successful Python job, or an unsigned JSON receipt alone is not a kernel proof. Other machines should rebuild the pinned source and compare hashes and axiom reports.

All scientific data are synthetic. Original literature and inherited results are credited. No worldwide priority claim is made. Nonlinear gravitational backreaction is retained in the inherited PDE and boundary-Hamiltonian definitions.
