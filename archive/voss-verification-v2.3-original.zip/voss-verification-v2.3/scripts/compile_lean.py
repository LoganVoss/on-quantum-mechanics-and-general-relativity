#!/usr/bin/env python3
"""Actually build all Lean modules, audit theorem axioms, and test a rejection.
No missing tool, failed build, missing theorem, or unapproved axiom can yield PASS.
Run with --fetch-deps once online. This script does not install a compiler.
"""
from pathlib import Path
import argparse,datetime,hashlib,json,os,platform,re,shutil,subprocess,sys,time
ROOT=Path(__file__).resolve().parents[1]; PROJ=ROOT/'lean'; OUT=ROOT/'evidence/lean';OUT.mkdir(parents=True,exist_ok=True)
EXPECTED_MATHLIB='c44e0c8ee63ca166450922a373c7409c5d26b00b'
ALLOWED={'propext','Quot.sound','Classical.choice'}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--fetch-deps',action='store_true');ap.add_argument('--replay',type=Path);args=ap.parse_args()
    receipt={'schema':'voss.build-receipt.v1','status':'started','lean_compiled':False,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'platform':platform.platform(),'python':sys.version,'driver_sha256':sha(Path(__file__)), 'github_context':{k:os.getenv(k) for k in ['GITHUB_REPOSITORY','GITHUB_SHA','GITHUB_RUN_ID','GITHUB_RUN_ATTEMPT']},'steps':[], 'kernel_replay':'not_run','allowed_standard_axioms':sorted(ALLOWED),'source_hashes':{str(p.relative_to(ROOT)):sha(p) for p in sorted(PROJ.glob('*.lean'))}}
    def save():
        receipt['updated_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
        (OUT/'build_receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    def run(label,cmd,cwd=PROJ,expected=0,timeout=1800):
        t=time.monotonic()
        r=subprocess.run(cmd,cwd=cwd,text=True,capture_output=True,timeout=timeout)
        txt=r.stdout+r.stderr;(OUT/(label+'.log')).write_text(txt)
        receipt['steps'].append({'label':label,'argv':[str(x) for x in cmd],'returncode':r.returncode,'seconds':time.monotonic()-t,'log_sha256':sha(OUT/(label+'.log'))})
        save()
        if (expected==0 and r.returncode!=0) or (expected=='nonzero' and r.returncode==0):
            raise RuntimeError(f'{label}: unexpected exit {r.returncode}; inspect {OUT/(label+".log")}')
        return txt
    try:
        run('source_gate',[sys.executable,str(ROOT/'scripts/source_gate.py')],cwd=ROOT)
        if not shutil.which('lean') or not shutil.which('lake'):
            receipt.update(status='blocked',reason='lean and/or lake executable absent; no compilation was performed',lean_compiled=False)
            save();print(json.dumps(receipt,indent=2));return 78
        version=run('lean_version',['lean','--version']);receipt['lean_version']=version.strip()
        if not re.search(r'\b4\.19\.0\b',version):raise RuntimeError('Wrong Lean version; expected 4.19.0')
        run('lake_version',['lake','--version'])
        if args.fetch_deps:
            run('lake_update',['lake','update'])
            run('mathlib_cache',['lake','exe','cache','get'])
        dep=PROJ/'.lake/packages/mathlib'
        commit=run('mathlib_commit',['git','rev-parse','HEAD'],cwd=dep).strip()
        if commit!=EXPECTED_MATHLIB:raise RuntimeError('Mathlib commit mismatch')
        receipt['mathlib_commit']=commit
        # Targeted clean: our outputs cannot be mistaken for a stale successful build.
        shutil.rmtree(PROJ/'.lake/build',ignore_errors=True)
        run('lake_build',['lake','build','VossVerification'])
        output=run('axiom_audit',['lake','env','lean','-DwarningAsError=true','AxiomAudit.lean'])
        names=[x['name'] for x in json.loads((ROOT/'machine/theorems.json').read_text())['theorems']]
        audits=[]
        for name in names:
            esc=re.escape(name)
            empty=re.search(r"'?"+esc+r"'?\s+does not depend on any axioms",output)
            found=re.search(r"'?"+esc+r"'?\s+depends on axioms:\s*\[([^\]]*)\]",output,re.S)
            if empty:axioms=[]
            elif found:axioms=[x.strip() for x in found.group(1).split(',') if x.strip()]
            else:raise RuntimeError(f'Missing axiom report for {name}')
            bad=set(axioms)-ALLOWED
            if bad:raise RuntimeError(f'Unapproved axioms for {name}: {sorted(bad)}')
            audits.append({'name':name,'axioms':axioms})
        receipt['theorem_audit']=audits;receipt['theorems_checked']=len(audits)
        # Control must be rejected by Lean, not merely by a Python text check.
        sentinel=PROJ/'NegativeSentinel.lean';sentinel.write_text('import Std\nexample : (1 : Nat) = 0 := by decide\n')
        try:run('negative_control',['lake','env','lean','NegativeSentinel.lean'],expected='nonzero')
        finally:sentinel.unlink(missing_ok=True)
        if args.replay:
            run('kernel_replay',['lake','env',str(args.replay.resolve()),'--fresh','AllCertificates'])
            receipt['kernel_replay']='passed'
        oleans=sorted((PROJ/'.lake/build').rglob('*.olean'))
        if len(oleans)<8:raise RuntimeError(f'Only {len(oleans)} project olean files found; build incomplete')
        receipt['compiled_objects']={str(p.relative_to(PROJ)):sha(p) for p in oleans}
        man=PROJ/'lake-manifest.json'
        if man.exists():shutil.copyfile(man,OUT/'lake-manifest.json')
        receipt.update(status='passed',lean_compiled=True)
        save();print(json.dumps(receipt,indent=2));return 0
    except Exception as exc:
        receipt.update(status='failed',lean_compiled=False,error=str(exc));save();print(json.dumps(receipt,indent=2));return 1
if __name__=='__main__':sys.exit(main())
