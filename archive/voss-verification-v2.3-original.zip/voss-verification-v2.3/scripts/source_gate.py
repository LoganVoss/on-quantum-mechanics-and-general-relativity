#!/usr/bin/env python3
"""Static source guard. NOT a Lean compiler. Rejects obvious unsound shortcuts."""
from pathlib import Path
import hashlib,json,re,sys
ROOT=Path(__file__).resolve().parents[1]
def strip_comments_and_strings(text):
    out=[];i=0;depth=0;string=False
    while i<len(text):
        if depth:
            if text.startswith('/-',i):depth+=1;i+=2
            elif text.startswith('-/',i):depth-=1;i+=2
            else:out.append('\n' if text[i]=='\n' else ' ');i+=1
        elif string:
            if text[i]=='\\':i+=2
            elif text[i]=='"':string=False;i+=1
            else:out.append('\n' if text[i]=='\n' else ' ');i+=1
        elif text.startswith('/-',i):depth=1;i+=2
        elif text.startswith('--',i):
            j=text.find('\n',i);i=len(text) if j<0 else j
        elif text[i]=='"':string=True;i+=1
        else:out.append(text[i]);i+=1
    if depth or string:raise ValueError('unclosed comment or string')
    return ''.join(out)
def inspect(path):
    text=path.read_text();clean=strip_comments_and_strings(text)
    bad=[]
    for pattern in [r'\b(sorry|admit|native_decide|unsafe)\b',r'^\s*(axiom|opaque)\s',r'\brun_tac\b']:
        bad += [m.group(0).strip() for m in re.finditer(pattern,clean,re.M)]
    return {'path':str(path.relative_to(ROOT)),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'forbidden':bad}
def main():
    paths=sorted((ROOT/'lean').glob('*.lean'))
    records=[inspect(p) for p in paths]
    expected=['AnchorCertificates','MathlibExtensions','SelectionCertificates','FlatReferenceSelection','Certificates','AuditCertificates']
    imports=re.findall(r'^import\s+(\S+)',(ROOT/'lean/AllCertificates.lean').read_text(),re.M)
    ok=all(not r['forbidden'] for r in records) and set(expected)==set(imports)
    result={'status':'passed' if ok else 'failed','kind':'static_source_inspection_not_compilation','files':records,'expected_modules':expected,'actual_imports':imports}
    (ROOT/'evidence/source_gate.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2));return 0 if ok else 1
if __name__=='__main__':sys.exit(main())
