#!/usr/bin/env python3
"""Turn the legacy print-only audit output into explicit acceptance tests."""
from pathlib import Path
import re,json
ROOT=Path(__file__).resolve().parents[1];E=ROOT/'baseline_v2_2/evidence';tests=[]
def gate(name,test,observed):
 assert test,(name,observed)
 tests.append({'name':name,'passed':bool(test),'observed':observed})
geom=(E/'audit_geom_checks.log').read_text()
diffs=[float(x) for x in re.findall(r'diff=([0-9.e+\-]+)',geom)]
gate('off_shell_finite_difference',len(diffs)==3 and max(diffs)<5e-6,diffs)
rics=[float(x) for x in re.findall(r'max\|Ric(?:_mu nu)?\|(?: \(16 comps\))?\s*=\s*([0-9.e+\-]+)',geom)]
gate('flat_reference_Ricci_floor',len(rics)>=4 and max(rics)<1e-5,rics)
extra=(E/'audit_extra_checks.log').read_text()
values=[float(x) for x in re.findall(r'max\|Ric\| = ([0-9.e+\-]+)',extra)]
gate('negative_geometric_controls',len(values)==4 and values[0]<1e-5 and min(values[1:])>1e-3,values)
errs=[float(x) for x in re.findall(r'rel.err = ([0-9.e+\-]+)',extra)]
gate('functional_variation_error',len(errs)==3 and max(errs)<3e-4,errs)
f=json.loads((E/'foundations_summary.json').read_text())
gate('exact_single_chart_rank',f['single_chart_exact_rank']==26 and f['single_chart_exact_nullity']==2,f['single_chart_exact_rank'])
gate('exact_nullspace',f['nullspace_is_exact_Einstein_plus_Euler'],f['nullspace_is_exact_Einstein_plus_Euler'])
c=json.loads((E/'corrected_boundary_summary.json').read_text())
gate('nonlinear_PDE_second_order',all(1.9<x['observed_order']<2.1 for x in c['orders']),c['orders'])
gate('finest_energy_drift',c['rows'][-1]['relative_energy_drift']<1e-5,c['rows'][-1]['relative_energy_drift'])
gate('zero_asymptotic_twist_initial',abs(c['corrected_continuum_twist'])<1e-12,c['corrected_continuum_twist'])
gate('nonlinear_backreaction_retained',c['rows'][-1]['max_exp_gamma']>2,c['rows'][-1]['max_exp_gamma'])
p=json.loads((E/'integrability_summary.json').read_text())
gate('all_Lax_exact_certificates',all(x['passed'] for x in p['exact_checks'].values()),p['exact_checks_passed'])
(ROOT/'evidence/regression_gates.json').write_text(json.dumps({'status':'passed','kind':'explicit_regression_thresholds_not_Lean','tests':tests},indent=2)+'\n')
print(json.dumps(tests,indent=2))
