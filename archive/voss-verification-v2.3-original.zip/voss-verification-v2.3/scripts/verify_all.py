#!/usr/bin/env python3
"""Scientific checks only. Lean compilation is a SEPARATE mandatory CI job."""
from pathlib import Path
import subprocess,sys,time,os,json,hashlib,shutil
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'evidence';OUT.mkdir(exist_ok=True)
cmds=[('baseline_v2_2','scripts/verify_all.py')]
cmds += [('legacy/'+n,'scripts/verify_all.py') for n in ['nonlinear','selection','ab_initio']]
cmds += [('.','scripts/verify_regression_gates.py'),('.','scripts/verify_new_routes.py'),('.','scripts/source_gate.py'),('.','tests/test_source_gate.py')]
records=[]
for cwd,script in cmds:
 t=time.monotonic();label=cwd.replace('/','_').replace('.','root')+'_'+Path(script).stem
 run=subprocess.run([sys.executable,script],cwd=ROOT/cwd,text=True,capture_output=True,timeout=240,env={**os.environ,'OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1'})
 (OUT/(label+'.log')).write_text(run.stdout+run.stderr)
 records.append({'working_directory':cwd,'script':script,'returncode':run.returncode,'seconds':time.monotonic()-t,'sha256':hashlib.sha256((ROOT/cwd/script).read_bytes()).hexdigest()})
 print(label,'exit',run.returncode,flush=True)
 if run.returncode:
  print(run.stdout+run.stderr);(OUT/'verification_manifest.json').write_text(json.dumps(records,indent=2));sys.exit(run.returncode)
(OUT/'verification_manifest.json').write_text(json.dumps({'status':'passed','Lean':'not_executed_by_this_command','records':records},indent=2)+'\n')
print('SCIENTIFIC AND STATIC CHECKS PASSED. This command does not assert Lean compilation.')
