#!/usr/bin/env python3
"""Executed synthetic checks of audit extensions. Not a Lean compiler or experiment."""
from pathlib import Path
import csv,json,math
import numpy as np
import sympy as sp
from scipy.linalg import expm,logm
from scipy.integrate import solve_ivp
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'evidence';OUT.mkdir(exist_ok=True)
rng=np.random.default_rng(230311)
checks={}
def zero(name,expr):
    e=sp.simplify(sp.cancel(expr));assert e==0,(name,e)
    checks[name]={'passed':True,'kind':'exact_sympy','residual':str(e)}

# 1. Fixed-area selection algebra, independent of Lean elaboration.
r,fp=sp.symbols('r fp',positive=True);u,w=sp.symbols('u w')
sol=sp.solve([2*u*r**2-w,-2*r*fp+2*u*r**2+w],[u,w])
zero('selected_U',sol[u]-fp/(2*r));zero('selected_W',sol[w]-r*fp)
s,wp,W,xx,yy=sp.symbols('s wp W xx yy',nonzero=True)
A=s*(1+s)/(1-s);B=s*(1-s)/(1+s)
obs=(sp.diff(A,s)*B-sp.diff(B,s)*A)*xx*yy+(A-B)*(wp/W-xx*yy)
zero('Lax_obstruction_algebra',obs-4*s**2/(1-s**2)*wp/W)

# 2. Properly reduce a minimally coupled Fourier probe on the literal 2+2 metric.
# sigma is any base-conformal shift, rho and shape M are kept fixed.
sig,rho,mu,nu,m,k1,k2=sp.symbols('sigma rho mu nu m k1 k2',positive=True)
M=sp.Matrix([[1,mu],[mu,mu**2+nu**2]])/nu
block=sp.diag(-sp.exp(2*sig),sp.exp(2*sig),1,1)
block[2:4,2:4]=rho*M
zero('probe_volume',block.det()+sp.exp(4*sig)*rho**2)
Gi=block.inv();sqrtg=sp.exp(2*sig)*rho
zero('base_kinetic_cancellation_T',sqrtg*Gi[0,0]+rho)
zero('base_kinetic_cancellation_R',sqrtg*Gi[1,1]-rho)
k=sp.Matrix([k1,k2]);meff=m**2+(k.T*M.inv()*k)[0]/rho
zero('orbit_effective_mass',meff-m**2-( (mu**2+nu**2)*k1**2-2*mu*k1*k2+k2**2)/(rho*nu))

# Frame detection from wave response, with an independent ODE solution.
# Flat cylindrical quotient has D0=-d_T^2+d_R^2+R^-1 d_R.
# Background frame deformation has compactly negligible Gaussian profile.
R=np.linspace(.45,3.5,2401);frame_epsilon=.12
sigma=frame_epsilon*np.exp(-((R-1.8)/.55)**2)
omega=2.3;mass=.7;ell=1.0
veff=mass**2+ell**2/R**2
sigma_fun=lambda x: frame_epsilon*np.exp(-((x-1.8)/.55)**2)
def rhs(x,y):
    V=mass**2+ell**2/x**2
    return [y[1],-y[1]/x-(omega**2-np.exp(2*sigma_fun(x))*V)*y[0]]
# Complex initial datum prevents generic real nodes from causing ratio explosions.
y0=np.array([1.+0j,0.2+1.j])
solution=solve_ivp(rhs,[R[0],R[-1]],y0,t_eval=R,rtol=3e-12,atol=1e-13)
assert solution.success
f=solution.y[0];fr=solution.y[1]
# Five-point second derivative is not the ODE RHS, so this is a held-out check.
h=R[1]-R[0]
frr=(-f[4:]+16*f[3:-1]-30*f[2:-2]+16*f[1:-3]-f[:-4])/(12*h*h)
response=(omega**2*f[2:-2]+frr+fr[2:-2]/R[2:-2])/(veff[2:-2]*f[2:-2])
interior=(R[2:-2]>.65)&(R[2:-2]<3.3)
frame_error=float(np.max(np.abs(response[interior]-np.exp(2*sigma[2:-2])[interior])))
assert frame_error<2e-5,frame_error
pure_orbit=np.exp(2*sigma)*(ell**2/R**2)
pure_orbit_recovered=pure_orbit/(ell**2/R**2)
assert np.max(np.abs(pure_orbit_recovered-np.exp(2*sigma)))<1e-14
frame_rows=[{'R':float(R[i]),'conformal_multiplier':float(np.exp(2*sigma[i])), 'massless_orbit_potential':float(pure_orbit[i]),'reconstructed_multiplier':float(pure_orbit_recovered[i])} for i in range(0,len(R),60)]
with (OUT/'frame_probe.csv').open('w',newline='') as fo:
    wr=csv.DictWriter(fo,fieldnames=frame_rows[0]);wr.writeheader();wr.writerows(frame_rows)

# 3. Opening-first construction: noncommuting finite matrices model the theorem.
kappa=.4; lam=.8;dim=6
Z=rng.normal(size=(dim,dim))+1j*rng.normal(size=(dim,dim));Q,_=np.linalg.qr(Z)
target=Q@np.diag([.0,.15,.8,1.4,2.0,3.5])@Q.conj().T
L=expm(-kappa*target);I=np.eye(dim)
resolvent=np.linalg.inv(target+lam*I)
open_rows=[]
pert=rng.normal(size=(dim,dim))+1j*rng.normal(size=(dim,dim));pert=(pert+pert.conj().T)/2
# Make a positive sequence by conjugation and a vanishing positive shift.
for n in [2,4,8,16,32,64,128]:
    U=expm(1j*pert/n);Kn=U@target@U.conj().T+I/n
    Ln=expm(-kappa*Kn)
    rec=-logm(Ln)/kappa
    rr=np.linalg.inv(rec+lam*I)
    norm_error=float(np.linalg.norm(rec-Kn,2))
    assert norm_error<2e-13
    open_rows.append({'n':n,'opening_norm_error':float(np.linalg.norm(Ln-L,2)), 'resolvent_norm_error':float(np.linalg.norm(rr-resolvent,2)), 'reconstruction_error':norm_error})
assert open_rows[-1]['resolvent_norm_error']<open_rows[0]['resolvent_norm_error']
with (OUT/'opening_reconstruction.csv').open('w',newline='') as fo:
    wr=csv.DictWriter(fo,fieldnames=open_rows[0]);wr.writeheader();wr.writerows(open_rows)
# An explicit algebraic identity supporting weak+square -> strong.
second,cross,norm=sp.symbols('second cross norm',real=True)
zero('weak_plus_second_identity',(second-2*cross+norm)-((second-norm)-2*(cross-norm)))
# Partial saturation: low-energy anchors alone can miss an escaped sector.
partial=[]
for n in [1,5,10,25,50,100]:
    energies=np.array([0.,1.,float(n)]);ls=np.exp(-kappa*energies)
    partial.append({'n':n,'L_low0':float(ls[0]),'L_low1':float(ls[1]),'L_hidden':float(ls[2]),'H_hidden':float((1-ls[2])/kappa),'hidden_resolvent':float(1/(n+lam))})
with (OUT/'partial_saturation.csv').open('w',newline='') as fo:
    wr=csv.DictWriter(fo,fieldnames=partial[0]);wr.writeheader();wr.writerows(partial)
# Controlled low-opening mass inequality from an auxiliary mean-energy bound.
violations=[]
for _ in range(256):
    energies=np.sort(rng.exponential(3.,size=50));p=rng.dirichlet(np.ones(50));mean=float(p@energies)
    E=float(rng.uniform(.2,15));tail=float(p[energies>=E].sum())
    violations.append(tail-mean/E)
assert max(violations)<1e-12

# 4. Sourced probes separate R+alpha R^2 even though Ricci-flat fields do not.
alpha,curv,box,trace=sp.symbols('alpha R box T')
zero('quadratic_gravity_trace',(1+2*alpha*curv)*curv-2*(curv+alpha*curv**2)+6*alpha*box-(-curv+6*alpha*box))
svals=np.linspace(0,4,17);a2=.08
response_rows=[{'s':float(x),'GR_response_normalized':-1.,'R2_response_normalized':float(-1/(1+6*a2*x))} for x in svals]
with (OUT/'sourced_response.csv').open('w',newline='') as fo:
    wr=csv.DictWriter(fo,fieldnames=response_rows[0]);wr.writeheader();wr.writerows(response_rows)

# 5. A causality diagnostic for the naive unconstrained tensor-factor interpretation.
epsilon=1.;time=1.;q=np.exp(-kappa*epsilon);gap=(1-q)/kappa
Xop=np.array([[0,1],[1,0]],complex)
H=np.diag((1-np.exp(-kappa*np.array([0,epsilon,epsilon,2*epsilon])))/kappa)
U=expm(-1j*time*H);plus=np.array([1,1])/np.sqrt(2)
expect=[]
for b in [0,1]:
    init=np.kron(plus,np.eye(2)[:,b]);out=U@init
    val=float(np.vdot(out,np.kron(Xop,np.eye(2))@out).real);expect.append(val)
    assert abs(val-np.cos(time*gap*q**b))<1e-14
causal={'A_X_when_B0':expect[0],'A_X_when_B1':expect[1],'difference':abs(expect[0]-expect[1]),'scope':'unconstrained two-qubit tensor-factor toy; not a superluminal signalling result for dressed gravity'}
assert causal['difference']>.01

summary={'status':'passed','exact_algebra_checks':checks,'exact_algebra_count':len(checks),'frame_ODE_independent_fd_max_error':frame_error,'frame_epsilon':frame_epsilon,'opening_noncommuting_trials':len(open_rows),'max_log_reconstruction_error':max(x['reconstruction_error'] for x in open_rows),'energy_tail_tests':len(violations),'max_tail_bound_violation':max(violations),'partial_saturation_demonstrated':True,'causality_diagnostic':causal,'data_are_synthetic':True,'Lean_compilation':False,'interacting_quantum_continuum_constructed':False}
(OUT/'new_routes_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
